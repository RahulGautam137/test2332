Cypress.Commands.add('generateMsisdnsToBeRestricted', (count) => { 

    let fileContent = '[START]\n';
    for(let i=0;i<count;i++){
    cy.writeFile('cypress/fixtures/restrictedListRunTime.txt',
    // '[START]'+'\n'+72+Math.floor(Math.random() * 100000000)+'\n'+72+Math.floor(Math.random() * 100000000)+'\n'+'[END]')
    fileContent += `72${Math.floor(Math.random() * 100000000)}\n`
    )}

    cy.readFile('cypress/fixtures/restrictedListRunTime.txt').then((existingContent) => {
        const newContent = `[END]`;  
        const updatedContent = existingContent + newContent;
        cy.writeFile('cypress/fixtures/restrictedListRunTime.txt', updatedContent);
    })

})

Cypress.Commands.add('pickRandomMsisdnFromGeneratedList', (count) => { 

cy.readFile('cypress/fixtures/restrictedListRunTime.txt').then((data) => {
    
    //To split the data object on the basis of new line character
    var rows = data.split("\n")

    //To remove [START] and [END] from restrictedListRunTime file 
    var msisdnList = rows.slice(1, -1);

    // for (let index = 0; index < msisdnList.length; index++) {      
    //     const element = msisdnList[index];
    //     cy.log(element)
    // }

    const randomMSISDN = msisdnList[Math.floor(Math.random() * rows.length)];
    // cy.log(randomMSISDN)
    return randomMSISDN
});

})