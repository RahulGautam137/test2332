// import '../Utils/generic'

Cypress.Commands.add('setFilepath', (value) => {
    this.sharedValue = value;
  });
  
Cypress.Commands.add('getFilepath', () => {
    return this.sharedValue;
  });


// Generate ICCID
function generateNumericData(length) {
    const min = Math.pow(10, length - 1);
    const max = Math.pow(10, length) - 1;
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

// Generate 32-character DECRYPTION Key
function generateAlphanumericData(length) {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }
  
/* 
   Generate data in the following format
   ICCID , DECRYPTION KEY
   123456789111213 , 1hu9CymiW34WPfMGVtG6N4CQhi1fXQcK
*/
function generateData(iccid, decKey) {
    const iccidData = generateNumericData(iccid);
    const decKeyData = generateAlphanumericData(decKey);
    return `${iccidData},${decKeyData}`;
  }

// Add ICCID , DECRYPTION KEY in text file
Cypress.Commands.add('generateIccidDecKeyPair', (count,iccidLen,decKeyLen,iccidFilePath) => { 
    let filePath = iccidFilePath
    let fileContent = 'Application Version = 13579\nDate =27/02/2024\nSIM Profile = VTOPUP5\nSTART DATA';
    for(let i=0;i<count;i++){
            cy.writeFile(filePath,
            fileContent += '\n'+generateData(iccidLen,decKeyLen)
            )
    }

        cy.readFile(filePath).then((existingContent) => {
            const newContent = `END DATA`;  
            const updatedContent = existingContent + '\n'+newContent;
            cy.writeFile(filePath, updatedContent);
        })
})


//Generate MSISDN for Upload Mobile Number (Associate ICCID, MSISDN in bulk)
function genMsisdn(len) {
  msisdn=72+"";
  var possible = "0123456789";
  for (var i = 0; i < len; i++)
      msisdn += possible.charAt(Math.floor(Math.random() * possible.length));
  return msisdn;
}


/*
Add ICCID , MSISDN in a text file for the first time after creating an
empty file
*/
Cypress.Commands.add('generateIccidMsisdn1', (msisdnLen,iccid,iccidFilePath) => { 
  let filePath = iccidFilePath
  let fileContent = "";
          cy.writeFile(filePath,
          fileContent += iccid+','+genMsisdn(msisdnLen)
          )

})

/*
Add ICCID , MSISDN in a text file for the other runs after file is 
already created
*/
Cypress.Commands.add('generateIccidMsisdn2', (msisdnLen,iccid,iccidFilePath) => { 
  let filePath = iccidFilePath
  cy.readFile(filePath).then((existingContent) => {
    const newContent = iccid+','+genMsisdn(msisdnLen);  
    const updatedContent = existingContent + '\n'+newContent;
    cy.writeFile(filePath, updatedContent);
  })
})


// Cypress.Commands.add('correctIccidMsisdnMapping',(iccidQuery,msisdnQuery)=>{

//   cy.task('queryDatabase',iccidQuery).then((rows)=>{
//     for (let i = 0; i < rows.length; i++) {
//             iccid.push(rows[i].icc_id)    
//     }
//   }).then(function(){
//     let randomIndex = Math.floor(Math.random() * msisdn.length);
//     selectedIccid = iccid[randomIndex];
//     iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
//   })


// })
