// const path = require('path');
// const fs = require('fs');

// Cypress.Commands.add('writeJsonToFile', (jsonData, outputFilePath) => {
//     const jsonString = JSON.stringify(jsonData, null, 2); // Convert JSON object to a pretty-printed string
//     return new Promise((resolve, reject) => {
//       fs.writeFile(outputFilePath, jsonString, 'utf8', (err) => {
//         if (err) {
//           reject(err);
//           return;
//         }
//         resolve(null);
//       });
//     });
//   });


Cypress.Commands.add('selectAndWriteLoginIds', (jsonFilePath,txtFilePath,numberOfRecordsToBeDeleted) => {

  // Reading the JSON file to get all mobile numbers
  return cy.readFile(jsonFilePath).then((loginIds) => {
    // Selecting number Of Records To Be Deleted
    const loginId = loginIds.splice(0, numberOfRecordsToBeDeleted);  // Get the first 4 mobile numbers

    // Converting selected login IDs to a comma-separated string
    const loginIdsStr = loginId.join(',');

    // Writing the comma-separated login IDs to a text file
    return cy.writeFile(txtFilePath, loginIdsStr).then(() => {
      // Update the JSON file to remove the selected mobile numbers
      return cy.writeFile(jsonFilePath, loginIds);
    });
  });
});
