// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })

import loginPage from "../pageObjects/loginPage";
import 'cypress-wait-until';


// ------------------OBJECT DECLARATION--------------------
const loginScreen = new loginPage();


Cypress.Commands.add('launchURL', (URL) => {
    cy.visit(URL); 
})


Cypress.Commands.add('login', (Username, Password) => {
    loginScreen.getLoginID().type(Username)
    loginScreen.getPassword().type(Password)
    loginScreen.getLoginBtn().click()
    cy.wait(2000)
})

Cypress.Commands.add('randomName',()=>{
    let randName = 'AUT'+ Math.floor(Math.random() * 10000)
    return randName
})