Cypress.Commands.add('randomProdName',()=>{
    let rndPrdName = 'Prod'+ Math.floor(Math.random() * 10000)
    return rndPrdName
})

Cypress.Commands.add('randomProdCode',(len)=> {
    rndPrdCode = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for (var i = 0; i < len; i++)
    rndPrdCode += possible.charAt(Math.floor(Math.random() * possible.length));
    return rndPrdCode;
})