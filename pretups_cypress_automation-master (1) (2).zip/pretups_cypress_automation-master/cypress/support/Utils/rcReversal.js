
Cypress.Commands.add('setTxnIdForRevByMsisdn', (value) => {
    this.sharedValue = value;
  });
  
Cypress.Commands.add('getTxnIdForRevByMsisdn', () => {
    return this.sharedValue;
  });
  
  Cypress.Commands.add('logTxnID', () => {
    // Log the shared variable
    cy.log('Shared variable value:', this.sharedValue);
  });