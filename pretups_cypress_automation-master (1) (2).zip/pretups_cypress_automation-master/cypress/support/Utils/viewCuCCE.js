var loginId;
var msisdn

Cypress.Commands.add('getRandomLoginId',(len)=> {
    loginId = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    for (var i = 0; i < len; i++)
        loginId += possible.charAt(Math.floor(Math.random() * possible.length));
    return loginId;
})

Cypress.Commands.add('getRandomMsisdn',(len)=>{
    msisdn=76+"";
    var possible = "0123456789";
    for (var i = 0; i < len; i++)
        msisdn += possible.charAt(Math.floor(Math.random() * possible.length));
    return msisdn;
})

Cypress.Commands.add('getRandomExtCode',(len)=>{
    loginId = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i = 0; i < len; i++)
        loginId += possible.charAt(Math.floor(Math.random() * possible.length));
    return loginId;
})
