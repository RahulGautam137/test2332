class commonEle{
    
    getSearchBar(){
        return cy.get('div.has-search')
    }

    getDropdownOptions(){
        return cy.get('span.ng-option-label')
    }

    getLeftToggleBtn(){
        return cy.get('mat-button-toggle[value="bar"]')
    }

    getRightToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

    getDownloadLink(){
        return cy.get('label.download')
    }

    getChooseFile(){
        return cy.get('label.clickarea')
    }

    getToggleBtnText(){
        return cy.get('span.mat-button-toggle-label-content')
    }

    getSelectedToggleBtn(){
        return cy.get('mat-button-toggle.mat-button-toggle-checked')
    }

    getFileReqdErrMsg(){
        return cy.get('div.invalid-file-format')
    }

    getErrorMessage(){
        return cy.get('span.errorMessage')
    }
}  
export default commonEle
