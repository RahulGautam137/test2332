class serviceTypeSelectorMappingLandingPage{

    getLandingPageHeading(){
        return cy.get('#page-header-container #dlayout')
    }

    getServiceNameDropdown(){
        return cy.get('[formcontrolname="service"]')
    }

    getLandingPageProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getServiceNameDropdownOption(){
        return cy.get('div.ng-dropdown-panel-items').contains('Buddy List')
    }

    getNoMappingServiceNameDropdownOption(){
        return cy.get('div.ng-dropdown-panel-items').contains('C2C Voucher Info')
    }

    getAddBtn(){
        return cy.get('div.add-btn')
    }

    getSearchBar(){
        return cy.get('div.has-search')
    }

    getEditActionBtn(){
        return cy.get('span#editLink')
    }

    getDeleteActionBtn(){
        return cy.get('span#delete')
    }

    getRecordRow(){
        return cy.get('tr.denoTableContent')
    }

    getServiceRequiredErrMsg(){
        return cy.get('span.errorMessage')
    }

    getNoMappingrecordsMsg(){
        return cy.get('div.no-records-found')
    }
}
export default serviceTypeSelectorMappingLandingPage