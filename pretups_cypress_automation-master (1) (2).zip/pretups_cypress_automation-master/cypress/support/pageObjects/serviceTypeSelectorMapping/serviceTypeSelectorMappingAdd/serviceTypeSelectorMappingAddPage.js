class serviceTypeSelectorMappingAddPage{
    getProductNameInputField(){
        return cy.get('[formcontrolname="productName"]')
    }

    getProductCodeInputField(){
        return cy.get('[formcontrolname="productCode"]')
    }

    getSenderSubscriberTypeDropdown(){
        return cy.get('[formcontrolname="senderType"]')
    }

    getReceiverSubscriberTypeDropdown(){
        return cy.get('[formcontrolname="receiverType"]')
    }

    getStatusDropdown(){
        return cy.get('[formcontrolname="status"]')
    }

    // getStatusDropdownText(){
    //     return cy.get('[formcontrolname="status"] div div + div span + span')
    // }

    getDropdownOptionsText(){
        return cy.get('div.ng-option span')
    }

    getPopupAddBtn(){
        return cy.get('#doneBtn')
    }

    getDefaultYesRadioBtn(){
        return cy.get('input[value="Y"]')
    }

    getDefaultNoRadioBtn(){
        return cy.get('input[value="N"]')
    }

    getSuccessMsg(){
        return cy.get('#modal-basic-title')
    }

    getFailureMsg(){
        return cy.get('div.message-failure')
    }

    getDoneBtnOnMsgPopup(){
        return cy.get('#doneBtn')
    }

    getProdNameReqdErrMsg(){
        return cy.get('[formcontrolname="productName"] + span.errorMessage')
    }

    getProdCodeReqdErrMsg(){
        return cy.get('[formcontrolname="productCode"] + span.errorMessage')
    }

    getSenderSubsTypeReqdErrMsg(){
        return cy.get('[formcontrolname="senderType"] + span.errorMessage')
    }

    getRecvSubsTypeReqdErrMsg(){
        return cy.get('[formcontrolname="receiverType"] + span.errorMessage')
    }

    getStatusReqdErrMsg(){
        return cy.get('[formcontrolname="status"] + span.errorMessage')
    }

}
export default serviceTypeSelectorMappingAddPage