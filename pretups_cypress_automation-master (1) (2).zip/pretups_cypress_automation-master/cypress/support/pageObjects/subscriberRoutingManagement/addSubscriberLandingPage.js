class addSubscriberLandingPage{

    getInterfaceCategoryDropDown(){
        return cy.get('#category')
    }

    getInterfaceTypeDropDown(){
        return cy.get('#type')
    }

    getInterfaceDropDown(){
        return cy.get('#interface')
    }

    getMobileNumberDropDown(){
        return cy.xpath("//textarea[@id='number']")
    }

    getSubmitButton(){
        return cy.xpath("//button[@name='Proceed']")
    }

    getResetButton(){
        return cy.xpath("//button[@name='Reset']")
    }

    getSuccessMessagePopUp(){
        return cy.xpath("//div[@id='successfultitle']")
    }

    getDoneButton(){
        return cy.get('#doneId')
    }    

    getBlankMobileNumberError(){
        return cy.xpath("//span[text()=' Mobile number is required ']")
    }

    getBlankInterfaceError(){
        return cy.xpath("//span[text()=' Interface is required ']")
    }

    getBlankInterfaceTypeError(){
        return cy.xpath("//span[text()=' Interface type is required ']")
    }
    
    getBlankInterfaceCategoryError(){
            return cy.xpath("//span[text()=' Interface Category is required ']")
    }
}
export default addSubscriberLandingPage