class deleteSubscriberRoutingLandingPage{

    getMobileNumberTextField(){
        return cy.xpath("//textarea[@id='number']")
    }

    getSubmitButton(){
        return cy.xpath("//button[@name='Submit']")
    }  

    getDeleteSuccessMessagePopUp(){
        return cy.get('#successfultitle')
    }
}

export default deleteSubscriberRoutingLandingPage