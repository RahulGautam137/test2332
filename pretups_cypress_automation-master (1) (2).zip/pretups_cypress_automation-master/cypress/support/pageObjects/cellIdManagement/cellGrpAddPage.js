class cellGrpAddPage{
    getGroupNameInputField(){
        return cy.get('#name')
    }

    getGroupCodeInputField(){
        return cy.get('#code')
    }

    getStatusDropdown(){
        return cy.get('[formcontrolname="status"]')
    }
    
    getAddModifyBtnOnPopup(){
        return cy.get('button.popup-add-btn')
    }
}
export default cellGrpAddPage