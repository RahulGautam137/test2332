class cellIdCellGrpLandingPage{

    getCellIdHeading(){
        return cy.get('span.page-Heading')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getSuccessMsgOnPopup(){
        return cy.get('#successfultitle')
    }

    getDoneBtnOnPopup(){
        return cy.get('#doneId')
    }

    getFailMsgOnPopup(){
        return cy.get('#modal-basic-title-fail')
    }

    //Manage cell group

    getCellGrpHeading(){
        return cy.get('div.operatorHeading')
    }

    getCellGrpAddBtn(){
        return cy.get('div.add-btn-screen')
    }

    getCellGrpModifyActionBtn(){
        return cy.get('a.editRecord')
    }

    getCellGrpDeleteActionBtn(){
        return cy.get('a.deleteRecord')
    }

    getRecordRow(){
        return cy.get('tr.denoTableContent')
    }

    getYesBtnOnDeletePopup(){
        return cy.get('button.popup-red-btn')
    }

    getCellGrpSuccessMsg(){
        return cy.get('#modal-basic-title')
    }

    getCellGrpFailureMsg(){
        return cy.get('div.message-failure')
    }
}
export default cellIdCellGrpLandingPage