class deletePage{
    getDeleteToggleBtn(){
        return cy.get('[ng-reflect-value="unbar"]',{timeout:3000})
    }
   
    getMultipleRadioBtn(){
        return cy.get('#multiple')
    }

    getAllRadioBtn(){
        return cy.get('#all')
    }

    getSubsMsisdnField(){
        return cy.get('#subscriberMobileNumbers')
    }

    getDeleteScreenSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getMsisdnCheckbox(){
        return cy.get('input.td-input-checkbox')    
    }

    getSubsDetailsDeleteScreenSubmitBtn(){
        return cy.get('.rounded-btn')
    }

    getMessage(){
        return cy.get('#modal-basic-title-fail .p14Msg',{ timeout: 30000 })
    }

    getPopupDoneBtn(){
        return cy.get('#anotherRecharge')
    }

    //UI Error Messages
    getSubsMsisdnReqdErrorMsg(){
        return cy.get('[formcontrolname="subscriberMobileNumbers"] + span')
    }

}
export default deletePage