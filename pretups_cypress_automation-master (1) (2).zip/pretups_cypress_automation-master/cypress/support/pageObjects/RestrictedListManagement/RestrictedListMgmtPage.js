class restrictedListMgmtPage{
    getDeleteToggleBtn(){
        return cy.get('[ng-reflect-value="unbar"]',{timeout:3000})
    }
   
    getDomainDropdown(){
        return cy.get('[formcontrolname="domain"]')
    }

    getDomainDropdownOptions(){
        return cy.get('[formcontrolname="domain"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Corporate "]')
    }

    getCategoryDropdown(){
        return cy.get('[formcontrolname="category"]')
    }

    getCategoryDropdownOptions(){
        return cy.get('[formcontrolname="category"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Corporate Executive "]')
    }

    getGeographyDropdown(){
        return cy.get('[formcontrolname="geography"]')
    }

    getGeographyDropdownOptions(){
        return cy.get('[formcontrolname="geography"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Delhi-Ncr "]')
    }

    getSubscriberTypeDropdown(){
        return cy.get('[formcontrolname="subScribetype"]')
    }

    getSubscriberTypeDropdownOptions(){
        return cy.get('[formcontrolname="subScribetype"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Prepaid Subscriber "]')
    }

    getUserField(){
        return cy.get('[formcontrolname="user"]')
    }

    getSearchBtn(){
        return cy.get('[alt="search"]')
    }

    getUsersOnPopup(){
        return cy.get('.modal-content .searchUser1 > ul :nth-child(1)')
    }

    getDoneBtnOnPopup(){
        return cy.get('.modal-footer > .btn')
    }

    getMultipleRadioBtn(){
        return cy.get('#multiple')
    }

    getAllRadioBtn(){
        return cy.get('#all')
    }

    getSubsMsisdnField(){
        return cy.get('#subscriberMobileNumbers')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getCheckbox(){
        return cy.get('input.td-input-checkbox')    
    }

    getSubsDetailsSubmitBtn(){
        return cy.get('.rounded-btn')
    }

    getMessage(){
        return cy.get('#modal-basic-title-fail .p14Msg',{ timeout: 30000 })
    }

    getPopupDoneBtn(){
        return cy.get('#anotherRecharge')
    }
}
export default restrictedListMgmtPage