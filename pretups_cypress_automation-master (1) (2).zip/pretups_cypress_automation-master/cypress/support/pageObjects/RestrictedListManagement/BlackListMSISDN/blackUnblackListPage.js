class blackUnblackListPage{
    
    getBlackUnblackListScreenHeading(){
        return cy.get('div.operatorHeading',{timeout:5000})
    }

    getBlackListToggleBtn(){
        return cy.get('mat-button-toggle[value="bar"]')
    }

    getUnblackListToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

    getAllCheckboxes(){
        return cy.get('[type="checkbox"]')
    }

    getP2pPayerCheckbox(){
        return cy.get('[formcontrolname="payer"]')
    }

    getP2pPayeeCheckbox(){
        return cy.get('[formcontrolname="payee"]')
    }

    getC2sPayeeCheckbox(){
        return cy.get('[formcontrolname="payee1"]')
    }

    getSingleRadioBtn(){
        return cy.get('[value="single"]')
    }

    getSubscriberMsisdnOnDetailsScreen(){
        return cy.get('tr.denoTableContent')
    }

    //Specific to Unblack msisdn

    getSubscriberMsisdnCheckBox(){
        return cy.get('input.td-input-checkbox')
    }

    //UI Error Messages

    getBlackUnblackListTypeReqdErrorMsg(){
        return cy.get('.row .errorMessage')
    }

    getInvalidMsisdnFormatErrorMsg(){
        return cy.get('#subscriberMobileNumbers + span.errorMessage')
    }
    
}
export default blackUnblackListPage