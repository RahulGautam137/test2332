class approvePage{
    
    getApprovalScreenHeading(){
        return cy.get('label.operatorHeading')
    }

    getApproveScreenProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getSubsApprovalLink(){
        return cy.get('#approveLink',{timeout:3000})
    }

    getYesBtn(){
        return cy.get('button.yes',{timeout:3000})
    }
    
}
export default approvePage