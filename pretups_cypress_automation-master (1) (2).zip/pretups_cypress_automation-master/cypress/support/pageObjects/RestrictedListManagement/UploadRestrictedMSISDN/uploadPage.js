class uploadPage{
  
    getUploadScreenHeading(){
        return cy.get('div.operatorHeading',{timeout:4000})
    }

    getUploadToggleBtn(){
        return cy.get('mat-button-toggle[ng-reflect-value="bar"]')
    }

    getDomainDropdown(){
        return cy.get('[formcontrolname="domain"]')
    }

    getDomainDropdownOptions(){
        return cy.get('[formcontrolname="domain"]').contains(text,"Corporate")
    }

    getCategoryDropdown(){
        return cy.get('[formcontrolname="category"]')
    }

    getCategoryDropdownOptions(){
        return cy.get('[formcontrolname="category"]').contains(text,"Corporate Executive")
    }

    getGeographyDropdown(){
        return cy.get('[formcontrolname="geography"]')
    }

    getGeographyDropdownOptions(){
        return cy.get('[formcontrolname="geography"]').contains(text,"Delhi-Ncr")
    }

    getSubscriberTypeDropdown(){
        return cy.get('[formcontrolname="subScribetype"]')
    }

    getSubscriberTypeDropdownOptions(){
        return cy.get('[formcontrolname="subScribetype"]').contains(text,"Prepaid")
    }

    getUserField(){
        return cy.get('[formcontrolname="user"]')
    }

    getSearchBtn(){
        return cy.get('[alt="search"]')
    }

    getUsersOnPopup(){
        return cy.get('div.modal-content').contains(text,"ranag")
    }

    getDoneBtnOnPopup(){
        return cy.get('.modal-footer > .btn')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getUploadScreenMessage(){
        return cy.get('#modal-basic-title',{ timeout: 3000 })
    }

    getUploadScreenPopupDoneBtn(){
        return cy.get('#doneBtn')
    }

    getChooseFile(){
        return cy.get('label.clickarea')
    }

    getUploadScreenSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getUploadSuccessPopupDoneBtn(){
        return cy.get('#doneBtn')
    }


    //UI Error Messages
    
    getDomainReqErrorMsg(){
        return cy.get('[formcontrolname="domain"] + span')
    }

    getCategoryReqErrorMsg(){
        return cy.get('[formcontrolname="category"] + span')
    }

    getGeographyReqdErrorMsg(){
        return cy.get('[formcontrolname="geography"] + span')
    }

    getUserReqdErrorMsg(){
        return cy.get('.user-search + span')
    }

    getSubsTypeReqdErrorMsg(){
        return cy.get('[formcontrolname="subScribetype"] + span')
    }

    getFileReqdErrorMsg(){
        return cy.get('.invalid-file-format > div')
    }
}
export default uploadPage