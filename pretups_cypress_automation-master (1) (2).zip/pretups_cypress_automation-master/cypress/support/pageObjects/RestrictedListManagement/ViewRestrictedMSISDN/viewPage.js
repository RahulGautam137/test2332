class viewPage{
    
    getViewScreenHeading(){
        return cy.get('label.operatorHeading')
    }

    getDateField(){
        return cy.get('#dateRange')
    }

    getCalendarMonthField(){
        return cy.get('div > select.ui-datepicker-month')
    }

    getCalendarYearField(){
        return cy.get('div > select.ui-datepicker-year')
    }

    getStartDate(){
        return cy.get('tbody.ng-tns-c15-11 > tr > td > a[ng-reflect-klass="ui-state-default"]')
    }

    getEndDate(){
        return cy.get('tbody.ng-tns-c15-11 > tr > td > a[ng-reflect-klass="ui-state-default"]')
    }

    getViewScreenProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getSearchBar(){
        return cy.get('.has-search > .form-control')
    }

    getViewScreenMsisdnColumn(){
        return cy.get('.dataTables_scrollBody table > tbody > tr.denoTableHeader')
    }

    //UI Error Messages
    getDateRangeReqdErrorMsg(){
        return cy.get('.c2cTransferDateClass + span + span')
    }
    
}
export default viewPage