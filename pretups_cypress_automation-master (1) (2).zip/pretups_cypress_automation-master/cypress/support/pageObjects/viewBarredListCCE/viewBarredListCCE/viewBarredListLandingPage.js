class viewBarredListLandingPage{

    getUnbarToggleBtn(){
        return cy.get('[value="UNBAR"]')   
    }

    getAdvancedSearchBtn(){
        return cy.get('[value="advanced"]')
    }

    getDateRange(){
        return cy.get('span.ui-calendar input.ui-inputtext')
    }

    getMonthDropdown(){
        return cy.get('div.ui-datepicker select.ui-datepicker-month')
    }

    getYearDropdown(){
        return cy.get('div.ui-datepicker select.ui-datepicker-year')
    }

    getDates(){
        return cy.get('table.ui-datepicker-calendar > tbody > tr > td > a[ng-reflect-klass="ui-state-default"]')
    }

    getModuleDropdown(){
        return cy.get('[formcontrolname="module"]')
    }

    getModuleDropdownOptions(){
        return cy.get('[formcontrolname="module"] ng-dropdown-panel')
    }

    getBarredAsDropdown(){
        return cy.get('[formcontrolname="barredAs"]')
    }

    getBarredAsDropdownOptions(){
        return cy.get('[formcontrolname="barredAs"] ng-dropdown-panel')
    }

    getBarringTypeDropdown(){
        return cy.get('[formcontrolname="barringType"]')
    }

    getBarringTypeDropdownOptions(){
        return cy.get('[formcontrolname="barringType"] ng-dropdown-panel')
    }

    getProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getBarredListHeading(){
        return cy.get('div.page-Heading span')
    }

    getNoUserInBarredListMsg(){
        return cy.get('.transfer-details-wil')
    }

}

export default viewBarredListLandingPage