class messageManagementBulkPage{
    getBulkProceedBtn(){
        return cy.get('button.save-btn')
    }

    getFileReqdErrMsg(){
        return cy.get('div.invalid-file-format')
    }
    
    getDownloadMsgsListLink(){
        return cy.get('label.download')
    }

    getChooseFile(){
        return cy.get('label.clickarea')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getSuccessMsg(){
        return cy.get('#successfultitle')
    }

    getFailedMsg(){
        return cy.get('#modal-basic-title-fail')
    }
}
export default messageManagementBulkPage 