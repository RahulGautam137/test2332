class messageManagementPage{

    getdefaultMessageTextField(){
        return cy.xpath("//div[@class='msg-in-text ng-tns-c1138916792-11']")
    }

    getMessage1TextField(){
        return cy.xpath("//textarea[@id='message0']")
    }

    getMessage2TextField(){
        return cy.xpath("//textarea[@id='message1']")
    }

    getMessage3TextField(){
        return cy.xpath("//textarea[@id='message2']")
    }

    getMessage4TextField(){
        return cy.xpath("//textarea[@id='message3']")
    }

    getResetButton(){
        return cy.xpath("//button[@name='Reset']")
    }

    getProceedButton(){
        return cy.xpath("//button[@name='Save']")
    } 

    getDoneButton(){
        return cy.xpath("//button[@id='doneBtn']")
    }

    getSuccessPopUpMessage(){
        return cy.xpath("//div[text()=' Message successfully modified. ']")
    }

    getErrorPopUpMessage(){
        return cy.xpath("//div[text()=' Invalid Message contents some special characters. ']")
    }

}
export default messageManagementPage