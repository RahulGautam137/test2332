class messageManagementLandingPage{

    getmessageCodeTextField(){
        return cy.xpath("//input[@name='search']")
    }

    getResetButton(){
        return cy.xpath("//button[@name='Reset']")
    }

    getProceedButton(){
        return cy.xpath("//button[@name='Save']")
    }

    getBlankMessageCodeErrorMessage(){
        return cy.xpath("//span[text()=' Message Code is required']")
    }

    getMsgMgmtHeading(){
        return cy.get('div.operatorHeading')
    }

    getBulkToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

}
export default messageManagementLandingPage