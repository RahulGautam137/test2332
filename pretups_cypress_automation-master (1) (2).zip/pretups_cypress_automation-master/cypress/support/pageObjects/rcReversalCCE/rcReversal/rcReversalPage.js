class rcReversalPage{
    getReverseAmtBtnOnPopup(){
        return cy.get('#recharge')
    }

    getSuccessMsgOnPopup(){
        return cy.get('div.recharge-successful')
    }

    getRcRevTxnId(){
        return cy.get('div.poplabel div.rowpopupspace [id="vals txnidsuccess"]')
    }

    getDoneBtnOnPopup(){
        return cy.get('#anotherRecharge')
    }
}
export default rcReversalPage