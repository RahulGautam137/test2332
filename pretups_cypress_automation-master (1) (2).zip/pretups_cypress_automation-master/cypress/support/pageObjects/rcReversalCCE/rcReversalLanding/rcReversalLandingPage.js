class rcReversalLandingPage{

    getRcReversalHeading(){
        return cy.get('div.recharge-mobile')
    }

    getSearchByDropdown(){
        return cy.get('[formcontrolname="searchby"]')
    }

    getDropdownOptionsText(){
        return cy.get('div.ng-option span')
    }

    getTxnIdMobNumInputField(){
        return cy.get('[formcontrolname="valueof"]')
    }

    getSenderMobNumInputField(){
        return cy.get('[formcontrolname="senderMsisdn"]')
    }

    getProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getSearchCriteriaReqdErrMsg(){
        return cy.get('[formcontrolname="searchby"] + .invalid-feedback')
    }

    getTxnIdMobNumReqdErrMsg(){
        return cy.get('[formcontrolname="valueof"] + .invalid-feedback')
    }

    getSenderMobNumReqdErrMsg(){
        return cy.get('[formcontrolname="senderMsisdn"] + .invalid-feedback')
    }

    getNoRecordMsg(){
        return cy.get('div.transfer-details-wil')
    }

    getReverseAmtLink(){
        return cy.get('td.approveClass .spanClass')
    }

    getRecordRows(){
        return cy.get('tr.denoTableContent')
    }

    getTxnIDColData(){
        return cy.get('table#parentTable tr td:nth-child(1)')
    }

    getActionColLinks(){
        return cy.get('table#parentTable tr td:nth-child(5)')
    }
}
export default rcReversalLandingPage