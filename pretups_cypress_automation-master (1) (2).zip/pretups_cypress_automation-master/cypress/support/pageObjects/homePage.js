class homePage{

    getUsernameCard(){
        return cy.get('li#userdropdown')
    }

    getLogoutOnUsernameCard(){
        return cy.get('#logOut')
    }

    getCoreEtopuptab(){
        return cy.get('#mat-tab-label-1-0 > .mdc-tab__content > .mdc-tab__text-label')
    }

    getEtopupTab(){
        return cy.get('#mat-tab-label-1-0').find('.mat-tab-label-content')
    }

    getApprovalL1Link(){
        return cy.get('[ng-reflect-klass="list-group-item"][ng-reflect-router-link="/approvallevelo2c/ap1"]',{timeout:3000})
    }

    getAppr1RestrictedSubsLink(){
        return cy.get('[ng-reflect-router-link="/focap2"]')
    }

    getSubscriberMgmtLink(){
        return cy.get('.nested-menu > :nth-child(19)')
    }

    getViewRestrictedSubscribersLink(){
        return cy.get('[ng-reflect-router-link="/viewResList"]')
    }

    getRestrictedListMgmtLink(){
        return cy.get('[ng-reflect-router-link="/uplDeltRestList"]')
    }

    getBlackUnblackLink(){
        return cy.get('[ng-reflect-router-link="/blackUnblackListSubscribers"]')
    }

    getCardGroupLink(){
        return cy.get('a > span').contains('Card Group')
    }

    getVoucherCardGrpLink(){
        return cy.get('[ng-reflect-router-link="/cardGroupV2C"]')
    }

    getOperatorUserLink(){
        return cy.get('.nested-menu a[href="/pretups-ui/operatorUser"]')
    }

    getChannelUserLinkCCE(){
        return cy.get('#P_CHNL_USR_MAIN_CCE')
    }

    getUserBarringMgmtLink(){
        return cy.get(':nth-child(4) > #Path16')
    }

    getSrvTypeSelectorMappingLink(){
        return cy.get(':nth-child(13) > #Path16')
    }

    getTransferRulesLink(){
        return cy.get('#P_NW_TRF_RULES_MAIN')
    }

    getC2sTransferRulesLink(){
        return cy.get('#P_NW_TRF_RULES_C2S')
    }

    getIccidKeyMgmtLink(){
        return cy.get('[data-custom-identifier="P_NW_ICCID_IMSI"]')
    }

    getRechargeLinkCCE(){
        return cy.get('#P_RC_MAIN_CCE')
    }

    getRcReversalLinkCCE(){
        return cy.get('#P_RC_RV_CCE')
    }

    getCardGroupLinkCCE(){
        return cy.get('#P_NW_CRDGRP_MAIN_CCE')
    }

    getCalcC2sTrfValueCCE(){
        return cy.get('#P_NW_CHNL_TO_SUB_CCE')
    }

    getRechargeLinkCU(){
        return cy.get('#P_RC_MAIN')
    }

    getRechargeSubLinkCU(){
        return cy.get('#P_RC_RC')
    }

    getServProdIntMappingLink(){
        return cy.get('#P_NW_INTERFACE_MAP')
    }

    getReconciliationLink(){
        return cy.get('#P_NW_RECON_MAIN')
    }

    getO2cReconLink(){
        return cy.get('#P_NW_RECON_O2C')
    }

    getMsgMgmtLink(){
        return cy.get('#P_NW_MSG_MGMT')
    }

    getSubLookupManagementLink(){
        return cy.get("[data-custom-identifier='P_SU_SUBLKP_MAIN']")
    }
    
    getHomeLink(){
        return cy.xpath("//a[@id='P_HOME_MAIN']")
    }

    // Added for Cell ID Management 
    getCellIdMgmtlink(){
        return cy.get("#P_NW_CELLID_MGMTMAIN")
    }

    getCellGroupLink(){
        return cy.get("#P_NW_CELL_MGMT")
    }

    getCellIdCellGrpLink(){
        return cy.get("#P_NW_CELL_ID_ASS")
    }

    // Added for Add Delete Subscriber Routing

    getSubscriberRoutingLink(){
        return cy.get('#P_SU_SUBS_ROUT_MAIN')
    }
 
    getAddRoutingNumberSubscriberRoutingLink(){
        return cy.get('#P_SU_ADD_SUBS_ROUT')
    }
 
    getDeleteRoutingNumberSubscriberRoutingLink(){
        return cy.get('#P_SU_DEL_SUBS_ROUT')
    }
}
export default homePage