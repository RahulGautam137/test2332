class rechargeCuLandingPage{
    getRechargeHeading(){
        return cy.get('div.recharge-mobile')
    }

    getMsisdnInputField(){
        return cy.get('#msisdnInput')
    }

    getAmtInputField(){
        return cy.get('#amountInput')
    }

    getSubServDropdown(){
        return cy.get('#subServiceSelect')
    }

    getDropdownOptionText(){
        return cy.get('div.ng-option span')
    }

    getRechargeBtnOnLandingPage(){
        return cy.get('#recharge')
    }
}
export default rechargeCuLandingPage