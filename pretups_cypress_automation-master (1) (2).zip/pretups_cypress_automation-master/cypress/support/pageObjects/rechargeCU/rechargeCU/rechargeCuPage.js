class rechargeCuPage{
    getPinInputField(){
        return cy.get('#divInner input#no-partitioned')
    }

    getRechargeBtnOnPopup(){
        return cy.get('#rechargebutton2')
    }

    getRechargeSuccessMsgOnPopup(){
        return cy.get('div.recharge-successful')
    }

    getTxnIdOnPopup(){
        return cy.get('[id="vals txnidsuccess"]')
    }

    getDoneBtnOnPopup(){
        return cy.get('#done')
    }
}
export default rechargeCuPage 