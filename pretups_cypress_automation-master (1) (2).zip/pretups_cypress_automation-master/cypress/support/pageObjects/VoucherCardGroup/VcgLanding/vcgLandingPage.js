class vcgLandingPage{
    getVcgHeading(){
        return cy.get('label.operatorHeading')
    }

    getAddVcgBtn(){
        return cy.get('[ng-reflect-klass="add-btn"]')
    }
}
export default vcgLandingPage