class addVcgPage{

    getSubServiceDropdown(){
        return cy.get('ng-select#subService')
    }

    getCgSetName(){
        return cy.get('[formcontrolname="cardGroupName"]')
    }

    getCgSetTypeDropdown(){
        return cy.get('ng-select[formcontrolname="setType"]')
    }

    getApplicableFrom(){
        return cy.get('#time')
    }

    // getCalendarUi(){
    //     return cy.get('.ui-datepicker-calendar')
    // }

    getCurrentDateOnCalendar(){
        return cy.get('tr > td.ui-datepicker-today')
    }

    getHourUpKey(){
        return cy.get('div.ui-hour-picker .pi-chevron-up')
    }

    getCgNameField(){
        return cy.get('[formcontrolname="name"]')
    }

    getCgCodeField(){
        return cy.get('[formcontrolname="code"]')
    }

    getVoucherTypeDropdown(){
        return cy.get('#voucherType')
    }

    getVoucherSegmentDropdown(){
        return cy.get('[formcontrolname="voucherSegment"]')
    }

    getDenominationDropdown(){
        return cy.get('[formcontrolname="denomination"]')
    }

    getDenominationDropdownOption(){
        return cy.get('[formcontrolname="denomination"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option')
    }

    getDenominationProfileDropdown(){
        return cy.get('[formcontrolname="denominationProfile"]')
    }

    getDenominationProfileDropdownOption(){
        return cy.get('[formcontrolname="denominationProfile"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option')
    }

    getTax1UnitDropdown(){
        return cy.get('ng-select#tax1Unit')
    }

    getTaxUnitDropdownOptions(){
        return cy.get('.ng-dropdown-panel')
    }

    getTax1Rate(){
        return cy.get('[formcontrolname="tax1Rate"]')
    }

    getTax2UnitDropdown(){
        return cy.get('ng-select#tax2Unit')
    }

    getTax2Rate(){
        return cy.get('[formcontrolname="tax2Rate"]')
    }

    getProcessingFeeDropdown(){
        return cy.get('ng-select#rate')
    }

    getProcessingFeeInputField(){
        return cy.get('.row [formcontrolname="value"]')
    }

    getMinAmtInputField(){
        return cy.get('[name="minAmt"]')
    }

    getMaxAmtInputField(){
        return cy.get('[name="maxAmt"]')
    }

    getValidityTypeDropdown(){
        return cy.get('ng-select#type')
    }

    getValidityDaysInputField(){
        return cy.get('[name="validitydDays"]')
    }

    getGracePeriodInputField(){
        return cy.get('[formcontrolname="gracePeriod"]')
    }

    // getBonusBenefitsRows(){
    //     return cy.get('tbody.ng-star-inserted')
    // }

    getBonusBundleDropdowns(){
        return cy.get('[formcontrolname="bonusName"]')
    }

    getBonusUnitDropdowns(){
        return cy.get('[formcontrolname="unit"]')
    }

    getBonusValueInputField(){
        return cy.get('table.ng-star-inserted [formcontrolname="value"]')
    }

    getBonusValidityInputField(){
        return cy.get('[formcontrolname="validity"]')
    }

    getBonusBcfInputFields(){
        return cy.get('[formcontrolname="factor"]')
    }

    getSaveCardBtn(){
        return cy.get('button.save-btn')
    }

    getMessageOnPopup(){
        return cy.get('#modal-basic-title')
    }

    getDoneBtnOnMsgPopup(){
        return cy.get('#doneBtn')
    }

    getYesBtnOnPopup(){
        return cy.get('button.yes')
    }

    getSaveCardGrpSetBtn(){
        return cy.get('.footer .save-review-btn-new')
    }

    getMes

}
export default addVcgPage