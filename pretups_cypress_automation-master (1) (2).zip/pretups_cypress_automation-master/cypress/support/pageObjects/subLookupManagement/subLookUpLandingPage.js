class subLookUpLandingPage{
    getLookUpNameDropDown(){
        return cy.xpath("//ng-select[@id='lookup']")
    }

    getProceedButton(){
        return cy.xpath("//button[@name='Proceed']")
    }

    getAddSubLookUp(){
        return cy.xpath("//button[@id='add']")
    }

    getSearchTextBox(){
        return cy.xpath("//input[@name='search']")
    }

    getEditButton(){
        return cy.get('.editRecord')
    }

    getDeleteButton(){
        return cy.get('.deleteRecord')
    }
}
export default subLookUpLandingPage