class addSubLookUpPage {

    getSubLookUpNameTextField(){
        return cy.xpath("//input[@id='subLookUpName']")
    }

    getAddProceedButton(){
        return cy.xpath("//button[@id='doneBtn']")
    }

    getDoneButton(){
        return cy.get('button.done')
    }

    getSuccessMessagePopUp(){
        return cy.get('div.status-change-successful1')
    }

    getYesDeleteButton(){
        return cy.get('button.yes')
    }

    getNoDeleteButton(){
        return cy.xpath("//span[text()='NO']")
    }

    getInvalidLengthMessage(){
        return cy.get('div.errorMessage')
    }

    getDuplicateSubLookupNameError(){
        return cy.xpath("//div[@id='vals failuremsg']")
    }
}

export default addSubLookUpPage