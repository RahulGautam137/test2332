class correctMsisdnIccidMappingPage{
    getModifyBtnPopup2(){
        return cy.get('#rejectConfirmNo')
    }
}

export default correctMsisdnIccidMappingPage