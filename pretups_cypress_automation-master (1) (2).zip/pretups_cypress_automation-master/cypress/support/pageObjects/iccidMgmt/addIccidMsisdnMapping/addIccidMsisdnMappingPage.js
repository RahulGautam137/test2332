class addIccidMsisdnMappingPage{

    getIccidInputField(){
        return cy.get('#iccidImsi')
    }

    getMobNumInputField(){
        return cy.get('#mobileNumber')
    }

    getMappingDetailsAddBtn(){
        return cy.get('#doneBtn')
    }

    getIccidReqdErrMsg(){
        return cy.get('#iccidImsi + .errorMessage > div')
    }

    getMobNumReqdErrMsg(){
        return cy.get('#mobileNumber + .errorMessage > div')
    }

    getMsgOnPopup(){
        return cy.get('#modal-basic-title-fail')
    }

    getMsgPopupDoneBtn(){
        return cy.get('#anotherRecharge')
    }

}
export default addIccidMsisdnMappingPage