class iccidKeyMgmtLandingPage{
    getIccidKeyMgmtHeading(){
        return cy.get('label.barringHeading')
    }

    getAddMappingBtn(){
        return cy.get('div.add-btn')
    }

    getSingleToggleBtn(){
        return cy.get('mat-button-toggle[value="bar"]')
    }

    getBulkToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

    getUploadKeyRadioBtn(){
        return cy.get('input[value="key"]')
    }

    getUploadMsisdnRadioBtn(){
        return cy.get('input[value="number"]')
    }

    getUploadChooseFile(){
        return cy.get('label.clickarea')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getFileReqdErrMsg(){
        return cy.get('div.invalid-file-format')
    }

    getSuccessMsgOnPopup(){
        return cy.get('#successfultitle')
    }

    getUploadKeyToolTipIcon(){
        return cy.get('img[src="assets/images/c2c_icons/gg_info.svg"]')
    }

    getToolTipBox(){
        return cy.get('div.tool-tip-box',{force:true})
    }

    getMobNumSearchByBtn(){
        return cy.get('button[value="Mobile Number"]')
    }

    getIccidSearchByBtn(){
        return cy.get('button[value="ICCID"]')
    }

    getActiveBtn(){
        return cy.get('button.active')
    }

    getMobNumIccidInputField(){
        return cy.get('#name')
    }

    getRecordRowIccid(){
        return cy.get('tr.denoTableContent')
    }

    getDeleteActionBtn(){
        return cy.get('#delete')
    }

    getModifyActionBtn(){
        return cy.get('#editLink')
    }

    getProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getRecordRow(){
        return cy.get('tr.denoTableContent')
    }

    getErrorMsg(){
        return cy.get('div.errorMessage')
    }

}
export default iccidKeyMgmtLandingPage 