class deleteIccidMsisdnMappingPage{

    getDeleteConfirmMsg(){
        return cy.get('span.DeleteReconfirmMsg')
    }

    getYesBtnOnDeletePopup(){
        return cy.get('button.yes')
    }

    getNoBtnOnDeletePopup(){
        return cy.get('.modal-content button').contains('No')
    }

    getDeleteSuccessMsg(){
        return cy.get('#modal-basic-title-fail')
    }

    getDoneBtnOnDeletePopup(){
        return cy.get('#anotherRecharge')
    }

}
export default deleteIccidMsisdnMappingPage