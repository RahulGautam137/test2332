class opUserLandingPage{

    getBulkBtn(){
        return cy.get('button#bulk')
    }

}

export default opUserLandingPage