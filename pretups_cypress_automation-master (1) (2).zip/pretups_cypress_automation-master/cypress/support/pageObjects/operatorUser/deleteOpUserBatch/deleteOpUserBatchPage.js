class deleteOpUserBatchPage{

    getDeleteToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

    getErrMsgOnPopup(){
        return cy.get('#modal-basic-title-fail')
    }

    getEmptyFileErrMsgOnPopup(){
        return cy.get('div.message-failure')
    }

    getDeleteSuccessMsg(){
        return cy.get('#modal-basic-title')
    }

    getViewErrLogLink(){
        return cy.get('#seeMoreId')
    }
}
export default deleteOpUserBatchPage