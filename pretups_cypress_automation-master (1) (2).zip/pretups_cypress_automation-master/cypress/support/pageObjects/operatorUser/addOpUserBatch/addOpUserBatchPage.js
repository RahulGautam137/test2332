class addOpUserBatchPage{

    getAddToggleBtn(){
        return cy.get('mat-button-toggle[value="bar"]')
    }

    getDeleteToggleBtn(){
        return cy.get('mat-button-toggle[value="unbar"]')
    }

    getBatchOpUserHeading(){
        return cy.get('label.operatorHeading')
    }

    getCategoryDropdown(){
        return cy.get('[formcontrolname="category"]')
    }

    getBatchNameField(){
        return cy.get('[formcontrolname="batchName"]')
    }

    getDownloadTemplateBtn(){
        return cy.get('button.download-btn')
    }

    getChooseFile(){
        return cy.get('label.clickarea')
    }

    getSubmitBtn(){
        return cy.get('button.save-btn')
    }

    getConfirmBtnOnPopup(){
        return cy.get('.modal-content button.save-btn')
    }

    getDoneBtnOnPopup(){
        return cy.get('button#doneBtn')
    }

    getDoneBtnOnErrPopup(){
        return cy.get('#anotherRecharge')
    }

    getErrMsg(){
        return cy.get('div.message-failure')
    }

    getCategoryReqdErrMsg(){
        return cy.get('[formcontrolname="category"] + span.errorMessage')
    }

    getBatchNameReqdErrMsg(){
        return cy.get('[formcontrolname="batchName"] + span.errorMessage')
    }

    getFileReqdErrMsg(){
        return cy.get('div.invalid-file-format')
    }
}

export default addOpUserBatchPage