class viewChannelUserLandingPage{

    getHeading(){
        return cy.get('.col-sm-7 > .ng-tns-c18-9')
    }

    getSearchByMsisdnBtn(){
        return cy.get('button[value="mobileNumber"]')
    }

    getSearchByLoginIdBtn(){
        return cy.get('button.sqaureButton').contains('Login ID')
    }

    getSearchByExtCodeBtn(){
        return cy.get('button.sqaureButton').contains('External code')
    }

    getInputField(){
        return cy.get('#name')
    }

    getProceedBtn(){
        return cy.get('button.rounded-btn')
    }

    getRecordRow(){
        return cy.get('.dataTables_scroll').find('.dataTables_scrollBody')
    }

    getUsernameLink(){
        // return cy.get('#parentTable').find('#user_Name')
        return cy.get('.DTFC_LeftBodyLiner > .nowrap > #approvalLevelO2CTableBody > .denoTableHeader > .sorting_1 > #user_Name')
    }

    getErrorMsg(){
        return cy.get('div.errorMessage')
    }

    getNoChannelUserFoundMsg(){
        return cy.get('div.transfer-details-wil')
    }

}
export default viewChannelUserLandingPage