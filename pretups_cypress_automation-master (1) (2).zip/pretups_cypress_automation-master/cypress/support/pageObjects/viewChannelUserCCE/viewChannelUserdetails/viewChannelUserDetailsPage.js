class viewChannelUserDetailsPage{

    getDetailsTab(){
        return cy.get('div.mat-tab-label-content')
    }

    getPhoneNoPrsnlDetailsTab(){
        return cy.get('span.phoneNo')
    }

    getExtCodePrsnlDetailsTab(){
        return cy.get(':nth-child(5) > :nth-child(6) > .value')
    }

    getLoginIdLoginDetailsTab(){
        return cy.get(':nth-child(1) > :nth-child(2) > :nth-child(1) > .value')
    }

    getBalanceHeading(){
        return cy.get('.heading').contains('Balance')
    }

    getBalPrefTable(){
        return cy.get('app-threshold-usage > div:nth-child(1) > div.table-responsive-sm > table')
    }

    getBalPrefTableRows(){
        return cy.get('app-threshold-usage > div:nth-child(1) > div.table-responsive-sm > table > tr')
    }

    getBalPrefTableData(){
        return cy.get('app-threshold-usage > div:nth-child(1) > div.table-responsive-sm > table > tr > td')
    }

    getDailyTcpTableData(){
        return cy.get('app-threshold-usage > div:nth-child(2) > div:nth-child(3) > table > tr > td')
    }

    getWeeklyTcpTableData(){
        return cy.get('app-threshold-usage > div:nth-child(2) > div:nth-child(4) > table > tr > td')
    }

    getMonthlyTcpTableData(){
        return cy.get('app-threshold-usage > div:nth-child(2) > div:nth-child(5) > table > tr > td')
    }


}
export default viewChannelUserDetailsPage