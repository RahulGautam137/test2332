// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add("login", (email, password) => { ... })

// ---------------------IMPORTS--------------------------------
import 'cypress-wait-until';
import loginPage from '../support/pageObjects/loginPage';
import commonEle from "../support/pageObjects/commonElements/commonEle";

// ------------------OBJECT DECLARATION------------------------
const loginScreen = new loginPage();
const commonElements = new commonEle();


Cypress.Commands.add('launchURL', (URL) => {
    cy.visit(URL); 
})

Cypress.Commands.add('login', (Username, Password) => {
    loginScreen.getLoginID().type(Username)
    loginScreen.getPassword().type(Password)
    loginScreen.getLoginBtn().click()
    cy.wait(2000)
})

Cypress.Commands.add('generateRandomMsisdn',(len)=>{
    msisdn=Cypress.env('ggnNwPrefix');
    var possible = "0123456789";
    for (var i = 0; i < len; i++)
        msisdn += possible.charAt(Math.floor(Math.random() * possible.length));
    return msisdn;
})

Cypress.Commands.add('randomName',()=>{
    let randName = 'AUT'+ Math.floor(Math.random() * 10000)
    return randName
})

Cypress.Commands.add('selectValueInDropdown',(dropdown,value)=>{
    dropdown.click()
    commonElements.getDropdownOptions().each(function($ele,index,list){
        if($ele.text().includes(value))
        {
            cy.log('Element found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('Element not found')
        }
    })
})

Cypress.Commands.add('renameFile', ({ originalPath, newPath }) => {
    return cy.task('renameFile', { originalPath, newPath });
  });