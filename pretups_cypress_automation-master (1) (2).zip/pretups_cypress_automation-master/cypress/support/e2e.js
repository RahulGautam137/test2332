// Import commands.js using ES2015 syntax:
import './commands';
import './utils/iccid'
import 'cypress-xpath';
// import './Utils/generic';
// import './Utils/restrictedMsisdn';
// Alternatively you can use CommonJS syntax:
// require('./commands')

module.exports = (on, config) => {
    on("file:preprocessor", cucumber());
  };
  
  Cypress.on('uncaught:exception', (err, runnable)=>{
    return false
  })
  