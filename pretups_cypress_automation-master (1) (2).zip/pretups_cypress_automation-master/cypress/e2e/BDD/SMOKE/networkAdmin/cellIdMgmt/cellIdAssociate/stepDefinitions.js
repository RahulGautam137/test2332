/// <reference types="Cypress" />

// ------------------------IMPORTS------------------------------
import homePage from "../../../../../../support/pageObjects/homePage";
import cellIdCellGrpLandingPage from "../../../../../../support/pageObjects/cellIdManagement/cellIdCellGrpLandingPage";
import commonEle from "../../../../../../support/pageObjects/commonElements/commonEle";
import { Before, Then, When } from "@badeball/cypress-cucumber-preprocessor";
import cellIdData from "../../../../../../fixtures/cellIdMgmt/cellIdData.json"
import '../../../../../../support/commands'

//-------------------------OBJECT DECLARATION-------------------
const homeScreen = new homePage();
const cellIdAssReassScreen = new cellIdCellGrpLandingPage();
const commonElements = new commonEle();

const downloadsPath = "cypress/downloads/";
const cellIdFilePath ="cypress/downloads/cellIdMgmt/";
const invalidFile = "cypress/fixtures/iccid/iccidKey/invalidFileFormat.csv"

//-------------------------QUERIES--------------------------------
const grpIdQuery = "SELECT group_id FROM cell_groups cg where network_code ='NG' and status ='Y' ORDER BY RANDOM() LIMIT 1;"
const cellIdQuery = "select cell_id from cell_ids ci where status <> 'N' and network_code ='NG' ORDER BY RANDOM() LIMIT 1;"
const activeCellIdQuery = "select cell_id from cell_ids ci where status = 'Y' and network_code ='NG' ORDER BY RANDOM() LIMIT 1;"
const suspendedCellIdQuery = "select cell_id from cell_ids ci where status = 'S' and network_code ='NG' ORDER BY RANDOM() LIMIT 1;"


let cellIdFileName;
let oldFilePath;
let newFilePath;
let associateFlag;
let cell_grp_id ;
let successRecords;
let partialSuccessRecords;
let scenario;
let cellIdSrchData = [];
let grpIdData = [];
let numOfRecords;

// Get the current date and time
const timestamp = new Date();
let formattedTimestamp = timestamp.toISOString().replace(/[-:T]/g, '').replace(/\..+/, '');;

//--------------------------------------------------------------

function getRandomCellId() {
    let mscid='';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    for (let i = 0; i < 3; i++) {
      mscid += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    const cellId = Math.floor(10000 + Math.random() * 90000);
    const result = `${mscid}-${cellId}`;
    return result;
  }  

function getRandomSiteId() {
    let text='';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    for (let i = 0; i < 3; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    const num = Math.floor(100 + Math.random() * 900);
    const result = "AUT"+`${text}${num}`;
    return result;
  } 

// ------------------------HOOKS---------------------------------

beforeEach(function(){
    cellIdFileName ="";
    scenario="";
})

// ---------------------------STEPS------------------------------

When('Click on Cell ID Management link',function(){
    homeScreen.getCoreEtopuptab().should('contain.text',this.userData.etopupTabText)
    homeScreen.getCellIdMgmtlink().click();
})

Then('Click on Cell ID - Cell Group link',function(){
    homeScreen.getCellIdCellGrpLink().click();
})

Then('Download template for Cell ID Associate or ReAssociate',function(){
    //Clicking on download template link
    commonElements.getDownloadLink().click()

    cy.wait(8000)

    if (associateFlag) {
        cy.task('fetchLatestDownloadedFile',{fileStarting:"CELLGRP",fileExtension:"XLS",directoryPath:downloadsPath}).then((downloadedFiles)=>{
            cellIdFileName = downloadedFiles
            cy.log("Cell ID Associate File downloaded successfully",cellIdFileName)
        })
    } else {
        cy.task('fetchLatestDownloadedFile',{fileStarting:"CRASSFILE",fileExtension:"XLS",directoryPath:downloadsPath}).then((downloadedFiles)=>{
            cellIdFileName = downloadedFiles
            cy.log("Cell ID Re-Associate File downloaded successfully",cellIdFileName)
        })
    }

})

//Steps for Cell ID associate

Then('Click on Associate Toggle button',function(){
    cy.waitUntil(function(){
        return cellIdAssReassScreen.getCellIdHeading().should('be.visible')
    })

    //Clicking on Associate Toggle button
    commonElements.getLeftToggleBtn().click()
    associateFlag = 1;
})

Then('Associate Cell ID in bulk',function(){
        oldFilePath = downloadsPath+cellIdFileName;
        newFilePath = cellIdFilePath+`cellIdAss${formattedTimestamp}.xls`;
        cy.wait(1500)

        cy.task('queryDatabase',grpIdQuery).then((rows)=>{
            cell_grp_id = rows[0].group_id;
        }).then(function(){
            successRecords = [    
                {
                    "Cell Group ID*":cell_grp_id,
                    "Cell ID*":getRandomCellId(),
                    "Site ID*":getRandomSiteId(),
                    "Site Name*":"Automated Site name "+getRandomSiteId()
                },
                {
                    "Cell Group ID*":cell_grp_id,
                    "Cell ID*":getRandomCellId(),
                    "Site ID*":getRandomSiteId(),
                    "Site Name*":"Automated Site name "+getRandomSiteId()
                }
            ];            
        })
        cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
            cy.wait(1500)
            cy.task('appendDataInExcelWs',{filePath:newFilePath,dataToBeAppended:successRecords});
        })
        cy.wait(3000)
        commonElements.getChooseFile().selectFile(newFilePath)
        cy.wait(3000)
        scenario = "success"

})

Then('Upload invalid data for cell id association',function(){
    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdAssF${formattedTimestamp}.xls`;
    cy.wait(1500)

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('appendDataInExcelWs',{filePath:newFilePath,dataToBeAppended:cellIdData["failRecords"]});
    })
    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "failure"

})

Then('Upload partially valid data for cell id association',function(){
    cy.task('queryDatabase',grpIdQuery).then((rows)=>{
        cell_grp_id = rows[0].group_id;
    }).then(function(){
        partialSuccessRecords = [
            {
                "Cell Group ID*":cell_grp_id,
                "Cell ID*":getRandomCellId(),
                "Site ID*":getRandomSiteId(),
                "Site Name*":"Automated Site name "+getRandomSiteId()
            },
            {
                "Cell Group ID*": "CLGRP000320",
                "Cell ID*": "PVG232",
                "Site ID*": "PVG070681726391",
                "Site Name*": "PVG Comviva Site name 706"
            }
        ];
    })

    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdAssPs${formattedTimestamp}.xls`;
    cy.wait(1500)

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('appendDataInExcelWs',{filePath:newFilePath,dataToBeAppended:partialSuccessRecords});
    })
    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "partialSuccess"

})

Then('Do not upload any file',function(){
    scenario = "fileReqdError"
})

Then('Click on submit button on Cell ID screen',function(){
    cellIdAssReassScreen.getSubmitBtn().click()
})

Then('Upload file in format which is not allowed',function(){
    commonElements.getChooseFile().selectFile(invalidFile)
    scenario = "invalidFile"
})

Then('Verify message',function(){
    if (scenario === 'success') {
        // Assertion for success scenario for cell id associate
        cellIdAssReassScreen.getSuccessMsgOnPopup().should('contain.text',this.messages.cellIdManagement.cellIdAssociateSuccessMsg)
      } else if (scenario === 'partialSuccess') {
        // Assertion for partial success scenario for cell id associate
        cellIdAssReassScreen.getFailMsgOnPopup().should('contain.text',this.messages.cellIdManagement.cellIdAssociatePartialSuccessMsg)
      } else if (scenario === 'failure') {
        // Assertion for failure scenario for cell id associate
        cellIdAssReassScreen.getFailMsgOnPopup().should('contain.text',this.messages.cellIdManagement.cellIdAssociateFailedMsg)
      } else if (scenario === 'fileReqdError'){
        // Assertion for file required error message
        commonElements.getFileReqdErrMsg().should('contain.text',this.iccidKey.messages.fileReqdErrMsg)
      } else if (scenario === 'invalidFile'){
        // Assertion for invalid file uploaded
        commonElements.getFileReqdErrMsg().should('contain.text',this.messages.cellIdManagement.cellIdAssociateInvalidFileMsg)
      } else if(scenario === 'cellIdReassSuccess'){
        // Assertion for success scenario for cell id re-associate , active , suspend , delete
        cellIdAssReassScreen.getSuccessMsgOnPopup().should('contain.text',this.messages.cellIdManagement.cellIdReAssSuccessMsg)
      } else {
        throw new Error('Invalid message displayed');
      }
})

//Steps for Cell ID Re-associate

Then('Click on Re-Associate Toggle button',function(){
    cy.waitUntil(function(){
        return cellIdAssReassScreen.getCellIdHeading().should('be.visible')
    })

    //Clicking on Re-Associate Toggle button
    commonElements.getRightToggleBtn().click()
    associateFlag = 0;
})


Then('Re-Associate Cell ID in bulk',function(){
    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdReAss${formattedTimestamp}.xls`;
    cy.wait(1500)
    
    numOfRecords = 3;
    for (let i = 0; i < numOfRecords; i++) {
        cy.task('queryDatabase',cellIdQuery).then((rows)=>{
            cellIdSrchData.push(rows[0].cell_id)
        }) 

        cy.task('queryDatabase',grpIdQuery).then((rows)=>{
            grpIdData.push(rows[0].group_id)
        }) 
    }

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('appendDataCellIdReAss',{filePath:newFilePath,searchValues:cellIdSrchData,action:'R',cellIdValues:grpIdData})
    })
    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "cellIdReassSuccess"
})

Then('Delete cell id successfully',function(){
    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdDel${formattedTimestamp}.xls`;
    cy.wait(1500)

    numOfRecords = 3;
    for (let i = 0; i < numOfRecords; i++) {
        cy.task('queryDatabase',cellIdQuery).then((rows)=>{
            cellIdSrchData.push(rows[0].cell_id)
        }) 
    }

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('addDataInActionCol',{filePath:newFilePath,searchValues:cellIdSrchData,action:'D'})
    })

    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "cellIdReassSuccess"
})

Then('Suspend cell id successfully',function(){
    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdSus${formattedTimestamp}.xls`;
    cy.wait(1500)

    numOfRecords = 3;
    for (let i = 0; i < numOfRecords; i++) {
        cy.task('queryDatabase',activeCellIdQuery).then((rows)=>{
            cellIdSrchData.push(rows[0].cell_id)
        }) 
    }

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('addDataInActionCol',{filePath:newFilePath,searchValues:cellIdSrchData,action:'S'})
    })

    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "cellIdReassSuccess"
})

Then('Activate cell IDs in bulk successfully',function(){
    oldFilePath = downloadsPath+cellIdFileName;
    newFilePath = cellIdFilePath+`cellIdAct${formattedTimestamp}.xls`;
    cy.wait(1500)

    numOfRecords = 3;
    for (let i = 0; i < numOfRecords; i++) {
        cy.task('queryDatabase',suspendedCellIdQuery).then((rows)=>{
            cellIdSrchData.push(rows[0].cell_id)
        }) 
    }

    cy.renameFile({ originalPath: oldFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('addDataInActionCol',{filePath:newFilePath,searchValues:cellIdSrchData,action:'A'})
    })

    cy.wait(3000)
    commonElements.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    scenario = "cellIdReassSuccess"
})