/// <reference types="Cypress" />

// ------------------------IMPORTS------------------------------
import { Then, When } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../../../support/pageObjects/homePage";
import cellIdCellGrpLandingPage from "../../../../../../support/pageObjects/cellIdManagement/cellIdCellGrpLandingPage";
import cellGrpAddPage from "../../../../../../support/pageObjects/cellIdManagement/cellGrpAddPage";
import "../../../../../../support/commands"
import commonEle from "../../../../../../support/pageObjects/commonElements/commonEle";

//-------------------------OBJECT DECLARATION-------------------
const homeScreen = new homePage();
const cellIdCellGrpLandingScreen = new cellIdCellGrpLandingPage();
const cellGrpAddScreen = new cellGrpAddPage();
const commonElements = new commonEle();

let randCellGrp;
let scenario;
let cell_grp_name;

beforeEach(()=>{
    scenario = "";
})

// ---------------------------------------------------------------
function getRandomCellGrpName() {
    const num = Math.floor(1000 + Math.random() * 9000);
    const result = "AutCellGrp"+`${num}`;
    return result;
  } 

function getRandomCellGrpCode() {
    let text='';
    const possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    for (let i = 0; i < 3; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
    const num = Math.floor(100 + Math.random() * 900);
    const result = `${text}${num}`;
    return result;
  }   

//------------------------------------------------------------------
Then('Click on cell group link',function(){
    homeScreen.getCellGroupLink().click()
    cellIdCellGrpLandingScreen.getCellGrpHeading().should('be.visible')
})

Then('Click on add button on cell group screen',function(){
    cellIdCellGrpLandingScreen.getCellGrpAddBtn().click();
})

Then('Add cell group',function(){
    randCellGrp = getRandomCellGrpName();
    cellGrpAddScreen.getGroupNameInputField().type(randCellGrp);
    cellGrpAddScreen.getGroupCodeInputField().type(getRandomCellGrpCode());
    cy.selectValueInDropdown(cellGrpAddScreen.getStatusDropdown(),"Active")
    scenario = "addCellGrpSuccess";

})

Then('Search for cell group',function(){
    commonElements.getSearchBar().type(randCellGrp)
})

Then('Click on add or modify button on popup',function(){
    cellGrpAddScreen.getAddModifyBtnOnPopup().click()
})

Then('Modify cell group',function(){
    cellGrpAddScreen.getGroupNameInputField().type("M");
    cellGrpAddScreen.getGroupCodeInputField().type("M");
    cy.selectValueInDropdown(cellGrpAddScreen.getStatusDropdown(),"Suspended")
    scenario = "modifyCellGrpSuccess"
})

When('Click on delete action button',function(){
    cellIdCellGrpLandingScreen.getCellGrpDeleteActionBtn().click()
})

Then('Successfully Delete Cell Group',function(){
    cellIdCellGrpLandingScreen.getYesBtnOnDeletePopup().click()
    scenario = "deleteCellGrpSuccess";
})

Then('Click on yes button on delete popup',function(){
    cellIdCellGrpLandingScreen.getYesBtnOnDeletePopup().click()
})

Then('Proceed without entering cell group name',function(){
    cellGrpAddScreen.getGroupCodeInputField().type(getRandomCellGrpCode());
    cy.selectValueInDropdown(cellGrpAddScreen.getStatusDropdown(),"Active");
    scenario = "noCellGrpName";
})

Then('Proceed without entering cell group code',function(){
    cellGrpAddScreen.getGroupNameInputField().type(getRandomCellGrpName());
    cy.selectValueInDropdown(cellGrpAddScreen.getStatusDropdown(),"Active");
    scenario = "noCellGrpCode";
})

Then('Proceed without selecting status',function(){
    cellGrpAddScreen.getGroupNameInputField().type(getRandomCellGrpName());
    cellGrpAddScreen.getGroupCodeInputField().type(getRandomCellGrpCode());
    scenario = "noStatus";
})

Then('Search for cell group already associated with some cell id',function(){
    const query = "SELECT cg.group_name FROM cell_groups cg WHERE EXISTS (SELECT 1 FROM cell_ids ci WHERE ci.group_id = cg.group_id) ORDER BY RANDOM() LIMIT 1;";
    cy.task('queryDatabase',query).then((rows)=>{
        cell_grp_name = rows[0].group_name;
        cy.log(cell_grp_name)
    }).then(function(){
        commonElements.getSearchBar().type(cell_grp_name)
    })
    scenario = "cellIdAssociated"
})


Then('Verify cell group message',function(){
    if (scenario === 'addCellGrpSuccess') {
        cellIdCellGrpLandingScreen.getCellGrpSuccessMsg().should("contain.text",this.messages.cellIdManagement.cellGrpAddSuccessMsg)
    } else if(scenario === 'modifyCellGrpSuccess'){
        cellIdCellGrpLandingScreen.getCellGrpSuccessMsg().should("contain.text",this.messages.cellIdManagement.cellGrpModifySuccessMsg)
    } else if(scenario === 'deleteCellGrpSuccess'){
        cellIdCellGrpLandingScreen.getCellGrpSuccessMsg().should("contain.text",this.messages.cellIdManagement.cellGrpDeleteSuccessMsg)
    } else if(scenario === 'noStatus'){
        commonElements.getErrorMessage().should("contain.text",this.messages.cellIdManagement.cellGrpStatusReqdErrMsg)
    } else if(scenario === 'noCellGrpCode'){
        commonElements.getErrorMessage().should("contain.text",this.messages.cellIdManagement.cellGrpCodeReqdErrMsg)
    } else if(scenario === 'noCellGrpName'){
        commonElements.getErrorMessage().should("contain.text",this.messages.cellIdManagement.cellGrpNameReqdErrMsg)
    } else if(scenario === 'cellIdAssociated'){
        cellIdCellGrpLandingScreen.getCellGrpFailureMsg().should("contain.text",this.messages.cellIdManagement.cellGrpAssociatedWithCellIdErrMsg)
    } else{
        throw new Error('Invalid message displayed');
    }
})