/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Before, Then } from "@badeball/cypress-cucumber-preprocessor";
import iccidKeyMgmtLandingPage from "../../../../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";
import deleteIccidMsisdnMappingPage from "../../../../../../../support/pageObjects/iccidMgmt/deleteIccidMsisdnMapping/deleteIccidMsisdnMappingPage";

//-----------------------OBJECT DECLARATION----------------------
const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();
const deleteIccidMsisdnMappingScreen = new deleteIccidMsisdnMappingPage();

let msisdn = [];
let iccid = [];
let selectedMsisdn;
let selectedIccid;

Before(()=>{
    cy.fixture('messages.json').then(function(messages){
        this.messages = messages
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })
})


Then('Click on Mobile number search by button',function(){
    iccidKeyMgmtLandingScreen.getMobNumSearchByBtn().click()
})

Then('Click on ICCID search by button',function(){
    iccidKeyMgmtLandingScreen.getIccidSearchByBtn().click()
})

Then('Delete ICCID Mapping',function(){

    iccidKeyMgmtLandingScreen.getActiveBtn().invoke('text').then(function(textVisible){

        if(textVisible.includes('Mobile Number')){
            const msisdnQuery = "select msisdn from pos_keys pk where registered ='Y' and msisdn is not null ;"
            cy.task('queryDatabase',msisdnQuery).then((rows)=>{
                expect(rows.length).to.be.greaterThan(0)
                for (let i = 0; i < rows.length; i++) {
                    msisdn.push(rows[i].msisdn)    
                }
            }).then(function(){
                let randomIndex = Math.floor(Math.random() * msisdn.length);
                selectedMsisdn = msisdn[randomIndex];
                iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedMsisdn)
            })
        }
        else if(textVisible.includes('ICCID')){
            const iccidQuery = "select icc_id from pos_keys pk where registered ='Y' and msisdn is not null ;"
            cy.task('queryDatabase',iccidQuery).then((rows)=>{
                expect(rows.length).to.be.greaterThan(0)
                for (let i = 0; i < rows.length; i++) {
                    iccid.push(rows[i].icc_id)    
                }
            }).then(function(){
                let randomIndex = Math.floor(Math.random() * iccid.length);
                selectedIccid = iccid[randomIndex];
                iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
            })
        }
        
    })
})


Then('Verify record and delete ICCID Mapping',function(){

    iccidKeyMgmtLandingScreen.getActiveBtn().invoke('text').then(function(textVisible){  
        if(textVisible.includes('Mobile Number')){
    
            iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedMsisdn)
            iccidKeyMgmtLandingScreen.getDeleteActionBtn().click()
            deleteIccidMsisdnMappingScreen.getDeleteConfirmMsg().should('contain.text',selectedMsisdn)
            deleteIccidMsisdnMappingScreen.getYesBtnOnDeletePopup().click()
            deleteIccidMsisdnMappingScreen.getDeleteSuccessMsg().should('contain.text',this.messages.iccid.iccidDeleteSuccessMsg)

            const deletedMsisdnQuery = "select * from pos_keys pk where msisdn ='"+selectedMsisdn+"';";
            
            cy.task('queryDatabase',deletedMsisdnQuery).then((rows)=>{
                expect(rows.length).to.be.eq(0)
            })
        }
        else if(textVisible.includes('ICCID')){
            iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedIccid)
            iccidKeyMgmtLandingScreen.getDeleteActionBtn().click()
            deleteIccidMsisdnMappingScreen.getDeleteConfirmMsg().should('contain.text',selectedIccid)
            deleteIccidMsisdnMappingScreen.getYesBtnOnDeletePopup().click()
            deleteIccidMsisdnMappingScreen.getDeleteSuccessMsg().should('contain.text',this.messages.iccid.iccidDeleteSuccessMsg)
            deleteIccidMsisdnMappingScreen.getDeleteSuccessMsg().should('contain.text',selectedIccid)

            const deletedIccidQuery = "select * from pos_keys pk where msisdn ='"+selectedIccid+"';";
            
            cy.task('queryDatabase',deletedIccidQuery).then((rows)=>{
                expect(rows.length).to.be.eq(0)
            })
        }

    })
    
})

Then('Verify error message',function(){
    iccidKeyMgmtLandingScreen.getActiveBtn().invoke('text').then(function(textVisible){  
        if(textVisible.includes('Mobile Number')){
            iccidKeyMgmtLandingScreen.getErrorMsg().should('contain.text',this.messages.iccid.mobNumReqdErrMsg)
        }
        else if(textVisible.includes('ICCID')){
            iccidKeyMgmtLandingScreen.getErrorMsg().should('contain.text',this.messages.iccid.iccidReqdErrMsg)
        }
    })
})