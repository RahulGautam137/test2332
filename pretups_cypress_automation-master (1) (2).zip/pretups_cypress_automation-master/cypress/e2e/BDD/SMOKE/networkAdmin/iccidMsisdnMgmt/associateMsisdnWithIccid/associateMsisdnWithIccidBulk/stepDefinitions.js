/// <reference types="Cypress" />

// ------------------------IMPORTS------------------------------
import { Then, Before } from "@badeball/cypress-cucumber-preprocessor";
import iccidKeyMgmtLandingPage from "../../../../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";
import '../../../../../../../support/utils/iccid'

// ------------------------OBJECT DECLARATION----------------------
const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();

let iccidArray =[]
let usedIndices = [];

const iccidTxtFilePath = "cypress/fixtures/iccid/associateIccidMsisdnBulk/"
const iccidBulkDataFilePath = 'cypress/fixtures/iccid/associateIccidMsisdnBulk/iccidMsisdnBulk.json'

Before(()=>{
    cy.fixture('iccid/associateIccidMsisdnBulk/iccidMsisdnBulk.json').then(function(iccidMsisdnBulk){
        this.iccidMsisdnBulk = iccidMsisdnBulk
    })

    cy.fixture('iccid/iccidKey/iccidKey.json').then(function(iccidKey){
        this.iccidKey = iccidKey
    })

})


Then('Click on Upload Mobile Number radio button',function(){
    iccidKeyMgmtLandingScreen.getUploadMsisdnRadioBtn().click();
})

Then('Click on Bulk Toggle button on upload key screen',function(){
    iccidKeyMgmtLandingScreen.getIccidKeyMgmtHeading().should('be.visible')
    iccidKeyMgmtLandingScreen.getBulkToggleBtn().click();
})

Then('Enter ICCID and MSISDN in a text file',function(){
    const query = "select * from pos_keys where registered ='Y' and msisdn is null ;"
    cy.task('queryDatabase',query).then((rows)=>{
        for (let index = 0; index < rows.length; index++) {
            iccidArray.push(rows[index].icc_id)    
        }
    }).then(()=>{

        if(this.iccidMsisdnBulk.iccidMsisdnBulkFilePath === ""){
            cy.randomName().then((value)=>{
                const filePath = iccidTxtFilePath+value+'UploadMsisdnBulk.txt'
                cy.writeFile(filePath,"")

                for (let i = 0; i < this.iccidMsisdnBulk.numOfRecords; i++){
                    let randomIndex;
                    do {
                        randomIndex = Math.floor(Math.random() * iccidArray.length);
                    } while (usedIndices.includes(randomIndex)); // Keep generating random indices until a unique one is found
                
                    usedIndices.push(randomIndex); // Add the index to the list of used indices
                    
                    if(i==0){
                        cy.generateIccidMsisdn1(Cypress.env('mobileDigits'),iccidArray[randomIndex],filePath)
                    }
                    else{
                        cy.generateIccidMsisdn2(Cypress.env('mobileDigits'),iccidArray[randomIndex],filePath)
                    }
                }

                cy.readFile(iccidBulkDataFilePath).then((data)=>{
                    data.iccidMsisdnBulkFilePath = filePath
                    cy.writeFile(iccidBulkDataFilePath,data)
                })
                iccidKeyMgmtLandingScreen.getUploadChooseFile().selectFile(filePath)
            })
        }
        else{
            cy.randomName().then((value)=>{

                const originalPath = this.iccidMsisdnBulk.iccidMsisdnBulkFilePath;
                const newPath = 'cypress/fixtures/iccid/associateIccidMsisdnBulk/'+value+ 'UploadMsisdnBulk.txt';
            
                cy.task('renameFile', { originalPath, newPath }).then(() => {
                    cy.readFile(iccidBulkDataFilePath).then((data)=>{
                        data.iccidMsisdnBulkFilePath = newPath
                        cy.writeFile(iccidBulkDataFilePath,data)
                    })

                    for (let i = 0; i < this.iccidMsisdnBulk.numOfRecords; i++){
                        let randomIndex;
                        do {
                            randomIndex = Math.floor(Math.random() * iccidArray.length);
                        } while (usedIndices.includes(randomIndex)); // Keep generating random indices until a unique one is found
                    
                        usedIndices.push(randomIndex); // Add the index to the list of used indices

                        if(i==0){
                            cy.generateIccidMsisdn1(Cypress.env('mobileDigits'),iccidArray[randomIndex],newPath)
                        }
                        else{
                            cy.generateIccidMsisdn2(Cypress.env('mobileDigits'),iccidArray[randomIndex],newPath)
                        }
                    }    

                    cy.readFile(iccidBulkDataFilePath).then((data)=>{
                        data.iccidMsisdnBulkFilePath = newPath
                        cy.writeFile(iccidBulkDataFilePath,data)
                    })
    
                iccidKeyMgmtLandingScreen.getUploadChooseFile().selectFile(newPath)
                })
            })
        }
    })
        cy.wait(2000)
        iccidKeyMgmtLandingScreen.getSubmitBtn().click()
        iccidKeyMgmtLandingScreen.getSuccessMsgOnPopup().should('contain.text',this.iccidMsisdnBulk.messages.successMsg)
    })
