/// <reference types="Cypress" />

// ------------------------IMPORTS------------------------------
import { Then,Before } from "@badeball/cypress-cucumber-preprocessor";
import iccidKeyMgmtLandingPage from "../../../../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";
import '../../../../../../../support/utils/iccid'

// ------------------------OBJECT DECLARATION----------------------
const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();

const iccidKeyFile = "cypress/fixtures/iccid/iccidKey/iccidKey.json";
const iccidTxtFilePath = "cypress/fixtures/iccid/iccidKey/iccidKey.txt"
const invalidFormatFilePath = "cypress/fixtures/iccid/iccidKey/invalidFileFormat.csv"

Before(()=>{
    cy.fixture('iccid/iccidKey/iccidKey.json').then(function(iccidKey){
        this.iccidKey = iccidKey
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })
})


Then('Click on Bulk Toggle button',function(){
    iccidKeyMgmtLandingScreen.getIccidKeyMgmtHeading().should('be.visible')
    iccidKeyMgmtLandingScreen.getBulkToggleBtn().click();
})

Then('Click on Upload Key radio button',function(){
    iccidKeyMgmtLandingScreen.getUploadKeyRadioBtn().click();
})

Then('Add ICCID and Decryption key in txt file',function(){
        if(this.iccidKey.iccidFilePath === ""){
            cy.writeFile(iccidTxtFilePath,"")
            cy.generateIccidDecKeyPair(this.iccidKey.numOfRecords,this.iccidKey.iccidLen,this.iccidKey.decKeyLen,iccidTxtFilePath)
            cy.randomName().then((value)=>{
                const originalPath = iccidTxtFilePath;
                const newPath = 'cypress/fixtures/iccid/iccidKey/'+value+ '.txt';
                cy.task('renameFile', { originalPath, newPath }).then(() => {
                    cy.readFile(iccidKeyFile).then((data)=>{
                        data.iccidFilePath = newPath
                        cy.writeFile(iccidKeyFile,data)
                    })
                })
            iccidKeyMgmtLandingScreen.getUploadChooseFile().selectFile(newPath)
            })
        }

        else{
        cy.randomName().then((value)=>{
            const originalPath = this.iccidKey.iccidFilePath;
            const newPath = 'cypress/fixtures/iccid/iccidKey/'+value+ 'iccid.txt';
            cy.task('renameFile', { originalPath, newPath }).then(() => {
                cy.readFile(iccidKeyFile).then((data)=>{
                    data.iccidFilePath = newPath
                    cy.writeFile(iccidKeyFile,data)
                })
            })
            cy.generateIccidDecKeyPair(this.iccidKey.numOfRecords,this.iccidKey.iccidLen,this.iccidKey.decKeyLen,newPath)

        iccidKeyMgmtLandingScreen.getUploadChooseFile().selectFile(newPath)
        })
        }
    
    cy.wait(3000)
    iccidKeyMgmtLandingScreen.getSubmitBtn().click()
    iccidKeyMgmtLandingScreen.getSuccessMsgOnPopup().should('contain.text',this.iccidKey.messages.successMsg)
})

Then('Proceed without uploading text file',function(){
    iccidKeyMgmtLandingScreen.getSubmitBtn().click()
    iccidKeyMgmtLandingScreen.getFileReqdErrMsg().should('contain.text',this.iccidKey.messages.fileReqdErrMsg)
})

Then('Proceed with invalid file format',function(){
    iccidKeyMgmtLandingScreen.getUploadChooseFile().selectFile(invalidFormatFilePath)
    iccidKeyMgmtLandingScreen.getSubmitBtn().click()
    iccidKeyMgmtLandingScreen.getFileReqdErrMsg().contains(this.iccidKey.messages.invalidFileFormatErrMsg,{matchCase:false})
})