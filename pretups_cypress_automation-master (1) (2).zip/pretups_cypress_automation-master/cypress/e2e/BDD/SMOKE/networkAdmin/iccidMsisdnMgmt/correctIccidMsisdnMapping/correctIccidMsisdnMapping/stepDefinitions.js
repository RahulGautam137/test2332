/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Before, Then } from "@badeball/cypress-cucumber-preprocessor";
import iccidKeyMgmtLandingPage from "../../../../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";
import addIccidMsisdnMappingPage from "../../../../../../../support/pageObjects/iccidMgmt/addIccidMsisdnMapping/addIccidMsisdnMappingPage";
import correctMsisdnIccidMappingPage from "../../../../../../../support/pageObjects/iccidMgmt/correctMsisdnIccidMapping/correctMsisdnIccidMappingPage";

//-----------------------OBJECT DECLARATION----------------------
const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();
const addIccidMsisdnMappingScreen = new addIccidMsisdnMappingPage();
const correctMsisdnIccidMappingScreen = new correctMsisdnIccidMappingPage();

let msisdn = [];
let iccid = [];
let selectedIccid;
let selectedMsisdn;

Before(()=>{
    cy.fixture('messages.json').then(function(messages){
        this.messages = messages
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })
})

Then('Correct ICCID Mapping when ICCID and MSISDN are not associated with any other MSISDN and ICCID',function(){
    const iccidQuery = "select icc_id from pos_keys where registered ='Y' and msisdn is null ;";
    const msisdnQuery = "select msisdn from pos_keys where registered ='Y' and msisdn is not null ;";

    cy.task('queryDatabase',iccidQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                iccid.push(rows[i].icc_id)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * iccid.length);
        selectedIccid = iccid[randomIndex];
        iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
        iccidKeyMgmtLandingScreen.getProceedBtn().click()
        iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedIccid)
    })

    iccidKeyMgmtLandingScreen.getModifyActionBtn().click()

    cy.task('queryDatabase',msisdnQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                msisdn.push(rows[i].msisdn)    
        }
    }).then(function(){
        cy.generateRandomMsisdn(Cypress.env('mobileDigits')).then((mobNum)=>{
            do {
                // MSISDN which is not associated with any ICCID
                selectedMsisdn = mobNum
            } while (msisdn.includes(selectedMsisdn));

            addIccidMsisdnMappingScreen.getMobNumInputField().type(selectedMsisdn)
        })
    })

    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click() 
    correctMsisdnIccidMappingScreen.getModifyBtnPopup2().click()
    addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.messages.iccid.correctIccidMappingAdded)
    
})

Then('Correct ICCID Mapping when entered MSISDN is already associated with other ICCID and Entered ICCID is free to use',function(){
    const iccidQuery = "select icc_id from pos_keys where registered ='Y' and msisdn is null ;";
    const msisdnQuery = "select msisdn from pos_keys where registered ='Y' and msisdn is not null ;";

    cy.task('queryDatabase',iccidQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                iccid.push(rows[i].icc_id)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * iccid.length);
        selectedIccid = iccid[randomIndex];
        iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
        iccidKeyMgmtLandingScreen.getProceedBtn().click()
        iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedIccid)
    })

    iccidKeyMgmtLandingScreen.getModifyActionBtn().click()

    cy.task('queryDatabase',msisdnQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                msisdn.push(rows[i].msisdn)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * msisdn.length);
        selectedMsisdn = msisdn[randomIndex];
        addIccidMsisdnMappingScreen.getMobNumInputField().type(selectedMsisdn)
    })

    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click() 
    correctMsisdnIccidMappingScreen.getModifyBtnPopup2().click()
    addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.messages.iccid.correctIccidMappingModified)
    
})

Then('Correct ICCID Mapping when entered ICCID is already associated with other MSISDN and Entered MSISDN is free to use',function(){
    const iccidQuery = "select icc_id from pos_keys where registered ='Y' and msisdn is not null ;";
    const msisdnQuery = "select msisdn from pos_keys where registered ='Y' and msisdn is not null ;";

    cy.task('queryDatabase',iccidQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                iccid.push(rows[i].icc_id)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * iccid.length);
        selectedIccid = iccid[randomIndex];
        iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
        iccidKeyMgmtLandingScreen.getProceedBtn().click()
        iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedIccid)
    })

    iccidKeyMgmtLandingScreen.getModifyActionBtn().click()

    cy.task('queryDatabase',msisdnQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                msisdn.push(rows[i].msisdn)    
        }
    }).then(function(){
        cy.generateRandomMsisdn(Cypress.env('mobileDigits')).then((mobNum)=>{
            do {
                // MSISDN which is not associated with any ICCID
                selectedMsisdn = mobNum
            } while (msisdn.includes(selectedMsisdn));

            addIccidMsisdnMappingScreen.getMobNumInputField().type(selectedMsisdn)
        })
    })

    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click() 
    correctMsisdnIccidMappingScreen.getModifyBtnPopup2().click()
    addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.messages.iccid.correctIccidMappingModified)
    
})

Then('Correct ICCID Mapping when entered ICCID and MSISDN are already associated with other MSISDN and ICCID',function(){
    const iccidQuery = "select icc_id from pos_keys where registered ='Y' and msisdn is not null ;";
    const msisdnQuery = "select msisdn from pos_keys where registered ='Y' and msisdn is not null ;";

    cy.task('queryDatabase',iccidQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                iccid.push(rows[i].icc_id)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * iccid.length);
        selectedIccid = iccid[randomIndex];
        iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
        iccidKeyMgmtLandingScreen.getProceedBtn().click()
        iccidKeyMgmtLandingScreen.getRecordRow().should('contain.text',selectedIccid)
    })

    iccidKeyMgmtLandingScreen.getModifyActionBtn().click()

    cy.task('queryDatabase',msisdnQuery).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                msisdn.push(rows[i].msisdn)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * msisdn.length);
        selectedMsisdn = msisdn[randomIndex];
        addIccidMsisdnMappingScreen.getMobNumInputField().type(selectedMsisdn)
    })
    
    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click() 
    correctMsisdnIccidMappingScreen.getModifyBtnPopup2().click()
    addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.messages.iccid.correctIccidMappingModified)
    
})

Then('Verify data in database',function(){
    const query = "select icc_id,msisdn from pos_keys pk where icc_id ='"+selectedIccid+"' and msisdn ='"+selectedMsisdn+"';"
    cy.task('queryDatabase',query).then((rows)=>{
        expect(rows.length).to.be.greaterThan(0)
        expect(selectedIccid).to.eq(rows[0].icc_id)
        expect(selectedMsisdn).to.eq(rows[0].msisdn)
    })
})

Then('Search for ICCID',function(){
    const iccidQuery1 = "select icc_id from pos_keys where registered ='Y' ;";
    cy.task('queryDatabase',iccidQuery1).then((rows)=>{
        for (let i = 0; i < rows.length; i++) {
                iccid.push(rows[i].icc_id)    
        }
    }).then(function(){
        let randomIndex = Math.floor(Math.random() * iccid.length);
        selectedIccid = iccid[randomIndex];
        iccidKeyMgmtLandingScreen.getMobNumIccidInputField().type(selectedIccid)
    })
})

Then('Click on proceed button on ICCID landing screen',function(){
    iccidKeyMgmtLandingScreen.getProceedBtn().click()
})

Then('Click on modify action button',function(){
    iccidKeyMgmtLandingScreen.getModifyActionBtn().click()
})

Then('Verify ICCID required error message',function(){
    addIccidMsisdnMappingScreen.getIccidInputField().clear()
    iccidKeyMgmtLandingScreen.getErrorMsg().should('contain.text',this.messages.iccid.correctIccidReqdErrMsg)
})

Then('Verify MSISDN required error message',function(){
    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click() 
    iccidKeyMgmtLandingScreen.getErrorMsg().should('contain.text',this.messages.iccid.correctMobNumReqdErrMsg)
})