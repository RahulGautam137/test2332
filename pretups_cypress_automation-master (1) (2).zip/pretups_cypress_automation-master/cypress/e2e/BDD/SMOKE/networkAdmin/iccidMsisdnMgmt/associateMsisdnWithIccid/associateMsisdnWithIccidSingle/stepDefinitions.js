/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Before, Then, When } from "@badeball/cypress-cucumber-preprocessor";
import addIccidMsisdnMappingPage from "../../../../../../../support/pageObjects/iccidMgmt/addIccidMsisdnMapping/addIccidMsisdnMappingPage";
import iccidKeyMgmtLandingPage from "../../../../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";

//-----------------------OBJECT DECLARATION----------------------
const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();
const addIccidMsisdnMappingScreen = new addIccidMsisdnMappingPage();

let iccid = [];
const associateIccidDataFile = 'cypress/fixtures/iccid/associateIccidMsisdnSingle/associateIccid.json'

Before(()=>{
    cy.fixture('iccid/associateIccidMsisdnSingle/associateIccid.json').then(function(associateIccidData){
        this.associateIccidData = associateIccidData
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })
})


When('Click on add mapping button',function(){
    iccidKeyMgmtLandingScreen.getIccidKeyMgmtHeading().should('be.visible')
    iccidKeyMgmtLandingScreen.getAddMappingBtn().click()
})

Then('Enter ICCID',function(){
    const query = "select icc_id from pos_keys where msisdn is null ;"
    cy.task('queryDatabase',query).then((rows)=>{
        for (let index = 0; index < rows.length; index++) {
            iccid.push(rows[index].icc_id)    
        }
    }).then(()=>{
        cy.log(iccid.length)
        let randomIndex = Math.floor(Math.random() * iccid.length);
        let selectedIccid = iccid[randomIndex];
        addIccidMsisdnMappingScreen.getIccidInputField().type(selectedIccid)
    })
})

Then('Enter Msisdn',function(){
    cy.generateRandomMsisdn(8).then((msisdnToBeAssociated)=>{
        addIccidMsisdnMappingScreen.getMobNumInputField().type(msisdnToBeAssociated)
        cy.readFile(associateIccidDataFile).then((mobNum)=>{
            mobNum.associatedIccidMsisdnPair.msisdn = msisdnToBeAssociated 
            cy.writeFile(associateIccidDataFile,mobNum)
        })

    })
})

Then('Click on add button on add mapping screen',function(){
    addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click()
})

Then('Verify Success Message',function(){
    addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.associateIccidData.messages.mapSucessMsg)
})

Then('Verify error message for ICCID Required',function(){
    addIccidMsisdnMappingScreen.getIccidReqdErrMsg().should('contain.text',this.associateIccidData.messages.iccidReqdErrMsg)
})

Then('Verify error message for MSISDN Required',function(){
    addIccidMsisdnMappingScreen.getMobNumReqdErrMsg().should('contain.text',this.associateIccidData.messages.mobNumReqdErrMsg)
})