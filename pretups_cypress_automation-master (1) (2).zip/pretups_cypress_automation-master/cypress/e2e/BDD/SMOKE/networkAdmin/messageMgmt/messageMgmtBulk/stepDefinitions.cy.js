/// <reference types="Cypress" />

//-----------------IMPORTS------------------------
import { Before, Then } from "@badeball/cypress-cucumber-preprocessor";
import '../../../../../../support/commands'
import messageManagementLandingPage from "../../../../../../support/pageObjects/messageManagement/messageManagementLandingPage";
import msgMgmtData from '../../../../../../fixtures/msgMgmt/msgMgmtData.json'
import messageManagementBulkPage from "../../../../../../support/pageObjects/messageManagement/messageManagementBulkPage";

//-----------------OBJECT DECLARATION-----------------------
const msgMgmtLandingScreen = new messageManagementLandingPage();
const messageManagementBulkScreen = new messageManagementBulkPage();

const msgMgmtDownloadsPath = "cypress/downloads/";
const modifiedFilePath ="cypress/downloads/bulkMsgMgmt/";
let msgListFileName ;
let finalFilePath;
let newFilePath;

// Get the current date and time
const timestamp = new Date();

let formattedTimestamp;


Before(function(){
    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })

    cy.fixture('messages.json').then(function(messages){
        this.messages = messages
    })

    cy.fixture('msgMgmt/msgMgmt.json').then(function(msgMgmt){
        this.msgMgmt = msgMgmt
    })
})

beforeEach(function(){
    msgListFileName ="";
    formattedTimestamp = timestamp.toISOString().replace(/[-:T]/g, '').replace(/\..+/, '');
})

Then('Click on bulk toggle button',function(){
   msgMgmtLandingScreen.getBulkToggleBtn().click()
})

Then('Download Messages File',function(){
    cy.waitUntil(function(){
        return messageManagementBulkScreen.getDownloadMsgsListLink().should('be.visible')
    })
    
    messageManagementBulkScreen.getDownloadMsgsListLink().click()
    cy.wait(8000)

    cy.task('fetchLatestDownloadedFile',{fileStarting:"messageList",fileExtension:".xls",directoryPath:msgMgmtDownloadsPath}).then((downloadedFiles)=>{
        msgListFileName = downloadedFiles
        cy.log("File downloaded successfully",msgListFileName)
    })
})

Then('Upload modified file and verify success message',function(){
    finalFilePath = msgMgmtDownloadsPath+msgListFileName;
    newFilePath = modifiedFilePath+`msgListS${formattedTimestamp}.xls`;
    cy.wait(1500)
    cy.renameFile({ originalPath: finalFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('appendDataInExcelWs',{filePath:newFilePath,msgMgmtData:msgMgmtData["successRecords"]});
    })
    cy.wait(3000)
    messageManagementBulkScreen.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    messageManagementBulkScreen.getSubmitBtn().click().then(function(){
        messageManagementBulkScreen.getSuccessMsg().should('contain.text',this.messages.messageManagement.msgBulkFileUploadSuccessMsg)
    })
})

Then('Upload modified file and verify partial success message',function(){
    finalFilePath = msgMgmtDownloadsPath+msgListFileName;
    cy.log(msgListFileName)
    newFilePath = modifiedFilePath+`msgListPs${formattedTimestamp}.xls`;
    cy.wait(1500)
    cy.renameFile({ originalPath: finalFilePath, newPath: newFilePath }).then(function(){
        cy.wait(1500)
        cy.task('appendDataInExcelWs',{filePath:newFilePath,msgMgmtData:msgMgmtData["partialSuccessRecords"]});
    })
    cy.wait(3000)
    messageManagementBulkScreen.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    messageManagementBulkScreen.getSubmitBtn().click().then(function(){
        messageManagementBulkScreen.getFailedMsg().should('contain.text',this.messages.messageManagement.msgBulkFileUploadPartialSuccessMsg)
    })
})

Then('Upload modified file and verify failure message',function(){
    finalFilePath = msgMgmtDownloadsPath+msgListFileName;
        newFilePath = modifiedFilePath+`msgListF${formattedTimestamp}.xls`;
        cy.wait(1500)
        cy.renameFile({ originalPath: finalFilePath, newPath: newFilePath }).then(function(){
            cy.wait(1500) 
            cy.task('appendDataInExcelWs',{filePath:newFilePath,msgMgmtData:msgMgmtData["failedRecords"]});
        })
    cy.wait(3000)
    messageManagementBulkScreen.getChooseFile().selectFile(newFilePath)
    cy.wait(3000)
    messageManagementBulkScreen.getSubmitBtn().click().then(function(){
        messageManagementBulkScreen.getFailedMsg().should('contain.text',this.messages.messageManagement.msgBulkFileUploadFailMsg)
    })
})

Then('Click on submit button',function(){
    messageManagementBulkScreen.getBulkProceedBtn().click();
})

Then('Verify file required error message',function(){
    messageManagementBulkScreen.getFileReqdErrMsg().should('contain.text',this.messages.messageManagement.fileReqdErrMsg)
})