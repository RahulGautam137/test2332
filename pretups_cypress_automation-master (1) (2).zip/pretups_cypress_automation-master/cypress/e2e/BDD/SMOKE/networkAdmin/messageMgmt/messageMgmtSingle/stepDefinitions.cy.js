/// <reference types="Cypress" />

//-----------------IMPORTS------------------------
import { Before, Then, When} from "@badeball/cypress-cucumber-preprocessor";
import messageManagementPage from "../../../../../../support/pageObjects/messageManagement/messageManagementPage";
import messageManagementLandingPage from "../../../../../../support/pageObjects/messageManagement/messageManagementLandingPage";
import homePage from "../../../../../../support/pageObjects/homePage";

//-----------------OBJECT DECLARATION-----------------------
const homeScreen = new homePage();
const messageManagementPage1 = new messageManagementPage();
const messageManagementHomePage = new messageManagementLandingPage();

Before(function(){
    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })

    cy.fixture('messages.json').then(function(messages){
        this.messages = messages
    })

    cy.fixture('msgMgmt/msgMgmt.json').then(function(msgMgmt){
        this.msgMgmt = msgMgmt
    })
})

When("Click on Message Management link",function(){  
    homeScreen.getCoreEtopuptab().should('contain.text',this.userData.etopupTabText)
    homeScreen.getMsgMgmtLink().click()
    cy.waitUntil(function(){
        return cy.get('div.operatorHeading').should('be.visible')
    })
    cy.get('div.operatorHeading').should("contain.text",this.msgMgmt.msgMgmtHeading)
})

Then("Enter Message Code",function(){
    messageManagementHomePage.getmessageCodeTextField().type(this.msgMgmt.msgCode)
    messageManagementHomePage.getProceedButton().click()
})

Then("Enter Messages",function(){
    messageManagementPage1.getMessage1TextField().clear()
    messageManagementPage1.getMessage1TextField().type(this.msgMgmt.msgTextData1)
    messageManagementPage1.getMessage2TextField().clear()
    messageManagementPage1.getMessage2TextField().type(this.msgMgmt.msgTextData1)
    messageManagementPage1.getMessage3TextField().clear()
    messageManagementPage1.getMessage3TextField().type(this.msgMgmt.msgTextData2)
    messageManagementPage1.getMessage4TextField().clear()
    messageManagementPage1.getMessage4TextField().type(this.msgMgmt.msgTextData2)
    messageManagementPage1.getProceedButton().click()
})

Then("Click on Done button in success message popup",function(){
    messageManagementPage1.getDoneButton().click()
    messageManagementPage1.getSuccessPopUpMessage().should('contain.text', this.messages.messageManagement.msgModifiedSuccessMsg)
})

Then('Click on proceed button',function(){
    messageManagementHomePage.getProceedButton().click()
    
})

Then("Verify error message for Message Code Required",function(){
    messageManagementHomePage.getBlankMessageCodeErrorMessage().should('contain.text',this.messages.messageManagement.msgCodeReqdErrMsg)
})

Then("Enter invalid Message1",function(){
    messageManagementPage1.getMessage1TextField().clear()
    messageManagementPage1.getMessage1TextField().type(this.msgMgmt.msgInvalidData)
    messageManagementPage1.getProceedButton().click()
})
Then("Verify error message for Invalid Message",function(){
    messageManagementPage1.getErrorPopUpMessage().should('contain.text', this.messages.messageManagement.msgInvalidErrMsg)
})

Then("Enter invalid Message2",function(){
    messageManagementPage1.getMessage2TextField().type(this.msgMgmt.msgInvalidData)
    messageManagementPage1.getProceedButton().click()
})