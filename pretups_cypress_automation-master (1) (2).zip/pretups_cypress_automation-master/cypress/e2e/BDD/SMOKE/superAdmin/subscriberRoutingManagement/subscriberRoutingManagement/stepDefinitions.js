/// <reference types="Cypress" />

//-----------------IMPORTS------------------------
import { Given,Before,Then, When } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../../../support/pageObjects/homePage";
import addSubscriberLandingPage from "../../../../../../support/pageObjects/subscriberRoutingManagement/addSubscriberLandingPage"
import deleteSubscriberRoutingLandingPage from "../../../../../../support/pageObjects/subscriberRoutingManagement/deleteSubscriberRoutingLandingPage"
import "../../../../../../support/commands";

//-----------------OBJECT DECLARATION-----------------------
const homeScreen = new homePage();
const  addSubscriberHomePage= new addSubscriberLandingPage();
const deleteSubscriberRoutingHomePage = new deleteSubscriberRoutingLandingPage();

let modifiedSubscriberNumber;

Before(function(){
   cy.fixture('usersData.json').then(function (userData){
       this.userData = userData
   })

   cy.fixture('messages.json').then(function(messages){
      this.messages = messages
  })

   cy.fixture('subscriberRouting.json').then(function(subscriberRouting){
       this.subscriberRouting = subscriberRouting
   })
})

When("Click on Subscriber Routing",function(){  
   homeScreen.getSubscriberRoutingLink().click()
 })

When("Click on Add Routing Number",function(){
   homeScreen.getAddRoutingNumberSubscriberRoutingLink().click()
 })

Then("Select Interface Category from Dropdown",function(){  
   cy.selectValueInDropdown(addSubscriberHomePage.getInterfaceCategoryDropDown(),this.subscriberRouting.interfaceCategory)
 })

Then("Select Interface Type from Dropdown",function(){ 
   cy.selectValueInDropdown(addSubscriberHomePage.getInterfaceTypeDropDown(),this.subscriberRouting.interfaceType)
 })

Then("Select Interface from Dropdown",function(){ 
   cy.selectValueInDropdown(addSubscriberHomePage.getInterfaceDropDown(),this.subscriberRouting.interface)
 })

Then("Enter Mobile Number in Mobile Number Textfield",function(){ 
   addSubscriberHomePage.getMobileNumberDropDown()
   cy.generateRandomMsisdn(8).then(function(randomSubscriberNumber){
      modifiedSubscriberNumber = randomSubscriberNumber;
      addSubscriberHomePage.getMobileNumberDropDown().type(modifiedSubscriberNumber)
   })
   cy.wait(3000)
})   

Then("Click Submit Subscriber Routing button",function(){ 
   addSubscriberHomePage.getSubmitButton().click()
    cy.wait(3000)
 })

Then("Validate Success Popup Message",function(){ 
   addSubscriberHomePage.getSuccessMessagePopUp().should('contain.text', this.messages.subscriberRouting.subscriberRoutingAddedMessage)
    cy.wait(3000)
})

Then("Click on Done Button",function(){ 
   addSubscriberHomePage.getDoneButton().click()
 })

When("Click on Delete Routing Number",function(){
   homeScreen.getDeleteRoutingNumberSubscriberRoutingLink().click()
 })

Then("Enter Mobile Number in Delete Mobile Number Textfield",function(){ 
   deleteSubscriberRoutingHomePage.getMobileNumberTextField().type(modifiedSubscriberNumber)
})

Then("Click Submit Delete Subscriber Routing button",function(){ 
   deleteSubscriberRoutingHomePage.getSubmitButton().click()
       cy.wait(3000)
    })

Then("Validate Delete Success Popup Message",function(){ 
      deleteSubscriberRoutingHomePage.getDeleteSuccessMessagePopUp().should('contain.text', this.messages.subscriberRouting.subscriberRoutingDeletedMessage)
       cy.wait(3000)
   })

   Then("Validate Error Message when Interface is not Provided",function(){ 
      addSubscriberHomePage.getBlankInterfaceError().should('contain.text', this.messages.subscriberRouting.blankInterfaceErrorMessage)
       cy.wait(3000)
   })

   Then("Validate Error Message when Interface Category is not Provided",function(){ 
      addSubscriberHomePage.getBlankInterfaceCategoryError().should('contain.text', this.messages.subscriberRouting.blankInterfaceCategoryErrorMessage)
       cy.wait(3000)
   })

   Then("Validate Error Message when Interface Type is not Provided",function(){ 
      addSubscriberHomePage.getBlankInterfaceTypeError().should('contain.text', this.messages.subscriberRouting.blankInterfaceTypeErrorMessage)
       cy.wait(3000)
   })

   Then("Validate Error Message when Mobile Number is not Provided",function(){ 
      addSubscriberHomePage.getBlankMobileNumberError().should('contain.text', this.messages.subscriberRouting.blankMobileNumberErrorMessage)
       cy.wait(3000)
   })