/// <reference types="Cypress" />

//-----------------IMPORTS------------------------
import { Given,Before,Then, When } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../../../support/pageObjects/homePage";
import addSubLookUpPage from "../../../../../../support/pageObjects/subLookupManagement/addSubLookUpPage"
import subLookUpLandingPage from "../../../../../../support/pageObjects/subLookupManagement/subLookUpLandingPage"
import "../../../../../../support/commands";
//-----------------OBJECT DECLARATION-----------------------
const homeScreen = new homePage();
const  subLookUpAddScreen= new addSubLookUpPage();
const subLookUpLandingScreen = new subLookUpLandingPage();

let modifiedSubLookup;

Before(function(){
   cy.fixture('usersData.json').then(function (userData){
       this.userData = userData
   })

   cy.fixture('messages.json').then(function(messages){
      this.messages = messages
  })

   cy.fixture('subLookUp.json').then(function(subLookup){
       this.subLookup = subLookup
   })
})

Given("Login with Super admin credentials on Angular 16 PVG Setup",function(){
   cy.launchURL(Cypress.env('ang16pvgUrl'))
   cy.login(this.userData.superadminloginID, this.userData.superadminpasswd);
})

When("Click on Sub Lookup link",function(){  
   homeScreen.getCoreEtopuptab().should('contain.text',this.userData.etopupTabText)
    homeScreen.getSubLookupManagementLink().click()
     cy.wait(6000)
 })

Then("Select Lookup Code from Dropdown",function(){  
   cy.selectValueInDropdown(subLookUpLandingScreen.getLookUpNameDropDown(),"Aadhar No")
   
 })

Then("Click Lookup Proceed Button",function(){ 
    subLookUpLandingScreen.getProceedButton().click({ force: true })
    cy.wait(3000)
 })

Then("Click Add Sub Lookup button",function(){ 
    subLookUpLandingScreen.getAddSubLookUp().click({ force: true })
    cy.wait(3000)
 })

Then("Enter Sub LookUp Name Textfield",function(){ 
   subLookUpAddScreen.getSubLookUpNameTextField().clear()
   
   cy.randomName().then(function(randomSubLookup){
      modifiedSubLookup = randomSubLookup+"subLookup";
      subLookUpAddScreen.getSubLookUpNameTextField().type(modifiedSubLookup)
   })
    //subLookUpAddScreen.getSubLookUpNameTextField().type(this.subLookup.subLookUpName)
    cy.wait(3000)
 })

Then("Click Submit Sub Lookup button",function(){ 
   subLookUpAddScreen.getAddProceedButton().click()
    cy.wait(3000)
 })

Then("Validate Success Popup and Validate Message",function(){ 
   subLookUpAddScreen.getSuccessMessagePopUp().should('contain.text', this.messages.subLookUpManagement.subLookUpAddedMessage)
   //subLookUpAddScreen.getDoneButton().click()
    cy.wait(3000)
})
Then("Validate Success Popup and Validate Modify Message",function(){ 
   subLookUpAddScreen.getSuccessMessagePopUp().should('contain.text', this.messages.subLookUpManagement.subLookUpModifiedMessage)
   //subLookUpAddScreen.getDoneButton().click()
    cy.wait(3000)
})

Then("Click on Edit Button of created Sub Lookup",function(){
   subLookUpLandingScreen.getEditButton().click({ force: true })
})

Then("Search for Sub Lookup",function(){
   subLookUpLandingScreen.getSearchTextBox().type(modifiedSubLookup)
})

Then("Click on Delete Button of Sub Lookup",function(){
   subLookUpLandingScreen.getDeleteButton().click({ force: true })
})

Then("Click on Yes Button on Delete Popup",function(){
   subLookUpAddScreen.getYesDeleteButton().click({ force: true })
})

Then("Click on No Button on Delete Popup",function(){
   subLookUpAddScreen.getNoDeleteButton().click({ force: true })
})

Then("Validate Success Popup and Validate Delete Message",function(){ 
   subLookUpAddScreen.getSuccessMessagePopUp().should('contain.text', this.messages.subLookUpManagement.subLookUpDeletedMessage)
   cy.wait(3000)
})

Then("Enter Sub LookUp Name with 2 characters",function(){ 
   subLookUpAddScreen.getSubLookUpNameTextField().clear()
   subLookUpAddScreen.getSubLookUpNameTextField().type(this.subLookup.invalidSubLookUpName)
   subLookUpAddScreen.getInvalidLengthMessage().should('contain.text', this.messages.subLookUpManagement.invalidSubLookupNameMessage)
   cy.wait(3000)
 })

 Then("Enter duplicate Sub Lookup Name",function(){ 
   subLookUpAddScreen.getSubLookUpNameTextField().type(modifiedSubLookup)
   subLookUpAddScreen.getAddProceedButton().click()
 })

 Then("Validate Duplicate Sub Lookup Error Message",function(){ 
   subLookUpAddScreen.getDuplicateSubLookupNameError().should('contain.text', this.messages.subLookUpManagement.duplicateSubLookUpName)
   cy.wait(3000)
 })
