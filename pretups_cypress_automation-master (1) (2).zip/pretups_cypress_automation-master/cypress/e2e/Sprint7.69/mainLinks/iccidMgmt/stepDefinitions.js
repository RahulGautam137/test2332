/// <reference types="Cypress" />


//--------------------------IMPORTS---------------------------------
import { And, When } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../support/pageObjects/homePage";

//--------------------------OBJECT DECLARATION---------------------------------
const homeScreen = new homePage();

When('Click on Iccid Key Management Link',function(){
    homeScreen.getCoreEtopuptab().should('contain.text',this.loginData.etopupTabText)
    homeScreen.getIccidKeyMgmtLink().click()
})

