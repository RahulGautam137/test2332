/// <reference types="Cypress" />

//--------------------------IMPORTS---------------------------------
import { And, Then } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../support/pageObjects/homePage";

//--------------------------OBJECT DECLARATION---------------------------------
const homeScreen = new homePage();


Then('Click on recharge link for channel user',function(){
    cy.wait(6000)
    homeScreen.getRechargeLinkCU().click()
})