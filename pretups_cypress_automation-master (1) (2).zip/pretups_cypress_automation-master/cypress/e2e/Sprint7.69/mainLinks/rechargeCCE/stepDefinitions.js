/// <reference types="Cypress" />

//--------------------------IMPORTS---------------------------------
import { And, Then } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../support/pageObjects/homePage";

//--------------------------OBJECT DECLARATION---------------------------------
const homeScreen = new homePage();


Then('Click on recharge link for Customer care user',function(){
    homeScreen.getEtopupTab().should('contain.text',this.loginData.etopupTabText)
    homeScreen.getRechargeLinkCCE().click()
})