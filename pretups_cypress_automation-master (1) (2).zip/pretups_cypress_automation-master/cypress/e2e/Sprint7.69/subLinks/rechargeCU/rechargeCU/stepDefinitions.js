/// <reference types="Cypress" />

//--------------------------IMPORTS---------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor";
import rechargeCuPage from "../../../../../support/pageObjects/rechargeCU/rechargeCU/rechargeCuPage";
import rechargeCuLandingPage from "../../../../../support/pageObjects/rechargeCU/rechargeCuLanding/rechargeCuLandingPage";
import homePage from "../../../../../support/pageObjects/homePage";
import "../../../../../support/Utils/rcReversal"

//--------------------------OBJECT DECLARATION---------------------------------
const rechargeCuLandingScreen = new rechargeCuLandingPage();
const rechargeCuScreen = new rechargeCuPage();
const homeScreen = new homePage();

const rcDatafile = "cypress/fixtures/rcReversal/rcDetails.json"

Then('Click on recharge sub link',function(){
    homeScreen.getRechargeSubLinkCU().click();
    rechargeCuLandingScreen.getRechargeHeading().should('be.visible');
})

Then('Perform C2S Recharge',function(){
    rechargeCuLandingScreen.getMsisdnInputField().type(this.rcData.rcRecvMsisdn);
    rechargeCuLandingScreen.getAmtInputField().type(this.rcData.rcAmt)
    rechargeCuLandingScreen.getSubServDropdown().click()

    rechargeCuLandingScreen.getDropdownOptionText().each(function($ele,index,list){
        if($ele.text().includes('CVG')){
            cy.wrap($ele).click()
        }
        else{
            cy.log('Element not found')
        }
    })

    rechargeCuLandingScreen.getRechargeBtnOnLandingPage().click()
    rechargeCuScreen.getPinInputField().type(this.rcData.cuPin)
    rechargeCuScreen.getRechargeBtnOnPopup().click()
    rechargeCuScreen.getRechargeSuccessMsgOnPopup().should('contain.text',this.rcData.rcSuccessMsg)
    rechargeCuScreen.getTxnIdOnPopup().invoke('text').then((txnId)=>{
        const transactionId = txnId.trim();
        cy.readFile(rcDatafile).then((data)=>{
            data.rcTxnId = transactionId
            cy.writeFile(rcDatafile,data)
        })
        cy.setTxnIdForRevByMsisdn(transactionId);
        cy.logTxnID();
  
    })

    rechargeCuScreen.getDoneBtnOnPopup().click()
})

Then('Log channel user out',function(){
    homeScreen.getUsernameCard().click()
    homeScreen.getLogoutOnUsernameCard().click()
})