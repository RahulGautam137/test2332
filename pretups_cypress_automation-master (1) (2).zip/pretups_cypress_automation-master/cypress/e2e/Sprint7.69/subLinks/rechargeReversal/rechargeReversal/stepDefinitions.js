/// <reference types="Cypress" />

//--------------------------IMPORTS---------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../../support/pageObjects/homePage";
import rcReversalLandingPage from "../../../../../support/pageObjects/rcReversalCCE/rcReversalLanding/rcReversalLandingPage";
import rcReversalPage from "../../../../../support/pageObjects/rcReversalCCE/rcReversal/rcReversalPage";
import "../../../../../support/Utils/rcReversal"

//--------------------------OBJECT DECLARATION---------------------------------
const homeScreen = new homePage();
const rcReversalLandingScreen = new rcReversalLandingPage();
const rcReversalScreen = new rcReversalPage();

const rcRevDataFile = "cypress/fixtures/rcReversal/rcReversal.json";

Then('Click on recharge reversal link',function(){
    homeScreen.getRcReversalLinkCCE().click();
    rcReversalLandingScreen.getRcReversalHeading().should('be.visible')
})

Then('click on search by dropdown',function(){
    rcReversalLandingScreen.getSearchByDropdown().click()
})

Then('click on proceed button',function(){
    rcReversalLandingScreen.getProceedBtn().click()
})

Then('select mobile number in dropdown',function(){
    rcReversalLandingScreen.getDropdownOptionsText().each(function($ele,index,list){
        if($ele.text().includes('Mobile number')){
            cy.log('Selected : ',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('Mobile number option not found')
        }
    })
})

Then('select transaction ID in dropdown',function(){
    rcReversalLandingScreen.getDropdownOptionsText().each(function($ele,index,list){
        if($ele.text().includes('Transaction ID')){
            cy.log('Selected : ',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('Transaction ID option not found')
        }
    })
})

Then('Perform recharge reversal by Mobile number',function(){    
    rcReversalLandingScreen.getTxnIdMobNumInputField().type(this.rcData.rcRecvMsisdn)
    rcReversalLandingScreen.getSenderMobNumInputField().type(this.rcRevData.rcSenderMsisdn)
    rcReversalLandingScreen.getProceedBtn().click()

    rcReversalLandingScreen.getTxnIDColData().each(function($ele,index,list){
        const rcTxnId = $ele.text();
        cy.getTxnIdForRevByMsisdn().then((txnId)=>{
            if(rcTxnId.includes(txnId)){
                rcReversalLandingScreen.getActionColLinks().eq(index).click()
            }
            else{
                cy.log('TXN ID not found')
            }
        })
    })

    rcReversalScreen.getReverseAmtBtnOnPopup().click()
    rcReversalScreen.getSuccessMsgOnPopup().should('contain.text',this.rcRevData.rcRevSuccessMsg)

    rcReversalScreen.getRcRevTxnId().invoke('text').then((txnId)=>{
        const transactionId = txnId.trim();
        cy.readFile(rcRevDataFile).then((data)=>{
            data.rcRevByMsisdn = transactionId
            cy.writeFile(rcRevDataFile,data)
        })
    })

})

Then('Perform recharge reversal by transaction ID',function(){
    cy.getTxnIdForRevByMsisdn().then((txnId)=>{
        rcReversalLandingScreen.getTxnIdMobNumInputField().type(txnId)
    })
    rcReversalLandingScreen.getSenderMobNumInputField().type(this.rcRevData.rcSenderMsisdn)
    rcReversalLandingScreen.getProceedBtn().click()
    rcReversalLandingScreen.getReverseAmtLink().click()
    rcReversalScreen.getReverseAmtBtnOnPopup().click()
    rcReversalScreen.getSuccessMsgOnPopup().should('contain.text',this.rcRevData.rcRevSuccessMsg)

    rcReversalScreen.getRcRevTxnId().invoke('text').then((txnId)=>{
        const transactionId = txnId.trim();
        cy.readFile(rcRevDataFile).then((data)=>{
            data.rcRevByTxnId = transactionId
            cy.writeFile(rcRevDataFile,data)
        })
    })
})

Then('Proceed without selecting search by dropdown',function(){
    rcReversalLandingScreen.getSearchCriteriaReqdErrMsg().should('contain.text','Search criteria is required')
})

Then('Proceed without entering value in reciever mobile number field',function(){
    rcReversalLandingScreen.getTxnIdMobNumReqdErrMsg().should('contain.text','Mobile number is required.')
})

Then('Proceed without entering value in transaction ID field',function(){
    rcReversalLandingScreen.getTxnIdMobNumReqdErrMsg().should('contain.text','Transaction ID is required')
})

Then('Proceed without entering sender mobile number',function(){
    rcReversalLandingScreen.getSenderMobNumReqdErrMsg().should('contain.text','Sender mobile number is required')
})

Then('Proceed when no transaction Id exists',function(){
    rcReversalLandingScreen.getTxnIdMobNumInputField().type(this.rcRevData.noRcMsisdn)
    rcReversalLandingScreen.getSenderMobNumInputField().type(this.rcRevData.rcSenderMsisdn)
    rcReversalLandingScreen.getProceedBtn().click()
    rcReversalLandingScreen.getNoRecordMsg().should('contain.text',this.rcRevData.noRecordMsg)
})

