/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import viewChannelUserDetailsPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserdetails/viewChannelUserDetailsPage";
import viewChannelUserLandingPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserLandingPage/viewChannelUserLandingPage";
import "../../../../support/Utils/viewCuCCE"

//-----------------------OBJECT DECLARATION----------------------
const viewCuLandingScreen = new viewChannelUserLandingPage();
const viewCuDetailsScreen = new viewChannelUserDetailsPage();

Then("search channel user by Msisdn", function(){
    viewCuLandingScreen.getHeading().should('be.visible')
    viewCuLandingScreen.getSearchByMsisdnBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuMobileNum)
    viewCuLandingScreen.getProceedBtn().click()
})

Then("search channel user by login ID", function(){
    viewCuLandingScreen.getHeading().should('be.visible')
    viewCuLandingScreen.getSearchByLoginIdBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuLoginId)
    viewCuLandingScreen.getProceedBtn().click()
})

Then("search channel user by External Code",function(){
    viewCuLandingScreen.getHeading().should('be.visible')
    viewCuLandingScreen.getSearchByExtCodeBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuExtCode)
    viewCuLandingScreen.getProceedBtn().click()
})


Then("Navigate to Threshold & Usage Tab", function(){
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab6).click()
})

Then("Check if values are present in Balance preferences table", function(){
    viewCuDetailsScreen.getBalPrefTable().should('be.visible')
    viewCuDetailsScreen.getBalPrefTableData().each(function($ele,index,list){

        cy.wrap($ele).should('not.be.empty')
    })
})

Then("Check if values are present in Daily Transfer control preferences table", function(){
    viewCuDetailsScreen.getBalPrefTable().should('be.visible')
    viewCuDetailsScreen.getDailyTcpTableData().each(function($ele,index,list){

        cy.wrap($ele).should('not.be.empty')
    })
})

Then("Check if values are present in Weekly Transfer control preferences table", function(){
    viewCuDetailsScreen.getBalPrefTable().should('be.visible')
    viewCuDetailsScreen.getWeeklyTcpTableData().each(function($ele,index,list){

        cy.wrap($ele).should('not.be.empty')
    })
})

Then("Check if values are present in Monthly Transfer control preferences table", function(){
    viewCuDetailsScreen.getBalPrefTable().should('be.visible')
    viewCuDetailsScreen.getMonthlyTcpTableData().each(function($ele,index,list){

        cy.wrap($ele).should('not.be.empty')
    })
})