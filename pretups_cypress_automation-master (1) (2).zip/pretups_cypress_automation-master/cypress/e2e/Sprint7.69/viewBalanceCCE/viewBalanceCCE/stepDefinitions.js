/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Before, Given, When, Then, And } from "@badeball/cypress-cucumber-preprocessor"
import viewChannelUserDetailsPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserdetails/viewChannelUserDetailsPage";
import viewChannelUserLandingPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserLandingPage/viewChannelUserLandingPage";
import "../../../../support/Utils/viewCuCCE"

//-----------------------OBJECT DECLARATION----------------------
const viewCuLandingScreen = new viewChannelUserLandingPage();
const viewCuDetailsScreen = new viewChannelUserDetailsPage();

const viewCuDataFile = "cypress/fixtures/viewCuData.json"

//POSITIVE FLOW
Then("View Channel user balance by Msisdn", function(){
    viewCuLandingScreen.getHeading().should('be.visible')
    viewCuLandingScreen.getSearchByMsisdnBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuMobileNum)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getRecordRow().should('contain.text',this.cuData.cuMobileNum)   
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab1).click()
    viewCuDetailsScreen.getBalanceHeading().should('be.visible')
})

Then("View Channel user balance by Login ID", function(){
    viewCuLandingScreen.getSearchByLoginIdBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuLoginId)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getRecordRow().should('contain.text',this.cuData.cuLoginId)   
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab1).click()
    viewCuDetailsScreen.getBalanceHeading().should('be.visible')
})

Then("View Channel user balance by External Code", function(){
    viewCuLandingScreen.getSearchByExtCodeBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuExtCode)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab1).click()
    viewCuDetailsScreen.getBalanceHeading().should('be.visible')
})

