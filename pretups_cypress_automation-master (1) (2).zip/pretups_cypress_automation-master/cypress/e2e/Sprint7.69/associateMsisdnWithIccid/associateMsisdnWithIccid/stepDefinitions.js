// /// <reference types="Cypress" />

// //---------------------IMPORTS------------------------------
// import { Then } from "@badeball/cypress-cucumber-preprocessor";
// import addIccidMsisdnMappingPage from "../../../../support/pageObjects/iccidMgmt/addIccidMsisdnMapping/addIccidMsisdnMappingPage";
// import iccidKeyMgmtLandingPage from "../../../../support/pageObjects/iccidMgmt/iccidKeyMgmtLanding/iccidKeyMgmtLandingPage";

// //-----------------------OBJECT DECLARATION----------------------
// const iccidKeyMgmtLandingScreen = new iccidKeyMgmtLandingPage();
// const addIccidMsisdnMappingScreen = new addIccidMsisdnMappingPage();

// const iccidFile = 'cypress/fixtures/iccid.txt'
// const associateIccidDataFile = 'cypress/fixtures/associateIccid.json'

// // Then('Click on add mapping button',function(){
// //     iccidKeyMgmtLandingScreen.getIccidKeyMgmtHeading().should('be.visible')
// //     iccidKeyMgmtLandingScreen.getAddMappingBtn().click()
// // })

// Then('Enter ICCID',function(){

//     cy.readFile(iccidFile).then((data)=>{
//         iccidArray = data.split('\n')
//         cy.log('Iccid array:', iccidArray);
//         const randomIndex = Math.floor(Math.random() * iccidArray.length);
//         const selectedIccid = iccidArray[randomIndex];

//         addIccidMsisdnMappingScreen.getIccidInputField().type(selectedIccid)
//         cy.readFile(associateIccidDataFile).then((iccid)=>{
//             iccid.associatedIccidMsisdnPair.iccid = selectedIccid 
//             cy.writeFile(associateIccidDataFile,iccid)
//         })

//         iccidArray.splice(randomIndex, 1);
//         cy.log('Updated iccid array:', iccidArray);
//         const updatedIccids = iccidArray.join('\n');
//         cy.writeFile(iccidFile, updatedIccids);
//     })
// })

// Then('Enter Msisdn',function(){
//     cy.getRandomMsisdn(8).then((msisdnToBeAssociated)=>{
//         addIccidMsisdnMappingScreen.getMobNumInputField().type(msisdnToBeAssociated)
//         cy.readFile(associateIccidDataFile).then((mobNum)=>{
//             mobNum.associatedIccidMsisdnPair.msisdn = msisdnToBeAssociated 
//             cy.writeFile(associateIccidDataFile,mobNum)
//         })

//     })
// })

// Then('Click on add button on add mapping screen',function(){
//     addIccidMsisdnMappingScreen.getMappingDetailsAddBtn().click()
// })

// Then('Verify Success Message',function(){
//     addIccidMsisdnMappingScreen.getMsgOnPopup().should('contain.text',this.associateIccidData.messages.mapSucessMsg)
// })

// Then('Verify error message for ICCID Required',function(){
//     addIccidMsisdnMappingScreen.getIccidReqdErrMsg().should('contain.text',this.associateIccidData.messages.iccidReqdErrMsg)
// })

// Then('Verify error message for MSISDN Required',function(){
//     addIccidMsisdnMappingScreen.getMobNumReqdErrMsg().should('contain.text',this.associateIccidData.messages.mobNumReqdErrMsg)
// })