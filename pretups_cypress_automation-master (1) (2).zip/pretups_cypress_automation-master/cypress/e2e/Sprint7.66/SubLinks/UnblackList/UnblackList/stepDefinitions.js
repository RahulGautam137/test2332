/// <reference types="Cypress" />

// ---------------------------IMPORTS--------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor";
import deletePage from "../../../../../support/pageObjects/RestrictedListManagement/DeleteRestrictedMSISDN/deletePage"
import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage";
import homePage from "../../../../../support/pageObjects/homePage";
import blackUnblackListPage from "../../../../../support/pageObjects/RestrictedListManagement/BlackListMSISDN/blackUnblackListPage"

// -----------------------------OBJECT DECLARATION--------------------------
const homeScreen = new homePage();
const uploadScreen = new uploadPage();
const deleteScreen = new deletePage();
const blackUnblackListScreen = new blackUnblackListPage();

Then('Unblack List Subscriber Msisdn',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to unblack list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Unblack List toggle button
    blackUnblackListScreen.getUnblackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Unblack List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()

    //Select subscriber
    deleteScreen.getMultipleRadioBtn().check()

    //Enter Msisdn
    deleteScreen.getSubsMsisdnField().type(this.loginData.restrictedMsisdnForBlackList)
    
    //Click on submit button on 1st screen
    uploadScreen.getSubmitBtn().click()

    //Validation that number is present on confirm details screen
    blackUnblackListScreen.getSubscriberMsisdnOnDetailsScreen().should('contain.text',this.loginData.restrictedMsisdnForBlackList)

    //Validation that checkbox is selected for that particular MSISDN
    blackUnblackListScreen.getSubscriberMsisdnCheckBox().should('be.checked')

    //Click on submit button on 2nd screen
    uploadScreen.getSubmitBtn().click()

    //Validating Success Message
    uploadScreen.getUploadScreenMessage().should('contain.text',this.loginData.unblackListMsisdnSuccessMsg)

    //Clickin on done button on message popup
    uploadScreen.getUploadScreenPopupDoneBtn().click()
})