/// <reference types="Cypress" />

Before(()=>{
    cy.fixture('restrictedMsisdn.json').then(function (restMsisdnData){
        this.restMsisdnData = restMsisdnData
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })
    })

//---------------------IMPORTS------------------------------
import { Before, Given, Then } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../../support/pageObjects/homePage";
import "../../../../../support/Utils/SubscriberMsisdnGenerator";
import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage"

//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();
const uploadScreen = new uploadPage();


Given('Log in with channel admin credentials', function () {
    cy.launchURL(Cypress.env('pvgUrl'))
    cy.login(this.userData.channelAdminLoginID, this.userData.channelAdminPasswd);
  })


Then("Upload Restricted List", function(){
   
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select User
    uploadScreen.getUserField().type(this.restMsisdnData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Subscriber type
    uploadScreen.getSubscriberTypeDropdown().click()
    uploadScreen.getSubscriberTypeDropdownOptions().click()

    //Generate random Subscriber Msisdns
    cy.generateMsisdnsToBeRestricted(this.restMsisdnData.countOfMsisdnsToBeGenerated);
    
    //Choose file containing Msisdns
    uploadScreen.getChooseFile().selectFile(this.restMsisdnData.restrictedMsisdnFile)

    //Click on Submit button
    uploadScreen.getUploadScreenSubmitBtn().click()

    //Get and validate success message after uploading file
    uploadScreen.getUploadScreenMessage().should('include.text',this.loginData.restrictedMsisdnUploadSuccessMsg)

    //Click on done button on message popup
    uploadScreen.getUploadSuccessPopupDoneBtn().click()    
})

Then('Proceed without selecting value in Domain Dropdown',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getDomainReqErrorMsg().should('contain.text',this.loginData.domainReqdErrorMsg)
})


Then('Proceed without selecting value in Category Dropdown',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getCategoryReqErrorMsg().should('contain.text',this.loginData.categoryReqdErrorMsg)
})

Then('Proceed without selecting value in Geography Dropdown',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getGeographyReqdErrorMsg().should('contain.text',this.loginData.geographyReqdErrorMsg)
})

Then('Proceed without entering & searching value in User field',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getUserReqdErrorMsg().should('contain.text',this.loginData.userReqdErrorMsg)
})

Then('Proceed without selecting value in Subscriber type dropdown',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getSubsTypeReqdErrorMsg().should('contain.text',this.loginData.subsTypeReqdErrorMsg)
})


Then('Proceed without selecting file',function(){
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //To check if user has been navigated to upload screen or not
    uploadScreen.getUploadScreenHeading().should('be.visible')

    //Click on upload toggle button
    uploadScreen.getUploadToggleBtn().click()

    //Click on submit button without selecting any value in Domain Dropdown 
    uploadScreen.getUploadScreenSubmitBtn().click()

    uploadScreen.getFileReqdErrorMsg().should('contain.text',this.loginData.fileReqdErrorMsg)
})