/// <reference types="Cypress" />

// ---------------------------IMPORTS--------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor";
import deletePage from "../../../../../support/pageObjects/RestrictedListManagement/DeleteRestrictedMSISDN/deletePage";
import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage";
import homePage from "../../../../../support/pageObjects/homePage";
import blackUnblackListPage from "../../../../../support/pageObjects/RestrictedListManagement/BlackListMSISDN/blackUnblackListPage";

// -----------------------------OBJECT DECLARATION--------------------------
const homeScreen = new homePage();
const uploadScreen = new uploadPage();
const deleteScreen = new deletePage();
const blackUnblackListScreen = new blackUnblackListPage();

Then('Black List Subscriber Msisdn',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    
    cy.waitUntil(()=>{
        return blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')
    })

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()

    //Select subscriber
    blackUnblackListScreen.getSingleRadioBtn().check()

    //Enter Msisdn
    var msisdn ;
    cy.pickRandomMsisdnFromGeneratedList().then((result) => {
        // 'result' contains the value returned by cy.pickRandomMsisdnFromGeneratedList()
        msisdn = result;
        cy.log('Selected MSISDN:'+ msisdn);
        
        cy.readFile('cypress/fixtures/example.json').then((data)=>{
            data.restrictedMsisdnForBlackList = msisdn
            cy.writeFile('cypress/fixtures/example.json',data)
            
        })

        deleteScreen.getSubsMsisdnField().type(msisdn)
        //Click on submit button on 1st screen
        uploadScreen.getSubmitBtn().click()

        //Validation that number is present on confirm details screen
        blackUnblackListScreen.getSubscriberMsisdnOnDetailsScreen().should('contain.text',msisdn)

        
    })

    //Click on submit button on 2nd screen
    uploadScreen.getSubmitBtn().click()

    //Validating Success Message
    uploadScreen.getUploadScreenMessage().should('contain.text',this.loginData.blackListMsisdnSuccessMsg)

    //Clickin on done button on message popup
    uploadScreen.getUploadScreenPopupDoneBtn().click()
})


Then('Proceed without selecting Black list type & single radio button',function(){
     //Click on Black Unblack List subscribers link
     homeScreen.getBlackUnblackLink().click()

     //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')


     //Click on Black List toggle button
     blackUnblackListScreen.getBlackListToggleBtn().click()
 
     //Select Domain
     uploadScreen.getDomainDropdown().click()
     uploadScreen.getDomainDropdownOptions().click()
 
     //Select Category
     uploadScreen.getCategoryDropdown().click()
     uploadScreen.getCategoryDropdownOptions().click()
 
     //Select Geography
     uploadScreen.getGeographyDropdown().click()
     uploadScreen.getGeographyDropdownOptions().click()
 
     //Select user
     uploadScreen.getUserField().type(this.loginData.corporateUser)
     uploadScreen.getSearchBtn().click()
     uploadScreen.getUsersOnPopup().click()
     uploadScreen.getDoneBtnOnPopup().click()

    //Uncheck all checkboxes
     blackUnblackListScreen.getAllCheckboxes().uncheck()

     //Select Single Radio Button
     blackUnblackListScreen.getSingleRadioBtn().check()

     uploadScreen.getSubmitBtn().click()

     blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed without selecting Black list type & multiple radio button',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

   //Uncheck all checkboxes
    blackUnblackListScreen.getAllCheckboxes().uncheck()

    //Select Single Radio Button
    deleteScreen.getMultipleRadioBtn().check()

    uploadScreen.getSubmitBtn().click()

    blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})

Then('Proceed without selecting Black list type & all radio button',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

   //Uncheck all checkboxes
    blackUnblackListScreen.getAllCheckboxes().uncheck()

    //Select Single Radio Button
    deleteScreen.getAllRadioBtn().check()

    uploadScreen.getSubmitBtn().click()

    blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed without selecting file for Multiple radio button',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()    

    //Select Multiple Radio Button
    deleteScreen.getMultipleRadioBtn().check()

    uploadScreen.getSubmitBtn().click()

    uploadScreen.getFileReqdErrorMsg().should('contain.text',this.loginData.fileReqdErrorMsg)

    // blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed without entering MSISDN for Single radio button',function(){
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()    

    //Select Multiple Radio Button
    blackUnblackListScreen.getSingleRadioBtn().check()

    uploadScreen.getSubmitBtn().click()

    deleteScreen.getSubsMsisdnReqdErrorMsg().should('contain.text',this.loginData.subscriberReqdErrorMsg)

    // blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed with invalid dgjhk for Single radio button',function(){
    
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    cy.waitUntil(() => {
        return blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')
      })
    // blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()    

    //Select Multiple Radio Button
    blackUnblackListScreen.getSingleRadioBtn().check()

    deleteScreen.getSubsMsisdnField().type('dgjhk')

    uploadScreen.getSubmitBtn().click()

    blackUnblackListScreen.getInvalidMsisdnFormatErrorMsg().should('contain.text',this.loginData.invalidMsisdnFormatErrMsg)

    // blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed with invalid 1345 for Single radio button',function(){
    
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()    

    //Select Multiple Radio Button
    blackUnblackListScreen.getSingleRadioBtn().check()

    deleteScreen.getSubsMsisdnField().type('1345')

    uploadScreen.getSubmitBtn().click()

    blackUnblackListScreen.getInvalidMsisdnFormatErrorMsg().should('contain.text',this.loginData.invalidMsisdnFormatErrMsg)

    // blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})


Then('Proceed with invalid ^%&^$^% for Single radio button',function(){
    
    //Click on Black Unblack List subscribers link
    homeScreen.getBlackUnblackLink().click()

    //Verify that user has been navigated to black list screen
    blackUnblackListScreen.getBlackUnblackListScreenHeading().should('be.visible')

    //Click on Black List toggle button
    blackUnblackListScreen.getBlackListToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Select Black List type
    blackUnblackListScreen.getP2pPayerCheckbox().check()
    blackUnblackListScreen.getP2pPayeeCheckbox().check()
    blackUnblackListScreen.getC2sPayeeCheckbox().check()    

    //Select Multiple Radio Button
    blackUnblackListScreen.getSingleRadioBtn().check()

    deleteScreen.getSubsMsisdnField().type('^%&^$^%')

    uploadScreen.getSubmitBtn().click()

    blackUnblackListScreen.getInvalidMsisdnFormatErrorMsg().should('contain.text',this.loginData.invalidMsisdnFormatErrMsg)

    // blackUnblackListScreen.getBlackUnblackListTypeReqdErrorMsg().should('contain.text',this.loginData.blackListTypeReqdErrorMsg)
})
