/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../../support/pageObjects/homePage"
import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage";
import deletePage from "../../../../../support/pageObjects/RestrictedListManagement/DeleteRestrictedMSISDN/deletePage";

//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();
const uploadScreen = new uploadPage();
const deleteScreen = new deletePage();

Then("Delete Restricted List", function(){

    //Assertion that user has successfully logged in and has reached on main screen
    // homeScreen.getEtopupTab().should('contain.text',this.loginData.etopupTabText)
   
    // //Click on Subscriber Management link
    // homeScreen.getSubscriberMgmtLink().click()
   
    //Click on Restricted list management link
    homeScreen.getRestrictedListMgmtLink().click()

    //Click on delete toggle button
    deleteScreen.getDeleteToggleBtn().click()

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    //Select Category
    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    //Select Geography
    uploadScreen.getGeographyDropdown().click()
    uploadScreen.getGeographyDropdownOptions().click()

    //Select user
    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()
    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    //Selecting subscriber (All/Multiple)
    deleteScreen.getMultipleRadioBtn().check()
    deleteScreen.getSubsMsisdnField().type(this.loginData.restrictedMsisdn)

    deleteScreen.getDeleteScreenSubmitBtn().click()

    deleteScreen.getMsisdnCheckbox().check()

    deleteScreen.getSubsDetailsDeleteScreenSubmitBtn().click()

    deleteScreen.getMessage().should('include.text',this.loginData.restrictedMsisdnDeleteMsg)

    uploadScreen.getDoneBtnOnPopup().click()
   
})