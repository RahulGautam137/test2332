/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../../support/pageObjects/homePage"
import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage";
import approvePage from "../../../../../support/pageObjects/RestrictedListManagement/ApproveRestrictedMsisdn/approvePage"
import viewPage from "../../../../../support/pageObjects/RestrictedListManagement/ViewRestrictedMSISDN/viewPage";


//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();
const uploadScreen = new uploadPage();
const approveScreen = new approvePage();
const viewScreen = new viewPage();


Then("Approve Restricted List", function(){

    //Assertion that user has successfully logged in and has reached on main screen
    // homeScreen.getEtopupTab().should('contain.text','eTopup')
   
    // //Click on Approval level 1 link
    homeScreen.getApprovalL1Link().click()

    //Click on Restricted Subscribers List
    homeScreen.getAppr1RestrictedSubsLink().click()

    approveScreen.getApprovalScreenHeading().should('exist')

    //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    cy.get('[formcontrolname="geograpgy"]').click()
    cy.get('[formcontrolname="geograpgy"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Delhi-Ncr "]').click()

    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()

    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    approveScreen.getApproveScreenProceedBtn().click()

//     let mobileNumbers;

// cy.readFile('cypress/fixtures/restrictedListRunTime.txt').then((fileContent) => {
//     // Assuming the mobile numbers are in the format "72xxxxxxxx" based on your previous code
//     const regex = /72\d{8}/g;
//     mobileNumbers = fileContent.match(regex);

//     // Now 'mobileNumbers' variable contains an array of matched mobile numbers
//     // You can use it as needed
//     console.log('Mobile Numbers:', mobileNumbers);

// });

viewScreen.getSearchBar().type(this.loginData.restrictedMsisdn)

// cy.get('.has-search > .form-control').type(7271308902)
// cy.get('input.td-input-checkbox').check() -> to be used for multiple msisdn case
approveScreen.getSubsApprovalLink().click()
approveScreen.getYesBtn().click()
uploadScreen.getUploadScreenMessage().should('include.text',this.loginData.restrictedMsisdnApprovalSuccessMsg)
uploadScreen.getUploadSuccessPopupDoneBtn().click()

    })