/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../../support/pageObjects/homePage";
 import uploadPage from "../../../../../support/pageObjects/RestrictedListManagement/UploadRestrictedMSISDN/uploadPage";
 import viewPage from "../../../../../support/pageObjects/RestrictedListManagement/ViewRestrictedMSISDN/viewPage"
import "../../../../../support/Utils/generic";
import "../../../../../support/Utils/restrictedMsisdn";


//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();
const viewScreen = new viewPage();
const uploadScreen = new uploadPage();

var userData = "cypress/fixtures/usersData.json"
var restrictedMsisdnData = "cypress/fixtures/restrictedMsisdn.json"

// Given('Log in with channel admin credentials', function () {
//     cy.launchURL(Cypress.env('pvgUrl'))
//     cy.login(this.userData.channelAdminLoginID, this.userData.channelAdminPasswd);
//   })

Then("View Restricted List", function(){

    homeScreen.getViewRestrictedSubscribersLink().click()
    // // homeScreen.getRestrictedListMgmtLink().click()
    // // cy.get('[ng-reflect-router-link="/viewResList"]',{timeout:3000}).click()

    viewScreen.getViewScreenHeading().should('be.visible')
    
    // //Select Domain
    uploadScreen.getDomainDropdown().click()
    uploadScreen.getDomainDropdownOptions().click()

    uploadScreen.getCategoryDropdown().click()
    uploadScreen.getCategoryDropdownOptions().click()

    cy.get('[formcontrolname="geograpgy"]').click()
    cy.get('[formcontrolname="geograpgy"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Delhi-Ncr "]').click()

    uploadScreen.getUserField().type(this.loginData.corporateUser)
    uploadScreen.getSearchBtn().click()

    uploadScreen.getUsersOnPopup().click()
    uploadScreen.getDoneBtnOnPopup().click()

    viewScreen.getDateField().click()
    viewScreen.getCalendarMonthField().select(10)
    viewScreen.getCalendarYearField().select("2023")
    viewScreen.getStartDate().contains(3).click()
    viewScreen.getEndDate().contains(30).click()
    viewScreen.getViewScreenProceedBtn().click()

    var msisdn ;
    cy.pickRandomMsisdnFromGeneratedList().then((result) => {
        // 'result' contains the value returned by cy.pickRandomMsisdnFromGeneratedList()
        msisdn = result;
        cy.log('Selected MSISDN:'+ msisdn);
        
        cy.readFile(restrictedMsisdnData).then((data)=>{
            data.restrictedMsisdn = msisdn
            cy.writeFile(restrictedMsisdnData,data)
            
        })
        
        viewScreen.getSearchBar().type(msisdn)
        viewScreen.getViewScreenMsisdnColumn().should('include.text',msisdn)
      });
        
})

Then('Proceed without selecting Date range',function(){

    homeScreen.getViewRestrictedSubscribersLink().click()
    viewScreen.getViewScreenHeading().should('be.visible')
    viewScreen.getViewScreenProceedBtn().click()
    viewScreen.getDateRangeReqdErrorMsg().should('contain.text',this.loginData.dateRangeReqdErrorMsg)

})