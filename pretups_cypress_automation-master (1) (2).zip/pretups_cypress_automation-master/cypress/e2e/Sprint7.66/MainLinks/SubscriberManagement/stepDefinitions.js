/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../support/pageObjects/homePage"
import 'cypress-wait-until';


//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();


Then("Click on Subscriber Management Link", function(){

    //Assertion that user has successfully logged in and has reached on main screen
    // cy.waitUntil(() => 
        homeScreen.getEtopupTab().should('contain.text',this.loginData.etopupTabText)
        // return cy.iframe().find('#mat-tab-label-1-0',{timeout:30000}).find('.mat-tab-label-content').should('contain.text',this.loginData.etopupTabText)
    // )    
   
    //Click on Subscriber Management link
    // cy.waitUntil(()=>{
        return homeScreen.getSubscriberMgmtLink().click()

    // })
   
})