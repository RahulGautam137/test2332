/// <reference types="Cypress" />
/// <reference types = "Cypress-iframe"/>

import { Before, Given, When, Then } from "@badeball/cypress-cucumber-preprocessor"

Then("View Voucher Card Group", function(){
    cy.wait(4000)
    //Assertion that user has successfully logged in and has reached on main screen
    cy.get('#mat-tab-label-1-0',{ timeout: 12000 }).find('.mat-tab-label-content').should('contain.text','eTopup')
    // cy.get('#userdropdown > .nav-link').should('contain.text','nwadmpvg N')
    
    cy.get(':nth-child(15) > .childmenucss').click()
    cy.get('[ng-reflect-router-link="/cardGroupV2C"]').click()
    cy.wait(2000)
    cy.get('#subService').click()
    cy.get('#subService').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()

    cy.get('ng-select[formcontrolname="setType"]').click()
    cy.get('ng-select[formcontrolname="setType"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()

    cy.get('#time').type("18/11/2023 18:47")
    cy.get('[name="Proceed"]').click()
})