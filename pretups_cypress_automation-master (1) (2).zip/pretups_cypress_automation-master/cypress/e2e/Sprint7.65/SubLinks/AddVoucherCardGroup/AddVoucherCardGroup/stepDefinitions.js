/// <reference types="Cypress" />

//--------------------------IMPORTS-------------------------------
import { Before, Given, When, Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../../support/pageObjects/homePage";
import vcgLandingPage from "../../../../../support/pageObjects/VoucherCardGroup/VcgLanding/VcgLandingPage";
import addVcgPage from "../../../../../support/pageObjects/VoucherCardGroup/AddVoucherCardGroup/addVcgPage";
import "../../../../../support/Utils/generic"


//---------------------------OBJECT DECLARATION--------------------
const homeScreen = new homePage();
const vcgLandingScreen = new vcgLandingPage();
const addVcgScreen = new addVcgPage();

const vcgDataFile = "cypress/fixtures/vcgData.json"

Given("Login with Network admin credentials",function(){
    cy.launchURL(Cypress.env('pvgUrl'))
    cy.login(this.userData.nwadmloginID, this.userData.nwadmpasswd);
})

Then("Add Voucher Card Group", function(){

    homeScreen.getVoucherCardGrpLink().click()
    vcgLandingScreen.getVcgHeading().should('be.visible')
    vcgLandingScreen.getAddVcgBtn().click()

    
    // cy.get('[ng-reflect-klass="add-btn"]').click()
    // cy.wait(2000)

    addVcgScreen.getSubServiceDropdown().click()
    addVcgScreen.getSubServiceDropdown().contains("Choice RC 1").click()

    // cy.get('#subService').click()
    // cy.get('#subService').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()

    // let name = cy.randomName()
    // addVcgScreen.getCgSetName().type(name)

    cy.randomName().then((value) => {
        // Use the custom value in further commands
        addVcgScreen.getCgSetName().type(value);
      });
      
      
    addVcgScreen.getCgSetName().invoke('val').then((val)=> {
        cy.log(val)
        cy.readFile(vcgDataFile).then((data)=>{
            data.vcgName = val
            cy.writeFile(vcgDataFile,data)
        })
    })
 

    addVcgScreen.getCgSetTypeDropdown().click()
    addVcgScreen.getCgSetTypeDropdown().contains("Normal").click()
    // cy.get('ng-select[formcontrolname="setType"]').click()
    // cy.get('ng-select[formcontrolname="setType"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()
    

    addVcgScreen.getApplicableFrom().click()
    // cy.get('.ui-datepicker-today > .ui-state-default').click()
    addVcgScreen.getHourUpKey().click()
    addVcgScreen.getCurrentDateOnCalendar().click()
    // addVcgScreen.getHourUpKey().click()

    addVcgScreen.getCgNameField().type('Automated VCG')
    addVcgScreen.getCgCodeField().type('AUT'+ Math.floor(Math.random() * 1000) + 'VCG')

    addVcgScreen.getVoucherTypeDropdown().click()
    addVcgScreen.getVoucherTypeDropdown().contains('Digital').click()

    addVcgScreen.getVoucherSegmentDropdown().click()
    addVcgScreen.getVoucherSegmentDropdown().contains('National').click()



    // cy.get('[formcontrolname="voucherSegment"]').click()
    // cy.get('[formcontrolname="voucherSegment"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()
    
    addVcgScreen.getDenominationDropdown().click()
    addVcgScreen.getDenominationDropdownOption().first().click()
    // cy.get('[formcontrolname="denomination"]').click()
    // cy.get('[formcontrolname="denomination"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()

    addVcgScreen.getDenominationProfileDropdown().click()
    addVcgScreen.getDenominationProfileDropdownOption().first().click()
    // cy.get('[formcontrolname="denominationProfile"]').click()
    // cy.get('[formcontrolname="denominationProfile"]').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').first().click()


    addVcgScreen.getTax1UnitDropdown().click()
    addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click()
    // addVcgScreen.getTax1Unit().contains('Pct').click()
    addVcgScreen.getTax1Rate().clear()
    addVcgScreen.getTax1Rate().type(1)


    addVcgScreen.getTax2UnitDropdown().click()
    addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click()
    // addVcgScreen.getTax2Unit().contains('Pct').click()
    addVcgScreen.getTax2Rate().clear()
    addVcgScreen.getTax2Rate().type(1)

    // cy.get('#tax2Unit').click()
    // cy.get('#tax2Unit').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Pct "]').click()
    // cy.get('[name="tax2Rate"]').clear().type(2)


    addVcgScreen.getProcessingFeeDropdown().click()
    addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click()
    addVcgScreen.getProcessingFeeInputField().clear()
    addVcgScreen.getProcessingFeeInputField().type(1)

    // cy.get('ng-select#rate').click()
    // cy.get('ng-select#rate').find('.ng-dropdown-panel').find('.ng-dropdown-panel-items').find('.ng-option').find('[ng-reflect-ng-item-label=" Pct "]').click()
    // cy.get('.col-lg-5 > [style="gap: 10px;"] > :nth-child(1) > .d-flex > :nth-child(2) > .form-control').clear().type('1')

    addVcgScreen.getMinAmtInputField().type('0')
    addVcgScreen.getMaxAmtInputField().type('5')
    
    // cy.get('[name="minAmt"]').type('0')
    // cy.get('[name="maxAmt"]').type('5')

    addVcgScreen.getValidityTypeDropdown().click()
    addVcgScreen.getValidityTypeDropdown().contains('Highest').click()

    addVcgScreen.getValidityDaysInputField().type('18')
    // cy.get('[name="validitydDays"]').type('18')

    addVcgScreen.getGracePeriodInputField().type('10')
    // cy.get('[name="Days"]').type('10')

    // const valuesSets = [
    //     ['CVG', 'Pct', '1', '7', '1'],
    //     ['C', 'Amt', '2', '14', '1'],
    //     ['ppp', 'Pct', '1', '32', '1']
    //   ];

    // addVcgScreen.getBonusBenefitsRows().each(($element, index, $list) => {
    //     // You can perform actions on each element here
    //     const currentValueSet = valuesSets[index];
    //     currentValueSet.forEach((value, subIndex) => {
           
    //         if(subIndex === 0){
    //             cy.wrap($element).eq(subIndex).getBonusBundleDropdowns().contains(value).click();
    //             cy.log(`Typed '${value}' into element ${subIndex + 1} of ${$list.length} for set ${index + 1}`);
    //         }

    //         if(subIndex === 1){
    //             cy.wrap($element).eq(subIndex).getBonusUnitDropdowns().contains(value).click();
    //             cy.log(`Typed '${value}' into element ${subIndex + 1} of ${$list.length} for set ${index + 1}`);
    //         }

    //         if(subIndex === 2){
    //             cy.wrap($element).eq(subIndex).getProcessingFeeInputField().type(value);
    //             cy.log(`Typed '${value}' into element ${subIndex + 1} of ${$list.length} for set ${index + 1}`);
    //         }
    
    //         if(subIndex === 3){
    //             cy.wrap($element).eq(subIndex).getBonusValidityDropdowns().type(value);
    //             cy.log(`Typed '${value}' into element ${subIndex + 1} of ${$list.length} for set ${index + 1}`);
    //         }

    //         if(subIndex === 4){
    //             cy.wrap($element).eq(subIndex).getBonusBcfInputFields().type(value);
    //             cy.log(`Typed '${value}' into element ${subIndex + 1} of ${$list.length} for set ${index + 1}`);
    //         }            
    //       });
    //   });

    // const valuesSets = [
    //     ['CVG', 'Pct', '1', '7', '1'],
    //     ['C', 'Amt', '2', '14', '1'],
    //     ['ppp', 'Pct', '1', '32', '1']
    //   ]; 

    // for (let i = 0; i < 3; i++) {
    
    //     for (let j = 0; j < 5; j++) {
            
    //         addVcgScreen.getBonusBundleDropdowns().eq(i).click()
    //         addVcgScreen.getTaxUnitDropdownOptions().contains('CVG').click();

    //         addVcgScreen.getBonusUnitDropdowns().eq(i).click();
    //         addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click();

    //         addVcgScreen.getBonusValueInputField().eq(i).clear()
    //         addVcgScreen.getBonusValueInputField().eq(i).type(1)

    //         addVcgScreen.getBonusValidityInputField().eq(i).clear()
    //         addVcgScreen.getBonusValidityInputField().eq(i).type(1)

    //         addVcgScreen.getBonusBcfInputFields().eq(i).clear()
    //         addVcgScreen.getBonusBcfInputFields().eq(i).type(1)
        
    //     }
    
    // }
    addVcgScreen.getBonusBundleDropdowns().eq(0).click()
    addVcgScreen.getTaxUnitDropdownOptions().contains('CVG').click();

    addVcgScreen.getBonusUnitDropdowns().eq(0).click();
    addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click();

    addVcgScreen.getBonusValueInputField().eq(0).clear()
    addVcgScreen.getBonusValueInputField().eq(0).type(1)

    addVcgScreen.getBonusValidityInputField().eq(0).clear()
    addVcgScreen.getBonusValidityInputField().eq(0).type(1)

    addVcgScreen.getBonusBcfInputFields().eq(0).clear()
    addVcgScreen.getBonusBcfInputFields().eq(0).type(1)

    //2nd bonus bundle
    // addVcgScreen.getBonusBundleDropdowns().eq(1).click()
    // addVcgScreen.getTaxUnitDropdownOptions().find('contains("C"):first').click();

    addVcgScreen.getBonusUnitDropdowns().eq(1).click();
    addVcgScreen.getTaxUnitDropdownOptions().contains('Amt').click();

    addVcgScreen.getBonusValueInputField().eq(1).clear()
    addVcgScreen.getBonusValueInputField().eq(1).type(1)

    addVcgScreen.getBonusValidityInputField().eq(1).clear()
    addVcgScreen.getBonusValidityInputField().eq(1).type(1)

    addVcgScreen.getBonusBcfInputFields().eq(1).clear()
    addVcgScreen.getBonusBcfInputFields().eq(1).type(1)

    //3rd bonus bundle
    addVcgScreen.getBonusBundleDropdowns().eq(2).click()
    addVcgScreen.getTaxUnitDropdownOptions().contains('ppp').click();

    addVcgScreen.getBonusUnitDropdowns().eq(2).click();
    addVcgScreen.getTaxUnitDropdownOptions().contains('Pct').click();

    addVcgScreen.getBonusValueInputField().eq(2).clear()
    addVcgScreen.getBonusValueInputField().eq(2).type(1)

    addVcgScreen.getBonusValidityInputField().eq(2).clear()
    addVcgScreen.getBonusValidityInputField().eq(2).type(1)

    addVcgScreen.getBonusBcfInputFields().eq(2).clear()
    addVcgScreen.getBonusBcfInputFields().eq(2).type(1)

    addVcgScreen.getSaveCardBtn().click()
    // cy.get('#ng-select-box-default [name="Proceed"]').click()

    addVcgScreen.getYesBtnOnPopup().click()

    addVcgScreen.getMessageOnPopup().should('contain.text','card details added successfully')

    addVcgScreen.getDoneBtnOnMsgPopup().click()
    // cy.get('.model-footer .submit-doneBtn').click()

    // cy.get('.ui-minute-picker > :nth-child(1) > .pi').dblclick()

    addVcgScreen.getSaveCardGrpSetBtn().click()

    addVcgScreen.getMessageOnPopup().should('include.text','details successfully added')

    addVcgScreen.getDoneBtnOnMsgPopup().click()


    
})