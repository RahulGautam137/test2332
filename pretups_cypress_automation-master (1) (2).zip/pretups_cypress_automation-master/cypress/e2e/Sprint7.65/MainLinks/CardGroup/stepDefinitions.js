/// <reference types="Cypress" />

//-----------------IMPORTS------------------------
import { And, Then } from "@badeball/cypress-cucumber-preprocessor";
import homePage from "../../../../support/pageObjects/homePage";

//-----------------OBJECT DECLARATION-----------------------
const homeScreen = new homePage();


Then("Click on Card group link",function(){

    homeScreen.getEtopupTab().should('be.visible')
    homeScreen.getCardGroupLink().click()

})