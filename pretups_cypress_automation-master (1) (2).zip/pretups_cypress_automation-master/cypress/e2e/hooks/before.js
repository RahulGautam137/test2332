/// <reference types="Cypress" />

import { Before } from "@badeball/cypress-cucumber-preprocessor"

//BDD HOOKS

Before(()=>{

    cy.fixture('example.json').then(function (loginData){
        this.loginData = loginData
    })

    cy.fixture('restrictedMsisdn.json').then(function (restMsisdnData){
        this.restMsisdnData = restMsisdnData
    })

    cy.fixture('usersData.json').then(function (userData){
        this.userData = userData
    })

    cy.fixture('vcgData.json').then(function (vcgData){
        this.vcgData = vcgData
    })

    cy.fixture('viewCuData.json').then(function (cuData){
        this.cuData = cuData
    })

    cy.fixture('viewBarredList.json').then(function (barredList){
        this.barredList = barredList
    })

    cy.fixture('/bulkOptUser/bulkOperatorUserData.json').then(function (bulkOptData){
        this.bulkOptData = bulkOptData
    })

    cy.fixture('srvTypeSelMapData.json').then(function(selMapData){
        this.selMapData = selMapData
    })

    // cy.fixture('batchC2sTrfRules.json').then(function(batchC2sTrfRulesData){
    //     this.batchC2sTrfRulesData = batchC2sTrfRulesData
    // })

    cy.fixture('/rcReversal/rcDetails.json').then(function(rcData){
        this.rcData = rcData
    })

    cy.fixture('/rcReversal/rcReversal.json').then(function(rcRevData){
        this.rcRevData = rcRevData
    })

    // cy.fixture('calcC2sTrfValCCE.json').then(function(calcC2sData){
    //     this.calcC2sData = calcC2sData
    // })

    cy.fixture('associateIccid.json').then(function(associateIccidData){
        this.associateIccidData = associateIccidData
    })

    cy.fixture('messages.json').then(function(messages){
        this.messages = messages
    })
})

