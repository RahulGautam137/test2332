/// <reference types="Cypress" />

import { Given } from "@badeball/cypress-cucumber-preprocessor"


Given("Login with Network admin credentials on Core Setup",function(){
    cy.launchURL(Cypress.env('ang16coreUrl'))
    cy.login(this.userData.nwadmloginID, this.userData.nwadmpasswd);
})

Given("Login with Network admin credentials on Angular 16 PVG Setup",function(){
    cy.launchURL(Cypress.env('ang16pvgUrl'))
    cy.login(this.userData.nwadmloginID, this.userData.nwadmpasswd);
})

Given("Login with Network admin credentials",function(){
    cy.launchURL(Cypress.env('pvgUrl'))
    cy.login(this.userData.nwadmloginID, this.userData.nwadmpasswd);
})

Given("Login with channel user",function(){
    cy.launchURL(Cypress.env('pvgUrl'))
    cy.login(this.userData.channelUserLoginID, this.userData.channelUserPasswd);
})