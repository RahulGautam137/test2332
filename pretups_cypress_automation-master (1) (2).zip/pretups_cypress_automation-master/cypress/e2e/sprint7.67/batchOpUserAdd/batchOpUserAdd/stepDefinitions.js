/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then} from "@badeball/cypress-cucumber-preprocessor"
import opUserLandingPage from "../../../../support/pageObjects/operatorUser/opUserLanding/opUserLandingPage"
import addOpUserBatchPage from "../../../../support/pageObjects/operatorUser/addOpUserBatch/addOpUserBatchPage";
import "../../../../support/Utils/batchOptUser"


//-----------------------OBJECT DECLARATION----------------------
const opUserLandingScreen = new opUserLandingPage();
const addOpUserBatchScreen = new addOpUserBatchPage();

const downloadDir = 'cypress/downloads/';
const optDataFile = 'cypress/fixtures/bulkOptUser/bulkOperatorUserData.json'
// const optUserData = 'cypress/fixtures/optUserInfo.json'


Then("Upload empty file in bulk operator user add", function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    addOpUserBatchScreen.getAddToggleBtn().click()
    addOpUserBatchScreen.getCategoryDropdown().click()
    addOpUserBatchScreen.getCategoryDropdown().contains('Channel Admin').click()

    cy.randomName().then((value)=>{
        addOpUserBatchScreen.getBatchNameField().type(value+'Batch')
    })

    if(!this.bulkOptData.filePath){
        addOpUserBatchScreen.getDownloadTemplateBtn().click()
        cy.wait(3000)
        cy.task('listFiles', { dir: downloadDir }).then((files) => {
            
            cy.randomName().then((value)=>{
            const originalPath = downloadDir + files[0];
            const newPath = downloadDir +value+ 'OPTUSR.xls';
            cy.task('renameFile', { originalPath, newPath }).then(() => {
                cy.readFile(optDataFile).then((data)=>{
                    data.filePath = newPath
                    cy.writeFile(optDataFile,data)
                })
            })
            addOpUserBatchScreen.getChooseFile().selectFile(newPath);
            })
    })
    }

    else{
        cy.randomName().then((value)=>{
        const originalPath = this.bulkOptData.filePath;
        const newPath = downloadDir +value+ 'OPTUSR.xls';

        cy.task('renameFile', { originalPath, newPath }).then(() => {
            cy.readFile(optDataFile).then((data)=>{
                data.filePath = newPath
                cy.writeFile(optDataFile,data)
            })
        })
        addOpUserBatchScreen.getChooseFile().selectFile(newPath);
        })
    }

    addOpUserBatchScreen.getSubmitBtn().click()
    addOpUserBatchScreen.getConfirmBtnOnPopup().click()
    addOpUserBatchScreen.getErrMsg().should('contain.text',this.bulkOptData.emptyFileErrMsg)
    addOpUserBatchScreen.getDoneBtnOnErrPopup().click()
})

Then("Proceed without selecting category", function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    addOpUserBatchScreen.getAddToggleBtn().click()
    addOpUserBatchScreen.getSubmitBtn().click()
    addOpUserBatchScreen.getCategoryReqdErrMsg().should('contain.text',this.bulkOptData.categoryReqdErrMsg)
        
    })

Then("Proceed without selecting batch name", function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    addOpUserBatchScreen.getAddToggleBtn().click()
    addOpUserBatchScreen.getSubmitBtn().click()
    addOpUserBatchScreen.getBatchNameReqdErrMsg().should('contain.text',this.bulkOptData.batchNameReqdErrMsg)  
    })    

Then("Proceed without selecting file for batch operator user add", function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    addOpUserBatchScreen.getAddToggleBtn().click()
    addOpUserBatchScreen.getSubmitBtn().click()
    addOpUserBatchScreen.getFileReqdErrMsg().should('contain.text',this.bulkOptData.fileReqdErrMsg)
    })    

// And("Add operator users in batch",function(){
//     opUserLandingScreen.getBulkBtn().should('be.visible')
//     opUserLandingScreen.getBulkBtn().click()

//     addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
//     addOpUserBatchScreen.getAddToggleBtn().click()
//     addOpUserBatchScreen.getCategoryDropdown().click()
//     addOpUserBatchScreen.getCategoryDropdown().contains('Channel Admin').click()
//     addOpUserBatchScreen.getBatchNameField().type('Batch 1')
//     addOpUserBatchScreen.getDownloadTemplateBtn().click()    

//     cy.task('listFiles', { dir: downloadDir }).then((files) => {
//         // const originalPath = path.join(downloadDir, files[0]);  // Get the path of the downloaded file
//         // const newPath = path.join(downloadDir, 'BCUOPTUSR01.xls');  // Define the new path and filename  
//         const originalPath = downloadDir +"/"+ files[0];
//         const newPath = downloadDir + '/BCUOPTUSR01.xls';

//         cy.task('renameFile', { originalPath, newPath }).then(() => {
        
//             // Optionally, perform assertions or other actions after renaming
//             // For example, you can assert the existence of the renamed file
//             cy.task('listFiles', { dir: downloadDir }).then((updatedFiles) => {
//               expect(updatedFiles.includes('BCUOPTUSR01.xls')).to.be.true;
//             })

//             cy.readFile(optDataFile).then((data)=>{
//                 data.filePath = newPath
//                 cy.writeFile(optDataFile,data)
//             })
//         })
//     })



//     cy.task('excelToJsonConverter',this.bulkOptData.filePath).then(function(result){
//         // const sheetName="Template Sheet"
//         cy.log(result.TemplateSheet[4].A)
//         // cy.writeFile(optUserData,result)
//         // cy.wait(5000)
//         // cy.readFile(optDataFile).then((result)=>{
//         //     cy.writeFile(optDataFile,result)
//         // })

//         for (const [key, value] of Object.entries(result.TemplateSheet[4])) {
//             // Log each key-value pair to the Cypress console
//             cy.log(`Key: ${key}, Value: ${JSON.stringify(value)}`);
//         }

//         // cy.writeJsonToFile(result,optUserData).then(function(){
//         //     cy.log(`Data has been written to ${optUserData}`);
        
//         // Optionally, you can read the written JSON file and perform assertions
//         // cy.readFile(optUserData).then((fileContent) => {
//         //   // Assert or validate the content of the written JSON file if needed
//         //   expect(fileContent).to.not.be.null;
//         //   // ... other assertions or validations
//         // });
//         // })

//         // cy.readFile(optUserData).then((data)=>{
//         //     data.filePath = newPath
//         //     cy.writeFile(optDataFile,data)
//         // })
//     })

// })