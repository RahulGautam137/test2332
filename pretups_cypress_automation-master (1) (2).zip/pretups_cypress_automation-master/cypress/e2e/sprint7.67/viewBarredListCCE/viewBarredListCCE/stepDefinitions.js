/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import viewBarredListLandingPage from "../../../../support/pageObjects/viewBarredListCCE/viewBarredListCCE/viewBarredListLandingPage";

//-----------------------OBJECT DECLARATION----------------------
const viewBarredListScreen = new viewBarredListLandingPage();

//POSITIVE FLOW
Then("View C2S Barred List", function(){
        viewBarredListScreen.getUnbarToggleBtn().click()
        viewBarredListScreen.getAdvancedSearchBtn().click()
        viewBarredListScreen.getDateRange().click()
        viewBarredListScreen.getMonthDropdown().select(11)
        viewBarredListScreen.getYearDropdown().select("2023")
        viewBarredListScreen.getDates().contains(1).click()
        viewBarredListScreen.getDates().contains(25).click()
        viewBarredListScreen.getModuleDropdown().click()
        viewBarredListScreen.getModuleDropdownOptions().contains(this.barredList.moduleDropdown.c2s).click()
        viewBarredListScreen.getBarredAsDropdown().click()
        viewBarredListScreen.getBarredAsDropdownOptions().contains(this.barredList.barredAsDropdown.all).click()
        viewBarredListScreen.getBarringTypeDropdown().click()
        viewBarredListScreen.getBarringTypeDropdownOptions().contains(this.barredList.barringTypeDropdown.all).click()
        viewBarredListScreen.getProceedBtn().click()
        cy.wait(2000)
        viewBarredListScreen.getBarredListHeading().contains(this.barredList.barredListHeading).should('be.visible')
    })

Then("View P2P Barred List", function(){
        viewBarredListScreen.getUnbarToggleBtn().click()
        viewBarredListScreen.getAdvancedSearchBtn().click()
        viewBarredListScreen.getDateRange().click()
        viewBarredListScreen.getMonthDropdown().select(11)
        viewBarredListScreen.getYearDropdown().select("2023")
        viewBarredListScreen.getDates().contains(1).click()
        viewBarredListScreen.getDates().contains(25).click()
        viewBarredListScreen.getModuleDropdown().click()
        viewBarredListScreen.getModuleDropdownOptions().contains(this.barredList.moduleDropdown.p2p).click()
        viewBarredListScreen.getBarredAsDropdown().click()
        viewBarredListScreen.getBarredAsDropdownOptions().contains(this.barredList.barredAsDropdown.all).click()
        viewBarredListScreen.getBarringTypeDropdown().click()
        viewBarredListScreen.getBarringTypeDropdownOptions().contains(this.barredList.barringTypeDropdown.all).click()
        viewBarredListScreen.getProceedBtn().click()
        cy.wait(2000)
        viewBarredListScreen.getBarredListHeading().contains(this.barredList.barredListHeading).should('be.visible')
    })


//FIELD VALIDATION
Then("View Barred list when no records exist for the selected filters", function(){
    viewBarredListScreen.getUnbarToggleBtn().click()
    viewBarredListScreen.getAdvancedSearchBtn().click()
    viewBarredListScreen.getDateRange().click()
    viewBarredListScreen.getMonthDropdown().select(10)
    viewBarredListScreen.getYearDropdown().select("2023")
    viewBarredListScreen.getDates().contains(1).click()
    viewBarredListScreen.getDates().contains(25).click()
    viewBarredListScreen.getModuleDropdown().click()
    viewBarredListScreen.getModuleDropdownOptions().contains(this.barredList.moduleDropdown.p2p).click()
    viewBarredListScreen.getBarredAsDropdown().click()
    viewBarredListScreen.getBarredAsDropdownOptions().contains(this.barredList.barredAsDropdown.all).click()
    viewBarredListScreen.getBarringTypeDropdown().click()
    viewBarredListScreen.getBarringTypeDropdownOptions().contains(this.barredList.barringTypeDropdown.all).click()
    viewBarredListScreen.getProceedBtn().click()
    cy.wait(2000)
    viewBarredListScreen.getNoUserInBarredListMsg().should('contain.text',this.barredList.noUserInBarredListMsg)
})

