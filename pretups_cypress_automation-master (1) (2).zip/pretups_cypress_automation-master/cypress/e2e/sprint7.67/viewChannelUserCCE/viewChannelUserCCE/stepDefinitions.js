/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Given, Then } from "@badeball/cypress-cucumber-preprocessor"
import viewChannelUserDetailsPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserdetails/viewChannelUserDetailsPage";
import viewChannelUserLandingPage from "../../../../support/pageObjects/viewChannelUserCCE/viewChannelUserLandingPage/viewChannelUserLandingPage";
import "../../../../support/Utils/viewCuCCE"

//-----------------------OBJECT DECLARATION----------------------
const viewCuLandingScreen = new viewChannelUserLandingPage();
const viewCuDetailsScreen = new viewChannelUserDetailsPage();

const viewCuDataFile = "cypress/fixtures/viewCuData.json"

Given('Log in with customer care credentials', function () {
    cy.launchURL(Cypress.env('pvgUrl'))
    cy.login(this.userData.customerCareLoginID, this.userData.customerCarePasswd);
  })

//POSITIVE FLOW
Then("View Channel user by Msisdn", function(){
    viewCuLandingScreen.getHeading().should('be.visible')
    viewCuLandingScreen.getSearchByMsisdnBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuMobileNum)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getRecordRow().should('contain.text',this.cuData.cuMobileNum)   
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab1).click()
    viewCuDetailsScreen.getPhoneNoPrsnlDetailsTab().should('contain.text',this.cuData.cuMobileNum)   
})

Then("View Channel user by Login ID", function(){
    viewCuLandingScreen.getSearchByLoginIdBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuLoginId)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getRecordRow().should('contain.text',this.cuData.cuLoginId)   
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab2).click()
    viewCuDetailsScreen.getLoginIdLoginDetailsTab().should('contain.text',this.cuData.cuLoginId)    
})

Then("View Channel user by External Code", function(){
    viewCuLandingScreen.getSearchByExtCodeBtn().click();
    viewCuLandingScreen.getInputField().type(this.cuData.cuExtCode)
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getUsernameLink().click()
    cy.wait(2000)
    viewCuDetailsScreen.getDetailsTab().contains(this.cuData.detailsTab1).click()
    viewCuDetailsScreen.getExtCodePrsnlDetailsTab().should('contain.text',this.cuData.cuExtCode)    
})

//FIELD VALIDATION
Then("View Channel user without entering Mobile number", function(){
    viewCuLandingScreen.getSearchByMsisdnBtn().click();
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.msisdnReqdErrMsg)
})

Then("View Channel user without entering login ID", function(){
    viewCuLandingScreen.getSearchByLoginIdBtn().click();
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.loginIdReqdErrMsg)
})

Then("View Channel user without entering External Code", function(){
    viewCuLandingScreen.getSearchByExtCodeBtn().click();
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.extCodeReqdErrMsg)
    })

Then("Proceed with invalid Msisdn",function(){
    viewCuLandingScreen.getSearchByMsisdnBtn().click()
    cy.getRandomMsisdn(15).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
        cy.readFile(viewCuDataFile).then((data)=>{
            data.invalidMsisdn = value
            cy.writeFile(viewCuDataFile,data)})
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.invalidMsisdnErrMsg)
})

Then("Proceed with invalid login ID",function(){
    viewCuLandingScreen.getSearchByLoginIdBtn().click()
    cy.getRandomLoginId(30).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
        cy.readFile(viewCuDataFile).then((data)=>{
            data.invalidLoginId = value
            cy.writeFile(viewCuDataFile,data)})
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.invalidLoginIdErrMsg)
})

Then("Proceed with invalid external code",function(){
    viewCuLandingScreen.getSearchByExtCodeBtn().click()
    cy.getRandomExtCode(30).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
        cy.readFile(viewCuDataFile).then((data)=>{
            data.invalidMsisdn = value
            cy.writeFile(viewCuDataFile,data)})
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getErrorMsg().should('contain.text',this.cuData.invalidExtCodeErrMsg)
})

Then("Proceed with Msisdn that does not exist",function(){
    viewCuLandingScreen.getSearchByMsisdnBtn().click()
    cy.getRandomMsisdn(10).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getNoChannelUserFoundMsg().should('contain.text',this.cuData.noChannelUserMsg)
})

Then("Proceed with login ID that does not exist",function(){
    viewCuLandingScreen.getSearchByLoginIdBtn().click()
    cy.getRandomLoginId(20).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getNoChannelUserFoundMsg().should('contain.text',this.cuData.noCuLoginIdMsg)
})

Then("Proceed with external code that does not exist",function(){
    viewCuLandingScreen.getSearchByExtCodeBtn().click()
    cy.getRandomExtCode(10).then((value)=>{
        viewCuLandingScreen.getInputField().type(value)
    })
    viewCuLandingScreen.getProceedBtn().click()
    viewCuLandingScreen.getNoChannelUserFoundMsg().should('contain.text',this.cuData.noChannelUserMsg)
})




