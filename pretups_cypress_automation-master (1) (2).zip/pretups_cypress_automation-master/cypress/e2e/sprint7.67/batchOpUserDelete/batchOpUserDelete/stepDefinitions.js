/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import opUserLandingPage from "../../../../support/pageObjects/operatorUser/opUserLanding/opUserLandingPage"
import addOpUserBatchPage from "../../../../support/pageObjects/operatorUser/addOpUserBatch/addOpUserBatchPage";
import deleteOpUserBatchPage from "../../../../support/pageObjects/operatorUser/deleteOpUserBatch/deleteOpUserBatchPage";


//-----------------------OBJECT DECLARATION----------------------
const opUserLandingScreen = new opUserLandingPage();
const addOpUserBatchScreen = new addOpUserBatchPage();
const deleteOpUserBatchScreen = new deleteOpUserBatchPage();

const optDataFile = 'cypress/fixtures/bulkOptUser/bulkOperatorUserData.json';
const fixturesDir = 'cypress/fixtures/bulkOptUser/';
// const downloadDir = 'cypress/downloads';

//-----------------------FUNCTIONS-----------------------------

Then("Delete Operator users in batch", function(){
  opUserLandingScreen.getBulkBtn().should('be.visible')
  opUserLandingScreen.getBulkBtn().click()
  addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
  deleteOpUserBatchScreen.getDeleteToggleBtn().click()  

  //if no txt file exists then following will be executed
  if(!this.bulkOptData.loginIdDataFilePath){
      cy.randomName().then((value) => {
          const jsonFilePath = this.bulkOptData.loginIdJsonFilePath;  // Path to your JSON file
          const txtFilePath = 'cypress/fixtures/bulkOptUser/'+value+'optDelete.txt';  // Path to the text file
          const numberOfRecordsToBeDeleted = 5;

          //creating an empty txt file
          cy.writeFile(txtFilePath,"")
  
          cy.wait(3000)

          //writin login ids in txt file
          cy.selectAndWriteLoginIds(jsonFilePath, txtFilePath , numberOfRecordsToBeDeleted).then(() => {
            cy.log('Login IDs have been written to the text file.');
          })
  
          cy.wait(2000)
          addOpUserBatchScreen.getChooseFile().selectFile(txtFilePath);
  
          //Writing filepath into json file
          cy.readFile(optDataFile).then((data)=>{
          data.loginIdDataFilePath = txtFilePath
          cy.writeFile(optDataFile,data)
          })
  
      });
      cy.wait(2000)
      addOpUserBatchScreen.getSubmitBtn().click()
      cy.wait(2000)
      deleteOpUserBatchScreen.getDeleteSuccessMsg().should('contain.text',this.bulkOptData.deleteOptBulkSuccessMsg)
  }
  
  //if a text file already exists , following code will just rename the file and
  //enter new data into it
  else{

      cy.randomName().then((value)=>{
      const originalPath = this.bulkOptData.loginIdDataFilePath;
      const newPath = 'cypress/fixtures/bulkOptUser/'+value+'optDelete.txt';;
      cy.task('renameFile', { originalPath, newPath }).then(() => {
      
          //checking if renamed file exists
          cy.task('listFiles', { dir: fixturesDir }).then((updatedFiles) => {
            expect(updatedFiles.includes(value+'optDelete.txt')).to.be.true;
          })

          cy.readFile(optDataFile).then((data)=>{
              data.loginIdDataFilePath = newPath
              cy.writeFile(optDataFile,data)
          })
      })
  
      const jsonFilePath = this.bulkOptData.loginIdJsonFilePath;  // JSON file path
      const txtFilePath = newPath;  // text file path
      const numberOfRecordsToBeDeleted = 5;
  
      cy.wait(3000)
      // fetching and writing mobile numbers in txt file
        cy.selectAndWriteLoginIds(jsonFilePath, txtFilePath , numberOfRecordsToBeDeleted).then(() => {
          cy.log('Login IDs have been written to the text file.');
        })
  
      cy.wait(2000)
      addOpUserBatchScreen.getChooseFile().selectFile(txtFilePath);
      cy.wait(2000)
      addOpUserBatchScreen.getSubmitBtn().click()
      cy.wait(2000)
      deleteOpUserBatchScreen.getDeleteSuccessMsg().should('contain.text',this.bulkOptData.deleteOptBulkSuccessMsg)
      })
    }

})

Then("Upload empty file in bulk operator user delete", function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    deleteOpUserBatchScreen.getDeleteToggleBtn().click()
    cy.writeFile(this.bulkOptData.emptyFilePath,"")
    addOpUserBatchScreen.getChooseFile().selectFile(this.bulkOptData.emptyFilePath);
    addOpUserBatchScreen.getSubmitBtn().click()
    deleteOpUserBatchScreen.getEmptyFileErrMsgOnPopup().should('contain.text',this.bulkOptData.emptyFileErrMsgOptDelete)
    })

Then("Proceed without selecting File for operator user delete in batch",function(){
    opUserLandingScreen.getBulkBtn().should('be.visible')
    opUserLandingScreen.getBulkBtn().click()
    addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
    deleteOpUserBatchScreen.getDeleteToggleBtn().click()
    addOpUserBatchScreen.getSubmitBtn().click()
    addOpUserBatchScreen.getFileReqdErrMsg().should('contain.text',this.bulkOptData.fileReqdErrMsg)

})

// And("Delete Operator users in batch with invalid data in file", function(){
//   opUserLandingScreen.getBulkBtn().should('be.visible')
//   opUserLandingScreen.getBulkBtn().click()
//   addOpUserBatchScreen.getBatchOpUserHeading().should('be.visible')
//   deleteOpUserBatchScreen.getDeleteToggleBtn().click()  
//   addOpUserBatchScreen.getChooseFile().selectFile(this.bulkOptData.invalidDataDeleteFilePath);
//   cy.wait(2000)
//   addOpUserBatchScreen.getSubmitBtn().click()
//   cy.wait(2000)
//   deleteOpUserBatchScreen.getViewErrLogLink().click()

//   cy.task('listFiles', { dir: downloadDir }).then((files) => {
//     // const originalPath = path.join(downloadDir, files[0]);  // Get the path of the downloaded file
//     // const newPath = path.join(downloadDir, 'BCUOPTUSR01.xls');  // Define the new path and filename  
//     const originalPath = downloadDir +"/"+ files[0];
//     const newPath = downloadDir + '/BcuOptErr02.csv';

//     cy.task('renameFile', { originalPath, newPath }).then(() => {
    
//         // Optionally, perform assertions or other actions after renaming
//         // For example, you can assert the existence of the renamed file
//         cy.task('listFiles', { dir: downloadDir }).then((updatedFiles) => {
//           expect(updatedFiles.includes('BcuOptErr01.csv')).to.be.true;
//         })

//         cy.readFile(optDataFile).then((data)=>{
//             data.deleteErrFilePath = newPath
//             cy.writeFile(optDataFile,data)
//         })
//     })



// })
  

// })
