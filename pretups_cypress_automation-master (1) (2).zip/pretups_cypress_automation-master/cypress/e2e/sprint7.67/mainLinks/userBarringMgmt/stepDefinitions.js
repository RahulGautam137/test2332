/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import homePage from "../../../../support/pageObjects/homePage"

//-----------------------OBJECT DECLARATION----------------------
const homeScreen = new homePage();


Then("Click on User Barring Management Card", function(){

    //Assertion that user has successfully logged in and has reached on main screen
    homeScreen.getEtopupTab().should('contain.text',this.loginData.etopupTabText)
   
    //Click on Approval level 1 link
    homeScreen.getUserBarringMgmtLink().click()   
})