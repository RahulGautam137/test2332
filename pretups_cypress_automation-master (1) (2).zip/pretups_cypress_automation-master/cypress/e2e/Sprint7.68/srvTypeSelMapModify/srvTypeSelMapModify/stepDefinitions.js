/// <reference types="Cypress" />

// const srvTypeSelMapFile = "cypress/fixtures/srvTypeSelMapData.json"

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import serviceTypeSelectorMappingLandingPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingLanding/serviceTypeSelectorMappingLandingPage"
import serviceTypeSelectorMappingAddPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingAdd/serviceTypeSelectorMappingAddPage";
import "../../../../support/Utils/servTypeSelMap"

//-----------------------OBJECT DECLARATION----------------------
const srvTypeSelMapLandingScreen = new serviceTypeSelectorMappingLandingPage();
const srvTypeSelMapAddScreen = new serviceTypeSelectorMappingAddPage();

Then("Modify Service type selector mapping", function(){

    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getSearchBar().type(this.selMapData.productName)
    srvTypeSelMapLandingScreen.getEditActionBtn().click()
    srvTypeSelMapAddScreen.getStatusDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('Suspended')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getDefaultNoRadioBtn().check()
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getSuccessMsg().should('contain.text',this.selMapData.mappingModifySuccessMsg)
    cy.wait(2000)
    srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()

})


Then("Modify Service type selector mapping with status as suspended and Yes in Default radio button", function(){

    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getSearchBar().type(this.selMapData.productName)
    srvTypeSelMapLandingScreen.getEditActionBtn().click()
    srvTypeSelMapAddScreen.getStatusDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('Suspended')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getDefaultYesRadioBtn().check()
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getFailureMsg().should('contain.text',this.selMapData.suspendDefaultMappingErrMsg)
    cy.wait(2000)
    srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()

})