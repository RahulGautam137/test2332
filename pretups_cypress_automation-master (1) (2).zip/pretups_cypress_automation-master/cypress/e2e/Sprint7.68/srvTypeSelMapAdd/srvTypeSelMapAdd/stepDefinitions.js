/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import serviceTypeSelectorMappingLandingPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingLanding/serviceTypeSelectorMappingLandingPage"
import serviceTypeSelectorMappingAddPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingAdd/serviceTypeSelectorMappingAddPage";
import "../../../../support/Utils/servTypeSelMap"

//-----------------------OBJECT DECLARATION----------------------
const srvTypeSelMapLandingScreen = new serviceTypeSelectorMappingLandingPage();
const srvTypeSelMapAddScreen = new serviceTypeSelectorMappingAddPage();

const srvTypeSelMapFile = "cypress/fixtures/srvTypeSelMapData.json"

Then("Add Service type selector mapping", function(){

    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()

    cy.randomProdName().then((prdName)=>{
        srvTypeSelMapAddScreen.getProductNameInputField().type(prdName)
        srvTypeSelMapAddScreen.getProductNameInputField().invoke('val').then((val)=>{
            cy.readFile(srvTypeSelMapFile).then((data)=>{
                data.productName = val
                cy.writeFile(srvTypeSelMapFile,data)
            })
        })
    
    })

    cy.randomProdCode(3).then((prdCode)=>{
        srvTypeSelMapAddScreen.getProductCodeInputField().type(prdCode)
        srvTypeSelMapAddScreen.getProductCodeInputField().invoke('val').then((val)=>{
            cy.readFile(srvTypeSelMapFile).then((data)=>{
                data.productCode = val
                cy.writeFile(srvTypeSelMapFile,data)
            })
        })
    
    })

    srvTypeSelMapAddScreen.getSenderSubscriberTypeDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

// for (index = 0; index < list.length; index++) {
//     cy.log(list[index])    
// }

        if($ele.text().includes('Prepaid')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getReceiverSubscriberTypeDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('ALL')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getStatusDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('Active')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getDefaultNoRadioBtn().check()
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getSuccessMsg().should('contain.text',this.selMapData.mappingAddSuccessMsg)
    cy.wait(2000)
    srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()
})

Then("Proceed without entering Product name",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getProdNameReqdErrMsg().should('contain.text',this.selMapData.prdNameReqdErrMsg)
})


Then("Proceed without entering Product code",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getProdCodeReqdErrMsg().should('contain.text',this.selMapData.prdCodeReqdErrMsg)
})


Then("Proceed without selecting Sender Subscriber Type",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getSenderSubsTypeReqdErrMsg().should('contain.text',this.selMapData.senderSubsTypeReqdErrMsg)
})

Then("Proceed without selecting Receiver Subscriber Type",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getRecvSubsTypeReqdErrMsg().should('contain.text',this.selMapData.recvSubsTypeReqdErrMsg)

})

Then("Proceed without selecting Status",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()
    cy.wait(2000)
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getStatusReqdErrMsg().should('contain.text',this.selMapData.statusReqdErrMsg)
})

Then("Proceed with product code length greater than allowed", function(){
        srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
        srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
        srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
        srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
        cy.wait(2000)
        srvTypeSelMapLandingScreen.getAddBtn().click()

        cy.randomProdCode(4).then((prdCode)=>{
            srvTypeSelMapAddScreen.getProductCodeInputField().type(prdCode)
    
            cy.readFile(srvTypeSelMapFile).then((data)=>{
                data.invalidProdCode = prdCode
                cy.writeFile(srvTypeSelMapFile,data)
            })
        
        })

        srvTypeSelMapAddScreen.getProdCodeReqdErrMsg().should('contain.text',this.selMapData.prdCodeMaxLengthErrMsg)
})


Then("Proceed with product name length greater than allowed", function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getAddBtn().click()

    cy.randomProdCode(21).then((prdName)=>{
        srvTypeSelMapAddScreen.getProductNameInputField().type(prdName)

        cy.readFile(srvTypeSelMapFile).then((data)=>{
            data.invalidProdName = prdName
            cy.writeFile(srvTypeSelMapFile,data)
        })
    
    })

    cy.randomProdCode(3).then((prdCode)=>{
        srvTypeSelMapAddScreen.getProductCodeInputField().type(prdCode)
        srvTypeSelMapAddScreen.getProductCodeInputField().invoke('val').then((val)=>{
            cy.readFile(srvTypeSelMapFile).then((data)=>{
                data.productCode = val
                cy.writeFile(srvTypeSelMapFile,data)
            })
        })
    
    })

    srvTypeSelMapAddScreen.getSenderSubscriberTypeDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('Prepaid')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getReceiverSubscriberTypeDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('ALL')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getStatusDropdown().click()
    srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

        if($ele.text().includes('Active')){
            cy.log('Element Found',$ele.text())
            cy.wrap($ele).click()
        }
        else{
            cy.log('current value',$ele.text())
        }

    })

    srvTypeSelMapAddScreen.getDefaultNoRadioBtn().check()
    srvTypeSelMapAddScreen.getPopupAddBtn().click()
    srvTypeSelMapAddScreen.getFailureMsg().should('contain.text',this.selMapData.prdNameMaxLengthErrMsg)
    cy.wait(2000)
    srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()
})

// Following cases Shall be done after DB Integration

// And("Proceed with existing product name", function(){    
//     srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
//     srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
//     srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
//     srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
//     cy.wait(2000)
//     srvTypeSelMapLandingScreen.getAddBtn().click()

//     srvTypeSelMapAddScreen.getProductNameInputField().type(this.selMapData.productName)
//     cy.randomProdCode(3).then((prdCode)=>{
//         srvTypeSelMapAddScreen.getProductCodeInputField().type(prdCode)

//         cy.readFile(srvTypeSelMapFile).then((data)=>{
//             data.productCode = prdCode
//             cy.writeFile(srvTypeSelMapFile,data)
//         })
    
//     })

//     srvTypeSelMapAddScreen.getSenderSubscriberTypeDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('Prepaid')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getReceiverSubscriberTypeDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('ALL')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getStatusDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('Active')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getDefaultNoRadioBtn().check()
//     srvTypeSelMapAddScreen.getPopupAddBtn().click()
//     srvTypeSelMapAddScreen.getFailureMsg().should('contain.text',this.selMapData.prdNameCodeExistErrMsg)
//     cy.wait(2000)
//     srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()
// })

// And("Proceed with existing product code", function(){
//     srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
//     srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
//     srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
//     srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
//     cy.wait(2000)
//     srvTypeSelMapLandingScreen.getAddBtn().click()

//     cy.randomProdName().then((prdName)=>{
//         srvTypeSelMapAddScreen.getProductNameInputField().type(prdName)
        
//         cy.readFile(srvTypeSelMapFile).then((data)=>{
//             data.productName = prdName
//             cy.writeFile(srvTypeSelMapFile,data)
//         })
    
//     })

//     srvTypeSelMapAddScreen.getProductCodeInputField().type(this.selMapData.productCode)

//     srvTypeSelMapAddScreen.getSenderSubscriberTypeDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('Prepaid')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getReceiverSubscriberTypeDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('ALL')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getStatusDropdown().click()
//     srvTypeSelMapAddScreen.getDropdownOptionsText().each(function($ele,index,list){

//         if($ele.text().includes('Active')){
//             cy.log('Element Found',$ele.text())
//             cy.wrap($ele).click()
//         }
//         else{
//             cy.log('current value',$ele.text())
//         }

//     })

//     srvTypeSelMapAddScreen.getDefaultNoRadioBtn().check()
//     srvTypeSelMapAddScreen.getPopupAddBtn().click()
//     srvTypeSelMapAddScreen.getFailureMsg().should('contain.text',this.selMapData.prdNameCodeExistErrMsg)
//     cy.wait(2000)
//     srvTypeSelMapAddScreen.getDoneBtnOnMsgPopup().click()
// })