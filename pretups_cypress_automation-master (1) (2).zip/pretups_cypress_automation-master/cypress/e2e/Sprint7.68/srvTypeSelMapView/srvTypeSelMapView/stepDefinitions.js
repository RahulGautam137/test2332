/// <reference types="Cypress" />

//---------------------IMPORTS------------------------------
import { Then } from "@badeball/cypress-cucumber-preprocessor"
import serviceTypeSelectorMappingLandingPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingLanding/serviceTypeSelectorMappingLandingPage"
import serviceTypeSelectorMappingAddPage from "../../../../support/pageObjects/serviceTypeSelectorMapping/serviceTypeSelectorMappingAdd/serviceTypeSelectorMappingAddPage";
import "../../../../support/Utils/servTypeSelMap"

//-----------------------OBJECT DECLARATION----------------------
// const homeScreen = new homePage();
const srvTypeSelMapLandingScreen = new serviceTypeSelectorMappingLandingPage();
const srvTypeSelMapAddScreen = new serviceTypeSelectorMappingAddPage();

const srvTypeSelMapFile = "cypress/fixtures/srvTypeSelMapData.json"

Then("View Service type selector mapping", function(){

    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getSearchBar().type(this.selMapData.productName)
    srvTypeSelMapLandingScreen.getRecordRow().should('contain.text',this.selMapData.productName)

})

Then("Proceed without selecting Service Type", function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    srvTypeSelMapLandingScreen.getServiceRequiredErrMsg().should('contain.text',this.selMapData.serviceReqdErrMsg)
})

Then("Proceed with a service type that has no mapping records",function(){
    srvTypeSelMapLandingScreen.getLandingPageHeading().should('be.visible').and('contain.text',this.selMapData.srvTypeSelMapScreenHeading)
    srvTypeSelMapLandingScreen.getServiceNameDropdown().click()
    srvTypeSelMapLandingScreen.getNoMappingServiceNameDropdownOption().click()
    srvTypeSelMapLandingScreen.getLandingPageProceedBtn().click()
    cy.wait(2000)
    srvTypeSelMapLandingScreen.getNoMappingrecordsMsg().should('contain.text',this.selMapData.noRecordsMsg)
})