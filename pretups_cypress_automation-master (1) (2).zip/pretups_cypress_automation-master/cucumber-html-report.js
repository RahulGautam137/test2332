const report = require('multiple-cucumber-html-reporter');

// const d = new Date();
// var year = d.getFullYear();
// var month = d.getMonth();
// var day = d.getDate();
// var hour = d.getHours();
// var mins = d.getMinutes();
// var seconds = d.getSeconds();


function formatDate(date) {
    // Get individual date components
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Month is zero-based
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');

    // Concatenate components to form the desired format
    return `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
}

// Create a new Date object
const now = new Date();



report.generate({
	jsonDir: './cypress/reports',
	reportPath: 'cypress/reports/cucumber-report.html',
	metadata:{
        browser: {
            name: 'edge',
            version: '123'
        },
        device: 'Local test machine',
        platform: {
            name: 'Windows',
            version: '10'
        }
    },
    customData: {
        title: 'Run info',
        data: [
            {label: 'Project', value: 'PreTUPs Roadmap'},
            {label: 'Release', value: '7.71'},
            {label: 'Execution Start Time', value: formatDate(now)},
        ]
    }
});