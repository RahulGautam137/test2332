/* 
  Following link can be referred to understand the following imports , functions , setupNodeEvents etc
  https://github.com/badeball/cypress-cucumber-preprocessor/blob/145dde30397408a93f434756e3850554af3f7d46/examples/esbuild-cjs/cypress.config.js
*/

const { defineConfig } = require("cypress");
const createBundler = require("@bahmutov/cypress-esbuild-preprocessor");
const { addCucumberPreprocessorPlugin, } = require("@badeball/cypress-cucumber-preprocessor");
const { createEsbuildPlugin, } = require("@badeball/cypress-cucumber-preprocessor/esbuild");
const fs = require('fs');
const path = require('path');
const {Pool} = require('pg');
const XLSX = require('xlsx');


async function setupNodeEvents(on, config) {
  // This is required for the preprocessor to be able to generate JSON reports after each run, and more,
  await addCucumberPreprocessorPlugin(on, config);

  on(
    "file:preprocessor",
    createBundler({
      plugins: [createEsbuildPlugin(config)],
    })
  );

  //For PostGreSQL DB connectivity
  const pool = new Pool({
    host: "172.30.41.48",
    user: "prtp7_51pgb3",
    password: "prtp7_51pgb3",
    database: "prtp7_51pgb3",
    port: "5455"
  });

  // Task for fetching data from PostGreSQL database
  on("task",{
    queryDatabase :(query)=>{
      return pool.query(query).then((result)=>{
        return result.rows;
      });
    },
  });

  // Task for fetching the latest downloaded file on the basis of parameters passed
  on('task',{
    fetchLatestDownloadedFile({fileStarting,fileExtension,directoryPath}){

      let regexPattern;
      if (fileStarting === 'CELLGRP') {
        
        // Regex pattern for CELLGRP filename
        regexPattern = new RegExp(`^${fileStarting}\\d{8}_\\d{6}\\.${fileExtension}$`);

      } else if (fileStarting === 'messageList') {
        
        // Regex pattern for messageList filename
        regexPattern = new RegExp(`^${fileStarting}\\d+\\.(${fileExtension.toUpperCase()}|${fileExtension.toLowerCase()})$`);
      
      } else if (fileStarting === 'CRASSFILE'){
        
        // Regex pattern for cell id re-associate  
        regexPattern = new RegExp(`^${fileStarting}_\\d{8}_\\d{6}\\.${fileExtension}$`);

      } else {
        
        // Handle other filename variations
        throw new Error(`Unsupported filename: ${fileStarting}`);
      
      }

      // Read the contents of the directory
      const files = fs.readdirSync(directoryPath);

      // Filter filenames based on the regular expression
      const filteredFiles = files.filter(file => regexPattern.test(file));

      // Sort files by modification time (latest first)
      filteredFiles.sort((a, b) => {
          const statA = fs.statSync(path.join(directoryPath, a));
          const statB = fs.statSync(path.join(directoryPath, b));
          return statB.mtime.getTime() - statA.mtime.getTime();
      });

      // Return the fist file after sorting (latest file)
      return filteredFiles[0];

    }
  })

  // Task for appending data in excel sheet
  on('task', {
    appendDataInExcelWs({ filePath, dataToBeAppended }) {

        const workBook = XLSX.readFile(filePath);
        const workSheet = workBook.Sheets[workBook.SheetNames[0]];
        const data = dataToBeAppended;

        // Clear existing data in the worksheet, leaving only the headers
        const headers = Object.values(XLSX.utils.sheet_to_json(workSheet, { header: 1 })[0]);
        const newWorksheet = XLSX.utils.aoa_to_sheet([headers]);

        // Append new data to the worksheet
        XLSX.utils.sheet_add_json(newWorksheet, data, { skipHeader: true, origin: -1 });

        // Update the worksheet in the workbook
        workBook.Sheets[workBook.SheetNames[0]] = newWorksheet;

        XLSX.writeFile(workBook, filePath);
        return null;
		}
	})

  // Task for renaming the file
  on('task', {
    renameFile({ originalPath, newPath }) {
      fs.renameSync(originalPath, newPath);
      return null;
    }
  });

  //Task for appending data (Cell group ID & action) against search data for Cell ID Re-Associate

  on('task',{
    appendDataCellIdReAss({filePath,searchValues,action,cellIdValues}){
      let cellGrpUpdate,actionColUpdate,cellGrpCol,actionCol;
      const workBook = XLSX.readFile(filePath);
      const workSheet = workBook.Sheets[workBook.SheetNames[0]];

      const valueMappings = {};
      // traverse and map search values with cell group ID
      searchValues.forEach((searchValue, index) => {
        const cellId = cellIdValues[index];
        valueMappings[searchValue] = cellId;
      });

      searchValues.forEach(searchValue => {
        const cellId = valueMappings[searchValue];

        for (const cellAddress in workSheet) {
            if (workSheet.hasOwnProperty(cellAddress)) {
                const cell = workSheet[cellAddress];
                if (cell.v === searchValue) {
                    // Get the row and column indices of the cell
                    const { r, c } = XLSX.utils.decode_cell(cellAddress);
                    // Get cell group
                     cellGrpCol = XLSX.utils.encode_cell({ r:r, c: c + 5 });
                     cellGrpUpdate = workSheet[cellGrpCol];
                    // Get action
                     actionCol = XLSX.utils.encode_cell({ r:r, c: c + 6 });
                     actionColUpdate = workSheet[actionCol];
                    break;
                }
            }
        }
          if (!cellGrpUpdate || !actionColUpdate) {
            // If the cell doesn't exist (or value is undefined), create it
            workSheet[cellGrpCol] = { t: 's', v: cellId }; 
            workSheet[actionCol] = { t: 's', v: action }; 
        } else {
            // If the cell already exists, update its value
            workSheet[cellGrpCol].v = cellId;
            workSheet[actionCol].v = action;
        }
    })
    XLSX.writeFile(workBook, filePath);
    return null;
    }
  })

  //Task for appending data(A,S,D) in Action column against search data for Cell ID Re-Associate

  on('task',{
    addDataInActionCol({filePath,searchValues,action}){
      let actionColUpdate,actionCol;
      const workBook = XLSX.readFile(filePath);
      const workSheet = workBook.Sheets[workBook.SheetNames[0]];

      searchValues.forEach(searchValue => {

        for (const cellAddress in workSheet) {
            if (workSheet.hasOwnProperty(cellAddress)) {
                const cell = workSheet[cellAddress];
                if (cell.v === searchValue) {
                    // Get the row and column indices of the cell
                    const { r, c } = XLSX.utils.decode_cell(cellAddress);
                    // Get action
                     actionCol = XLSX.utils.encode_cell({ r:r, c: c + 6 });
                     actionColUpdate = workSheet[actionCol];
                    break;
                }
            }
        }
        
        if (!actionColUpdate) {
          // If the cell doesn't exist (or value is undefined), create it
          workSheet[actionCol] = { t: 's', v: action }; 
      } else {
          // If the cell already exists, update its value
          workSheet[actionCol].v = action;
      }

    })
    XLSX.writeFile(workBook, filePath);
    return null;
    }
  })


  // Make sure to return the config object as it might have been modified by the plugin.
  return config;
}


module.exports = defineConfig({
  projectId: "gktv85",
  trashAssetsBeforeRuns: false,		//to avoid trashing assets before running test case in run/open mode
  defaultCommandTimeout : 100000,
  pageLoadTimeout :120000,
  viewportWidth: 1400,
  viewportHeight: 900,
  retries: {
    runMode: 0,		//count to retry failed test case in run Mode
    openMode: 0,	//count to retry failed test case in open Mode
    },
  e2e: {
    specPattern: 
    [
      "cypress/e2e/BDD/SIT/**/*.feature",
      "cypress/e2e/BDD/SMOKE/**/*.feature",
      "cypress/e2e/BDD/UAT/**/*.feature"
    ],
    setupNodeEvents,
    env:{
      mobileDigits:"8",
      pvgUrl:"http://172.30.40.143:6852/pretups-ui",
      coreUrl:"http://172.30.38.232:9747/pretups-ui",
      ang16coreUrl:"http://172.30.38.232:9747/pretups-ui-16",
      ang16pvgUrl:"http://172.30.40.143:6852/pretups-ui-16",
      ggnNwPrefix:"72"
    },
  },
});
